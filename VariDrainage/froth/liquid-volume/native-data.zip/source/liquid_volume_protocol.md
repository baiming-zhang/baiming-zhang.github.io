# Actual liquid control volumes and closed-network tracer reference

Scope: tetrahedralize saved wet liquid bodies, build barycentric control volumes
and shared cuts, and evolve passive BULK tracer diffusion on a fixed connected
liquid network. This is not surfactant/Marangoni coupling, liquid drainage,
coarsening, moving foam or rupture. The full objective remains open.

Inputs: conditioned wet7-s020/final and wet7-s010/final, plus wet4-s020/initial.
Four-body relaxation previously failed its projection-warning gate. Its INITIAL
saved surface is used only as a fixed geometric domain, subject to fresh PLC,
surface/volume and dual checks; it is not an accepted relaxed equilibrium.
Dry triple-force residuals remain unresolved and are not erased by this test.

Use MeshPy2026.1.1's bundled TetGen, no source patches. For each input, retain a
default `pfn` mesh as a geometry-loss control, and `pMfn` as the no-coplanar-merge
reference. No hole-filling, smoothing, boundary repair or arbitrary cross-section
factors. All tetrahedra must have positive oriented volume; independently compare
total volume with the saved native liquid body (<1e-8 relative). Record exact
exterior triangle geometry and per-body face labels. No PDE evolution on a mesh
that fails this volume gate.

Within each tetrahedron, one nodal barycentric dual cell has Vtet/4. Construct
each actual shared quadrilateral from the edge midpoint, its two face centroids,
and tetrahedron centroid, oriented once from node i to j. Build exterior dual
patches on each boundary triangle. Rebuild every cell volume by oriented dual-face
tetrahedra around its own node; compare with Vtet/4 accumulation (<1e-8).
Cell area-normal closure relative to its total boundary area <1e-9. One shared
cut has two opposite incidence signs; no duplicated inventory. Export physical
m^3 and m^2. The dual is a discretization choice, not a new physical border/vertex
partition. Finite film liquid volume is still absent.

Passive reference: Dc=5e-10 m²/s, c*=.002 mol/m³ (diagnostic choices), R=.01m;
zero normal tracer flux on the whole liquid boundary, fixed geometry. P1
variational diffusion with positive lumped volume mass. Assemble tetrahedral
gradient stiffness without replacing positive off-diagonals by a fitted graph
law. Enforce its analytical constant null mode only by subtracting floating-point
row sums from the diagonal; report the relative change. Solve the perturbation
about constant c/c*=1, without amount correction/clipping. A shared algebraic
edge flux is a weak FEM exchange, NOT an independently reconstructed normal
physical flux through the dual cut. Report non-M-matrix off-diagonals and actual
min/max; no general discrete maximum-principle claim.

Freeze six evolutions: wet7 .02 main dt5000s, half dt2500s, uniform dt5000s,
one conforming red refinement (8 tets per parent) dt5000s, wet7 .01 dt5000s,
wet4 initial .02 dt5000s. T=100000s, 140 backward-Euler steps total. This is long
physical tracer time, short CPU computation, NO training. Smooth diagnostic
initial c/c*=1+.2exp(-|x-xseed|²/(.15R)²); seed is a lexicographically chosen
native dry quadruple point. Uniform control is1 exactly. No rerun/parameter scan
after this matrix; preserve failures. If input meshing fails, record and skip
dependent evolutions rather than silently substitute a different geometry.

Evolution gates: positive concentration, inventory relative error <1e-10,
quadratic diffusion/BE dissipation ledger relative to initial quadratic energy
<1e-8, original linear residual <1e-9 relative, uniform error <1e-12. These
are numerical checks, not experimental validation. Time and spatial common-mesh
mean-subtracted field differences are reported against1% (not assumed passed).
Space comparison uses exact coarse-edge midpoint prolongation to the refined
nodes, no mesh finder. Geometry .01/.02 is initializer sensitivity, not refinement.

Primary tool references accessed2026-11-13:
https://documen.tician.de/meshpy/tri-tet.html
https://www.wias-berlin.de/software/tetgen/switches.html (-M preserves input facets)
https://wias-berlin.de/software/tetgen/switches.d.html
https://tetgen.github.io/plc/
Do not claim novelty for TetGen, barycentric duals, conservation or FEM diffusion.
The eventual candidate remains tested finite-speed event/recipient/gas feedback.
