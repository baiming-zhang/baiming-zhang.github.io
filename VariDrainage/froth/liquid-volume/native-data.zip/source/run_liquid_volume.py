"""Frozen actual-volume / tracer matrix; native mesher subprocess logs retained."""
from pathlib import Path
import argparse,csv,hashlib,json,platform,subprocess,sys,time
from importlib.metadata import version
import numpy as np
from liquid_control_volume import ROOT,R,D,CSTAR,load_surface,tetrahedralize,volumes,dual_cells,evolve,refine
OUT=ROOT/'results/liquid-volume';LOG=ROOT/'results/logs/liquid-volume'
def save(p,x):p.write_text(json.dumps(x,indent=2),encoding='utf8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def csvout(path,header,data):
    with path.open('w',newline='',encoding='utf8') as f:w=csv.writer(f);w.writerow(header);w.writerows(data)
def worker(name,n,spread,label,switches):
    x,f,gas,expected,_=load_surface(n,spread,label)
    csvout(OUT/f'{name}-input-vertices.csv',['id','x_over_R','y_over_R','z_over_R'],[[i,*v] for i,v in enumerate(x)])
    csvout(OUT/f'{name}-input-faces.csv',['id','v1','v2','v3','gas_body'],[[i,*tri,g] for i,(tri,g) in enumerate(zip(f,gas))])
    x,t,faces,markers=tetrahedralize(x,f,switches);v=volumes(x,t)
    np.savez_compressed(OUT/f'{name}.npz',points=x,tets=t,faces=faces,markers=markers)
    result=dict(name=name,switches=switches,vertices=len(x),tetrahedra=len(t),expected_volume_m3=expected*R**3,
       volume_m3=float(v.sum()*R**3),volume_error=float(abs(v.sum()/expected-1)),minimum_tet_volume_m3=float(v.min()*R**3),positive_tets=bool(np.all(v>0)))
    result['usable']=result['positive_tets'] and result['volume_error']<1e-8
    save(OUT/f'{name}-mesh.json',result)
def stock_files(name,x,t):
    m,cuts,outer,boundary,stats=dual_cells(x,t)
    csvout(OUT/f'{name}-stocks.csv',['id','x_m','y_m','z_m','volume_m3'],[[i,*(p*R),v*R**3] for i,(p,v) in enumerate(zip(x,m))])
    csvout(OUT/f'{name}-cuts.csv',['stock_i','stock_j','area_x_m2','area_y_m2','area_z_m2','area_m2','tet_pieces','oriented_moment_m3'],[[int(r[0]),int(r[1]),*(r[2:5]*R**2),r[5]*R**2,int(r[6]),r[7]*R**3] for r in cuts])
    csvout(OUT/f'{name}-boundary.csv',['stock','area_x_m2','area_y_m2','area_z_m2','area_m2','oriented_moment_m3'],[[int(r[0]),*(r[1:4]*R**2),r[4]*R**2,r[5]*R**3] for r in outer])
    csvout(OUT/f'{name}-vertices.csv',['id','x_over_R','y_over_R','z_over_R'],[[i,*p] for i,p in enumerate(x)])
    csvout(OUT/f'{name}-tets.csv',['id','v0','v1','v2','v3'],[[i,*p] for i,p in enumerate(t)])
    csvout(OUT/f'{name}-surface.csv',['id','v1','v2','v3'],[[i,*p] for i,p in enumerate(boundary)])
    return m,stats
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--worker',nargs=5);args=ap.parse_args()
    OUT.mkdir(exist_ok=True);LOG.mkdir(parents=True,exist_ok=True)
    if args.worker:
        name,n,spread,label,switches=args.worker;worker(name,int(n),float(spread),label,switches);return
    inputs=[(7,.02,'final'),(7,.01,'final'),(4,.02,'initial')]
    paths=[Path(__file__),ROOT/'foam/scripts/liquid_control_volume.py',ROOT/'foam/docs/liquid_volume_protocol.md']
    for n,s,l in inputs:paths+=load_surface(n,s,l)[-1]
    save(OUT/'protocol.json',dict(scope='fixed actual connected liquid volume; passive tracer only',R_m=R,D_m2_s=D,cstar_mol_m3=CSTAR,training=False,
        python=platform.python_version(),packages={k:version(k) for k in ['numpy','scipy','meshpy']},sources={str(p.relative_to(ROOT)):sha(p) for p in paths}))
    meshes=[];usable={};t0=time.perf_counter()
    for n,s,l in inputs:
        stem=f'liquid{n}-s{int(s*1000):03d}'
        for switches,suffix in [('pfn','default'),('pMfn','preserved')]:
            name=stem+'-'+suffix;cmd=[sys.executable,str(Path(__file__).resolve()),'--worker',name,str(n),str(s),l,switches]
            start=time.perf_counter();p=subprocess.run(cmd,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=60)
            (LOG/f'{name}.txt').write_bytes(p.stdout)
            file=OUT/f'{name}-mesh.json'
            r=json.loads(file.read_text()) if p.returncode==0 and file.exists() else dict(name=name,usable=False,returncode=p.returncode)
            r['elapsed_seconds']=time.perf_counter()-start;meshes.append(r)
            if suffix=='preserved' and r['usable']:usable[(n,s)]=name
    cases=[('seven-main',7,.02,5000,False,False),('seven-half',7,.02,2500,False,False),
           ('seven-uniform',7,.02,5000,True,False),('seven-refined',7,.02,5000,False,True),
           ('seven-thin',7,.01,5000,False,False),('four-initial',4,.02,5000,False,False)]
    runs=[];cache={};finals={};parents=None
    for name,n,s,dt,uniform,refined in cases:
        if (n,s) not in usable:runs.append(dict(name=name,skipped='input mesh failed'));continue
        z=np.load(OUT/(usable[(n,s)]+'.npz'));x=z['points'];t=z['tets']
        if refined:x,t,parents=refine(x,t);np.savez_compressed(OUT/'refinement-parent.npz',parent=parents)
        key=(n,s,refined)
        if key not in cache:cache[key]=stock_files(name,x,t)
        m,geometry=cache[key]
        dry=ROOT/f'results/free-wet-conditioned/free{n}-level2-network.json';gg=json.loads(dry.read_text())
        with (dry.parent/f'free{n}-level2-vertices.csv').open() as f:verts={int(r['id']):np.array([float(r[k]) for k in ['x_over_R','y_over_R','z_over_R']]) for r in csv.DictReader(f)}
        seed=sorted([verts[q['vertex']] for q in gg['junctions']],key=lambda q:tuple(q))[0]
        start=time.perf_counter();frames,h,ostats=evolve(x,t,m,seed,dt,uniform=uniform)
        csvout(OUT/f'{name}-history.csv',list(h[0]),[list(r.values()) for r in h])
        # Store every actual computed state, with no interpolation.
        csvout(OUT/f'{name}-frames.csv',['step','node','c_over_cstar'],[[k,i,v] for k,row in enumerate(frames) for i,v in enumerate(row)])
        gates=dict(dual_volume=geometry['dual_volume_rebuild_error']<1e-8,dual_closure=geometry['dual_area_closure']<1e-9,
           positive=all(q['minimum_c_over_cstar']>0 for q in h),amount=max(q['amount_relative_error'] for q in h)<1e-10,
           quadratic_ledger=max(q['energy_ledger_relative_error'] for q in h)<1e-8,
           linear=max(q['linear_relative_residual'] for q in h)<1e-9,
           uniform=float(max(abs(frames[-1]-1)))<1e-12 if uniform else True)
        runs.append(dict(name=name,cells=n,spread=s,dt_s=dt,steps=len(h)-1,uniform=uniform,refined=refined,
            geometry_file_prefix=next(q[0] for q in cases if (q[1],q[2],q[5])==key),
            geometry=geometry,operator=ostats,gates=gates,elapsed_seconds=time.perf_counter()-start,
            seed_over_R=seed.tolist(),final=h[-1],maximum_amount_error=max(q['amount_relative_error'] for q in h),
            maximum_energy_ledger_error=max(q['energy_ledger_relative_error'] for q in h)))
        finals[name]=(frames[-1],m)
    comparisons={}
    if all(k in finals for k in ['seven-main','seven-half','seven-refined']):
        base,m=finals['seven-main'];half,_=finals['seven-half'];fine,mf=finals['seven-refined']
        def centered(c,m):return c-np.dot(m,c)/m.sum()
        def relative(a,b,m):return float(np.sqrt(np.dot(m,(a-b)**2)/np.dot(m,b*b)))
        comparisons['half_time_field_relative']=relative(centered(base,m),centered(half,m),m)
        prolong=centered(base,m)[parents].mean(1)
        comparisons['space_field_relative']=relative(prolong,centered(fine,mf),mf)
        comparisons['time_1pct_pass']=comparisons['half_time_field_relative']<.01
        comparisons['space_1pct_pass']=comparisons['space_field_relative']<.01
    save(OUT/'summary.json',dict(meshes=meshes,runs=runs,comparisons=comparisons,elapsed_seconds=time.perf_counter()-t0))
    print(json.dumps(dict(meshes=meshes,runs=[{k:r.get(k) for k in ['name','gates','maximum_amount_error','maximum_energy_ledger_error']} for r in runs],comparisons=comparisons),indent=2))
if __name__=='__main__':main()
