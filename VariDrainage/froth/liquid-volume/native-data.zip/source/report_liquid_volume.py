"""White saved-state control-volume report; no interpolation or fake motion."""
from pathlib import Path
import csv,hashlib,json,zipfile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from liquid_control_volume import ROOT
OUT=ROOT/'results/liquid-volume';BLUE='#3b6da8';RED='#c44e52'
def read(name):return np.loadtxt(OUT/name,delimiter=',',skiprows=1,ndmin=2)
def main():
    s=json.loads((OUT/'summary.json').read_text());audit=json.loads((OUT/'independent-audit.json').read_text());runs=s['runs']
    stocks=read('seven-main-stocks.csv');x=stocks[:,1:4]*1000;frames=read('seven-main-frames.csv')[:,2].reshape(21,len(x))
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
    fig=plt.figure(figsize=(13,8.5),facecolor='white');gs=fig.add_gridspec(2,3,height_ratios=[1.3,1],hspace=.36,wspace=.32)
    norm=Normalize(1,float(frames.max()));cmap=plt.get_cmap('coolwarm');center=(x.max(0)+x.min(0))/2;h=np.ptp(x,axis=0).max()*.55
    for j,k in enumerate([0,10,20]):
        ax=fig.add_subplot(gs[0,j],projection='3d');pc=ax.scatter(*x.T,c=frames[k],cmap=cmap,norm=norm,s=9,depthshade=False,edgecolors='none')
        ax.set(xlim=(center[0]-h,center[0]+h),ylim=(center[1]-h,center[1]+h),zlim=(center[2]-h,center[2]+h));ax.set_box_aspect((1,1,1));ax.set_axis_off();ax.view_init(22,32);ax.set_title(f'Actual liquid nodes · {k*5000/3600:.2f} h')
    cb=fig.colorbar(pc,ax=fig.axes[:3],fraction=.018,pad=.01,label='Passive bulk c / c*');cb.solids.set_rasterized(False)
    ax=fig.add_subplot(gs[1,0])
    for name,col,ls in [('seven-main',BLUE,'-'),('seven-half',BLUE,':'),('seven-refined',RED,'-')]:
        with (OUT/f'{name}-history.csv').open() as f:hist=list(csv.DictReader(f))
        E=np.array([float(q['quadratic_energy_nd']) for q in hist]);ax.plot([float(q['time_s'])/3600 for q in hist],E/E[0],ls,color=col,label=name.replace('seven-',''))
    ax.set(xlabel='Tracer diffusion time / h',ylabel='Quadratic functional / initial');ax.legend(fontsize=9)
    ax=fig.add_subplot(gs[1,1]);v=[s['comparisons'][k]*100 for k in ['half_time_field_relative','space_field_relative']];ax.bar(['half time','red refinement'],v,color=[BLUE,RED]);ax.axhline(1,color='#777',ls='--');ax.set(ylabel='Mean-subtracted field difference / %',title='Both exceed the 1% target')
    for i,q in enumerate(v):ax.text(i,q+.25,f'{q:.2f}%',ha='center')
    ax=fig.add_subplot(gs[1,2]);ax.axis('off');ax.text(0,1,'Accepted seven-body references',weight='bold',va='top',fontsize=12)
    ax.text(0,.83,'472 stocks / 1,838 shared cuts\nRefined: 2,310 stocks\n\nAmount error ≤ 4.74e-13\nIndependent dual/element audits pass',va='top',linespacing=1.6,color=BLUE)
    ax.text(0,.25,'Four-body initial mesh: FAILED\nNear-degenerate tetrahedra\nAmount error 0.519%; retained.',va='top',linespacing=1.5,color=RED)
    fig.suptitle('A connected liquid network with actual finite inventories',fontsize=18,x=.06,ha='left',y=.98)
    fig.text(.06,.02,'Passive closed-domain bulk diffusion only. Fixed geometry; no drainage, surfactant feedback, gas exchange or rupture.',fontsize=9,color='#555')
    fig.savefig(OUT/'liquid-volume.png',dpi=180,bbox_inches='tight',facecolor='white');fig.savefig(OUT/'liquid-volume.pdf',bbox_inches='tight',facecolor='white');plt.close(fig)
    table=''
    for r in runs:
        fail=', '.join(k for k,v in r['gates'].items() if not v) or '通过'
        table+=f'<tr><td>{r["name"]}</td><td>{r["steps"]}</td><td>{r["geometry"]["stock_count"]}</td><td>{r["maximum_amount_error"]:.3g}</td><td>{fail}</td></tr>'
    html='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>FROTH · 实际液体控制体</title><style>:root{color-scheme:light}*{box-sizing:border-box}body{margin:0;background:#fff;color:#21303f;font:16px/1.75 system-ui,sans-serif}main{max-width:1120px;margin:auto;padding:34px 22px}h1{font-size:clamp(28px,4vw,46px);line-height:1.25}h2{margin-top:38px}a{color:#3b6da8}img{display:block;width:100%;height:auto}.tag{color:#c44e52;font-weight:700}.note{border-left:4px solid #c44e52;background:#faf5f5;padding:18px}.table{overflow:auto}table{border-collapse:collapse;width:100%;font-size:14px}th,td{padding:9px;text-align:left;border-bottom:1px solid #ddd;white-space:nowrap}.viewer{max-width:700px;margin:auto}canvas{display:block;background:#fff;border:1px solid #e0e5ea;width:100%;aspect-ratio:1;touch-action:none}input{width:100%;accent-color:#3b6da8}.muted{color:#596878;font-size:14px}</style><main>
    <a href="../index.html">← FROTH</a><p class="tag">ACTUAL FINITE VOLUMES · PASSIVE TRACER REFERENCE</p><h1>液体库存来自真实三维几何</h1><p>七泡的连通液体区域已被划为 472 个有限控制体、1,838 个共享截面；一次加密后为 2,310 个控制体。每份体积来自实际四面体与重心对偶几何，未使用“边界长度 × 经验截面积”补算库存。</p>
    <div class="note">完成六组、140 步固定域扩散诊断。七泡五组通过本轮离散收支检查；时间／空间场差异 1.27%／9.77%，仍不收敛到预定 1% 目标。四泡初始几何因近退化四面体失效，约 0.519% 的量误差已保留。这一步尚未接液体排流、表活、粗化或破裂。</div>
    <img src="liquid-volume.png" width="2340" height="1530" alt="七泡实际液体控制体浓度、时间与空间差异和失败记录"><p><a href="liquid-volume.png">PNG</a> · <a href="liquid-volume.pdf">矢量 PDF</a></p>
    <h2>播放实际保存的浓度</h2><p class="muted">拖动旋转；滑块只切换实际求解保存的 21 帧，没有时间插值。红蓝标尺固定为初始全局范围；圆点是实际库存节点，并非构造的气泡外观。物理示踪剂扩散跨度约 27.78 小时，实际 CPU 计算约 11 秒，无训练任务。</p><div class="viewer"><canvas aria-label="七泡实际库存节点和示踪剂浓度"></canvas><input aria-label="保存状态" id="frame" type="range" min="0" max="20" step="1" value="0"><p id="label"></p></div>
    <h2>实验矩阵与未通过项</h2><div class="table"><table><thead><tr><th>算例</th><th>步数</th><th>控制体</th><th>最大相对量误差</th><th>未通过检查</th></tr></thead><tbody>TABLE</tbody></table></div>
    <h2>独立几何与方程审计</h2><p>逐面输出体积矩和有向面积，从保存的共享面、外表面重建每个控制体。七泡重建体积最大相对差约 6.18e−10，面积闭合约 3.3e−14；删除一个共享面会被检查检出。另用完整仿射矩阵重新构造单元梯度，审计保存的扩散耗散、逐节点方程及总量。七泡五组通过，四泡独立审计也判为失败。</p>
    <p>正式网格给每个输入三角面独立标记；带标记的默认与禁止共面合并方案在本次生成相同的网格。去掉标记的独立错误对照产生 1.102% 的体积偏差，被 1e−8 几何门槛拒绝，没有进入扩散计算。因此不能把成功归因于单独调整某一个开关。</p>
    <h2>方法边界与下一步</h2><p>采用质量集中的线性有限元扩散；浓度为被动体相示踪剂，未把它当作已经接入 Marangoni 反馈的表面活性剂。七泡主网格约 29.2%、加密网格约 33.7% 的非对角刚度项为正，故不具一般离散最大值原理保证。当前浓度均保持正值，二次耗散检查通过，但不能据此声称任意状态均单调或非线性热力学闭合。</p>
    <p>共享几何截面是真实的；有限元交换仍是弱形式通量，不是独立测得的截面法向流量。此前干泡受力残差和四泡湿几何警告仍未消失。下一步需要连接有物理界面条件的膜／边界输运与气体交换，并保留有限速事件的实际接收库存。</p>
    <h2>来源与完整数据</h2><p><a href="summary.json">六组结果与全部门槛</a> · <a href="protocol.json">冻结协议与源文件哈希</a> · <a href="independent-audit.json">独立审计和错误对照</a> · <a href="native-data.zip">完整原始数据／日志／源码 ZIP</a></p><p><a href="seven-main-stocks.csv">库存 CSV</a> · <a href="seven-main-cuts.csv">共享截面 CSV</a> · <a href="seven-main-frames.csv">实际状态 CSV</a> · <a href="four-initial-history.csv">四泡失败历史</a> · <a href="negative-unmarked.json">未标记网格错误对照</a></p>
    <p class="muted">现成工具：<a href="https://documen.tician.de/meshpy/tri-tet.html">MeshPy / TetGen</a>；<a href="https://www.wias-berlin.de/software/tetgen/switches.html">TetGen PLC 与共面合并开关</a>。重心对偶、守恒账目与有限元扩散均为既有数值技术，本阶段不主张它们本身的新颖性。</p></main>
    <script>const data=DATA;let frame=0,yaw=.55,pitch=.35,drag=false,last;const canvas=document.querySelector('canvas'),ctx=canvas.getContext('2d'),slider=document.querySelector('#frame'),label=document.querySelector('#label'),center=[0,1,2].map(k=>(Math.max(...data.x.map(v=>v[k]))+Math.min(...data.x.map(v=>v[k])))/2),span=Math.max(...[0,1,2].map(k=>Math.max(...data.x.map(v=>v[k]))-Math.min(...data.x.map(v=>v[k]))));
    function draw(){canvas.width=Math.round(canvas.clientWidth*devicePixelRatio);canvas.height=canvas.width;let w=canvas.width;ctx.fillStyle='#fff';ctx.fillRect(0,0,w,w);const pts=data.x.map((v,i)=>{let [x,y,z]=v.map((q,k)=>(q-center[k])/span),a=Math.cos(yaw)*x-Math.sin(yaw)*y,b=Math.sin(yaw)*x+Math.cos(yaw)*y;return [w*(.5+.8*a),w*(.5-.8*(Math.cos(pitch)*z-Math.sin(pitch)*b)),Math.sin(pitch)*z+Math.cos(pitch)*b,i]}).sort((a,b)=>a[2]-b[2]);for(const [x,y,z,i]of pts){let f=Math.max(0,Math.min(1,(data.frames[frame][i]-1)/(data.max-1))),rgb=[59,109,168].map((v,k)=>Math.round(v+f*([196,78,82][k]-v)));ctx.fillStyle='rgb('+rgb.join(',')+')';ctx.beginPath();ctx.arc(x,y,Math.max(1.2,2.6*devicePixelRatio),0,2*Math.PI);ctx.fill()}label.textContent='保存帧 '+frame+' / 20 · 扩散时间 '+(frame*5000/3600).toFixed(2)+' h · c/c* 范围 '+Math.min(...data.frames[frame]).toFixed(5)+' – '+Math.max(...data.frames[frame]).toFixed(5)}
    slider.oninput=()=>{frame=+slider.value;draw()};canvas.onpointerdown=e=>{drag=true;last=[e.clientX,e.clientY];canvas.setPointerCapture(e.pointerId)};canvas.onpointermove=e=>{if(drag){yaw+=(e.clientX-last[0])*.01;pitch+=(e.clientY-last[1])*.01;last=[e.clientX,e.clientY];draw()}};canvas.onpointerup=()=>drag=false;new ResizeObserver(draw).observe(canvas);draw();</script></html>'''
    html=html.replace('TABLE',table).replace('DATA',json.dumps(dict(x=x.tolist(),frames=frames.tolist(),max=float(frames.max())),separators=(',',':')))
    (OUT/'index.html').write_text(html,encoding='utf8')
    readout={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),ROOT/'foam/scripts/audit_liquid_volume.py']}
    (OUT/'readout-provenance.json').write_text(json.dumps(readout,indent=2),encoding='utf8')
    with zipfile.ZipFile(OUT/'native-data.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in OUT.iterdir():
            if p.suffix in ['.csv','.json','.npz']:z.write(p,p.name)
        for p in (ROOT/'results/logs/liquid-volume').iterdir():z.write(p,'logs/'+p.name)
        for p in [ROOT/'foam/scripts/liquid_control_volume.py',ROOT/'foam/scripts/run_liquid_volume.py',ROOT/'foam/scripts/audit_liquid_volume.py',ROOT/'foam/scripts/report_liquid_volume.py',ROOT/'foam/docs/liquid_volume_protocol.md']:z.write(p,'source/'+p.name)
    print('Saved-state report, PNG/vector PDF and data archive written')
if __name__=='__main__':main()
