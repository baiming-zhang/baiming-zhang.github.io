"""Independent saved dual-face / element diffusion audit; unmarked mesh control."""
from pathlib import Path
import argparse,csv,hashlib,json,subprocess,sys
import numpy as np
import meshpy.tet as tet
from liquid_control_volume import ROOT,R,D,CSTAR,load_surface
OUT=ROOT/'results/liquid-volume';LOG=ROOT/'results/logs/liquid-volume'
def save(p,x):p.write_text(json.dumps(x,indent=2),encoding='utf8')
def read(name):return np.loadtxt(OUT/name,delimiter=',',skiprows=1,ndmin=2)
def dual(prefix):
    stocks=read(prefix+'-stocks.csv');cuts=read(prefix+'-cuts.csv');outer=read(prefix+'-boundary.csv');n=len(stocks)
    v=np.zeros(n);av=np.zeros((n,3));area=np.zeros(n)
    for row in cuts:
        i,j=map(int,row[:2]);v[i]+=row[7];v[j]-=row[7];av[i]+=row[2:5];av[j]-=row[2:5];area[[i,j]]+=row[5]
    for row in outer:
        i=int(row[0]);av[i]+=row[1:4];area[i]+=row[4];v[i]+=row[5]
    volume_error=float(max(abs(v/stocks[:,4]-1)));closure=float(max(np.linalg.norm(av,axis=1)/area))
    damaged=av.copy();row=cuts[np.argmax(cuts[:,5])];damaged[int(row[0])]-=row[2:5];damaged[int(row[1])]+=row[2:5]
    return dict(volume_error=volume_error,area_closure=closure,unique_shared_cuts=len({tuple(map(int,r[:2])) for r in cuts})==len(cuts),
       omitted_cut_detected=float(max(np.linalg.norm(damaged,axis=1)/area))>1e-9,
       passed=bool(volume_error<1e-8 and closure<1e-9))
def diffusion(run):
    name=run['name'];prefix=run['geometry_file_prefix'];stocks=read(prefix+'-stocks.csv');x=stocks[:,1:4]/R;m=stocks[:,4]/R**3;t=read(prefix+'-tets.csv')[:,1:].astype(int)
    frames=read(name+'-frames.csv')[:,2].reshape(run['steps']+1,len(x));z=frames-1
    # Different gradient construction: inverse of full affine [1,x,y,z] matrix.
    p=x[t];B=np.concatenate([np.ones((len(t),4,1)),p],axis=2)
    grad=np.linalg.inv(B)[:,1:,:].transpose(0,2,1)
    vol=np.linalg.det(p[:,1:]-p[:,0,None])/6;dtnd=run['dt_s']*D/R**2
    errors=[];linear=[];amount=[]
    E0=float(.5*np.dot(z[0],m*z[0]))
    for k in range(1,len(z)):
        g=np.einsum('ti,tij->tj',z[k,t],grad);diss=float(np.dot(vol,np.sum(g*g,axis=1))*dtnd)
        change=float(.5*np.dot(z[k],m*z[k])-.5*np.dot(z[k-1],m*z[k-1]));loss=float(.5*np.dot(z[k]-z[k-1],m*(z[k]-z[k-1])))
        errors.append(abs(change+loss+diss)/max(E0,1e-300))
        nodal=np.zeros(len(x));local=dtnd*vol[:,None]*np.einsum('tij,tj->ti',grad,g)
        np.add.at(nodal,t.ravel(),local.ravel());balance=m*(z[k]-z[k-1])+nodal
        linear.append(float(np.linalg.norm(balance)/max(np.linalg.norm(m*z[k-1]),1e-300)))
        amount.append(float(abs(np.dot(m,frames[k])/np.dot(m,frames[0])-1)))
    return dict(maximum_element_energy_error=max(errors),maximum_element_balance_error=max(linear),maximum_saved_amount_error=max(amount),
                passed=bool(max(errors)<1e-8 and max(linear)<1e-8 and max(amount)<1e-10))
def negative_unmarked():
    x,f,_,expected,_=load_surface(7,.02,'final');info=tet.MeshInfo();info.set_points(x.tolist());info.set_facets(f.tolist())
    mesh=tet.build(info,options=tet.Options('pfn'),verbose=True);x=np.array(mesh.points);t=np.array(mesh.elements);p=x[t];v=np.linalg.det(p[:,1:]-p[:,0,None])/6
    np.savez_compressed(OUT/'negative-unmarked.npz',points=x,tets=t)
    save(OUT/'negative-unmarked.json',dict(input_facet_markers=False,switches='pfn',tetrahedra=len(t),volume_error=float(abs(v.sum()/expected-1)),
          geometry_gate_rejects=bool(abs(v.sum()/expected-1)>=1e-8),scope='one unmarked geometry control; no diffusion'))
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--unmarked',action='store_true');a=ap.parse_args()
    if a.unmarked:negative_unmarked();sys.exit(0)
    if not (OUT/'negative-unmarked.json').exists():
        p=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--unmarked'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=60)
        (LOG/'negative-unmarked.txt').write_bytes(p.stdout)
        if p.returncode:raise RuntimeError('unmarked control failed; see native log')
    summary=json.loads((OUT/'summary.json').read_text());audits=[]
    for r in summary['runs']:
        try:diff=diffusion(r)
        except Exception as e:diff=dict(passed=False,error=f'{type(e).__name__}: {e}')
        d=dual(r['geometry_file_prefix']);accepted=all(r['gates'].values())
        audits.append(dict(name=r['name'],accepted_discrete_run=accepted,dual=d,diffusion=diff,passed=d['passed'] and diff['passed']))
    protocol=json.loads((OUT/'protocol.json').read_text());provenance=[dict(source=k,matched=hashlib.sha256((ROOT/k).read_bytes()).hexdigest()==v) for k,v in protocol['sources'].items()]
    result=dict(audits=audits,negative_unmarked=json.loads((OUT/'negative-unmarked.json').read_text()),provenance=provenance,
          accepted_run_audits_pass=all(r['passed'] for r in audits if r['accepted_discrete_run']),
          scope='saved dual cuts and independently assembled affine-element gradients; not normal-flow or physical validation')
    save(OUT/'independent-audit.json',result)
    print(json.dumps(result,indent=2))
