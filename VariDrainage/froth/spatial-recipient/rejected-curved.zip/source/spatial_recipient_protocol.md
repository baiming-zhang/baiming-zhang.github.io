# Local liquid recipient on the actual seven-bubble scene

Frozen before new seven-bubble retraction/response, 2026-11-13. The original
drainage--coarsening--finite-speed rupture objective remains incomplete.

## Why seven bubbles now

The archived four-bubble mesh contains a nearly coplanar tetrahedron with
condition1.64e15. One bounded semantic gas-marker TetGen attempt removes that
defect but loses.2308% native liquid volume and is REJECTED. Keep its input,
output and failed audit. Do not smooth/move the native surface or search mesh
parameters indefinitely. Use the existing independently volume-audited actual
wet7-s020/final liquid mesh (472vertices/934tets), same as the actual gas/shape
scene. Recompute a SEVEN-bubble first-contact packet; never reuse the four-bubble
packet at a different location. Original CODA owner code/executable unchanged.

## Event and geometric receiving closure

Use the actual gas[1,2] shared film, its area-normal planar projection, initially
open hole,24 rim nodes and five red refinements per native triangle, as in the
previous declared planar diagnostic. rho1000kg/m3,h.8um,gamma.03N/m,
Gamma1e-6mol/m2/interface,CFL.15 plus native half-time control. No imposed speed.
Retraction stops at first contact. Report planar error and packet sensitivities.

Local volume receiving is a deliberately UNCALIBRATED closure: choose the
actual liquid boundary triangle nearest the incoming packet centre. Attach ONE
outward tetrahedral cap on that triangle, with height3*sum(m)/(rho*A), so that
its volume is exactly incoming liquid volume. Preserve all original liquid
tetrahedra; replace only that exposed triangle by the three cap faces. Reject
positive-volume intersection of the cap with existing liquid tetrahedra.
The entire facet is a coarse contact footprint, not a resolved physical rim
collision. Report footprint/packet radius, cap height and displacement of its
COM from incoming mass centre. Do not claim microscopic contact prediction.
All received tagged amount enters the cap BULK inventory; newly exposed skin
has constant diagnostic gamma and no instant adsorption. No amount disappears.

Mass-lump actual rho*Vtet/4, including the added cap; add finite h0 film masses
on the SAME nodes where native films meet the liquid skin. Exclude the initiating
rupturing sheet from subsequent dynamics, keeping its unadvanced remainder
explicitly recorded. Local receiving support is the cap and original tetrahedra
incident to its base vertices. Minimize kinetic energy on that support subject
to the actual incoming linear AND orbital angular impulse. Then perform a
mass-orthogonal incompressible velocity projection. Report inelastic loss and
reject kinetic energy larger than incoming energy. Surface-energy difference
of the cap is separate; cylindrical-rim surface energy is only a declared
geometric estimate, not a verified total event-energy closure.

## Spatial liquid and film mechanics

Lagrangian linear tetrahedral fluid with one exact material-volume constraint
per tetrahedron; no elastic shear energy. Full nonlinear capillary area energy
on the liquid boundary, gamma per single interface. Remaining actual films use
the previous full-area dilute INSOLUBLE reference energy, fixed material liquid
volume and two-interface amount, h=V/A and Gamma=S/(2A). No viscosity, diffusion,
adsorption, disjoining pressure, gravity, gas pressure or air inertia in this
early inviscid response limit. This is not a stable/converged general-purpose
Navier--Stokes discretization: P1/P0 constraint rank/conditioning and potential
locking must be reported. Rigid and trace-free affine null-mode checks alone
are not spatial or physical validation. Reject singular pressure projection;
do not add a hidden pressure penalty or artificial shear stiffness.

Use explicit capillary forces and RATTLE exact-volume constraints. Position
constraint directions use gradients at OLD positions; velocity projection uses
new positions, preserving linear/angular impulse up to solver tolerance. Exact
geometric volume and full physical momenta are audited independently.
As before, explicit LAB-FIXED preload=initial area-energy gradient holds the
nonequilibrated POST-receiving geometry at rest. Record its conservative work
and angular input. This remains a supported experiment, not autonomous foam.

Freeze a0.2ms response horizon; choose main dt<=1us and dt*omega_bound<=.1
from the initial area-gradient mass/stiffness upper diagnostic. Round step
count UP to a multiple40; half doubles it. Save41 common-time actual states.
FOUR cases only: locally received/projected impulse, same initial velocity with
half dt, whole-liquid rigidly mixed INITIAL velocity, zero-impulse external
sink. The last two retain the SAME cap geometry/mass/amount and surface law.
Global initial mixing conserves P/L but erases nonrigid receiving energy into
an explicit additional loss. It does not keep the liquid rigid during evolution.
No prescribed subsequent holes, rupture order, contact times or wave speed.

## Gates

Native volume/reference<1e-8; appended cap volume<1e-10 relative packet volume;
no positive tet intersections. Initial constraint solve relative residual<1e-8,
rigid/trace-free affine tangent modes<1e-10. Full pressure system has no hidden
regularization. Directional force gradient<1e-6 on this actual scene.
Dynamic per-tet volume relative<1e-9, no inversion/nonfinite state, positive
film gamma/h. True P and L plus preload impulse relative<1e-6, energy relative
RECEIVED post-inelastic energy<1%. Report all observed failures. Check half-time
nonzero displacement/film-thickness increment fields against1%, not just the
large background h. No spatial convergence/experimental validation claim.
Each progress report includes liquid, tagged amount, gas=N/A, P,L and energy.

## Primary context

TetGen official manual https://www.wias-berlin.de/software/tetgen/1.5/doc/manual/manual005.html
explains facet/quality/tolerance behaviour. Bussonniere--Cantat JFM922A25
https://arxiv.org/pdf/2011.13658 establishes interface elasticity and local
meniscus transfer/shear as precedents; those viscous/adsorption terms remain
missing here. Saye--Sethian JCP2016 https://doi.org/10.1016/j.jcp.2016.02.077
already redistributes liquid conservatively through rearrangement/rupture.
Do not claim novelty for tetrahedra, volume constraints, RATTLE or mass transfer.
The candidate contribution still requires tested finite-speed local event
feedback on drainage/coarsening-generated states and continuing topology.
