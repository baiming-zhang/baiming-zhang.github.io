"""Actual barycentric liquid inventories / fixed-domain variational tracer."""
from pathlib import Path
from collections import defaultdict
from itertools import combinations
import csv,json
import numpy as np
from scipy.sparse import coo_matrix,diags
from scipy.sparse.linalg import splu
import meshpy.tet as tet

ROOT=Path(__file__).resolve().parents[2];R=.01;D=5e-10;CSTAR=.002

def load_surface(n,spread,label):
    name=f'wet{n}-s{int(spread*1000):03d}';folder=ROOT/'results/free-wet-conditioned'
    vp=folder/f'{name}-{label}-vertices.csv';fp=folder/f'{name}-{label}-triangles.csv'
    with vp.open() as f:vertices={int(r['id']):[float(r[k]) for k in ['x_over_R','y_over_R','z_over_R']] for r in csv.DictReader(f)}
    with fp.open() as f:rows=[r for r in csv.DictReader(f) if n+1 in [int(r['front_body']),int(r['back_body'])]]
    ids=sorted({int(r[k]) for r in rows for k in ['v1','v2','v3']});lookup={v:i for i,v in enumerate(ids)}
    x=np.array([vertices[v] for v in ids]);faces=[];gas=[]
    for r in rows:
        tri=[lookup[int(r[k])] for k in ['v1','v2','v3']];front=int(r['front_body']);back=int(r['back_body'])
        faces.append(tri if front==n+1 else tri[::-1]);gas.append(back if front==n+1 else front)
    summary=json.loads((folder/'summary.json').read_text());run=next(r for r in summary['runs'] if r['name']==name)
    snap=next(s for s in run['snapshots'] if s['label']==label)
    return x,np.array(faces),np.array(gas),snap['liquid_volume_m3']/R**3,[vp,fp,folder/'summary.json']

def tetrahedralize(x,faces,switches):
    info=tet.MeshInfo();info.set_points(x.tolist());info.set_facets(faces.tolist(),markers=list(range(1,len(faces)+1)))
    mesh=tet.build(info,options=tet.Options(switches),verbose=True)
    return np.array(mesh.points),np.array(mesh.elements,dtype=int),np.array(mesh.faces,dtype=int),np.array(mesh.face_markers,dtype=int)

def volumes(x,t):
    p=x[t];return np.linalg.det(p[:,1:]-p[:,0,None])/6

def refine(x,t):
    points=list(x);edge={};parent=[(i,i) for i in range(len(x))];result=[]
    def mid(a,b):
        key=tuple(sorted([int(a),int(b)]))
        if key not in edge:
            edge[key]=len(points);points.append((x[a]+x[b])/2);parent.append(key)
        return edge[key]
    for a,b,c,d in t:
        ab,ac,ad,bc,bd,cd=[mid(i,j) for i,j in [(a,b),(a,c),(a,d),(b,c),(b,d),(c,d)]]
        result.extend([(a,ab,ac,ad),(ab,b,bc,bd),(ac,bc,c,cd),(ad,bd,cd,d),
                       (ab,cd,ac,ad),(ab,cd,ad,bd),(ab,cd,bd,bc),(ab,cd,bc,ac)])
    x=np.array(points);t=np.array(result);negative=volumes(x,t)<0;t[negative,:2]=t[negative,1::-1]
    return x,t,np.array(parent)

def poly_geometry(p):
    # Oriented quadrilateral; sum two triangles, without assuming orthogonality.
    av=np.cross(p[1]-p[0],p[2]-p[0])/2+np.cross(p[2]-p[0],p[3]-p[0])/2
    area=np.linalg.norm(np.cross(p[1]-p[0],p[2]-p[0]))/2+np.linalg.norm(np.cross(p[2]-p[0],p[3]-p[0]))/2
    return av,float(area)

def dual_cells(x,t):
    nv=len(x);mass=np.zeros(nv);rebuilt=np.zeros(nv);closure=np.zeros((nv,3));areas=np.zeros(nv)
    shared={};faces=defaultdict(list);outer=[]
    for ids in t:
        p=x[ids];center=p.mean(0);vol=float(np.linalg.det(p[1:]-p[0]))/6;mass[ids]+=vol/4
        for i,j in combinations(range(4),2):
            k,l=[q for q in range(4) if q not in [i,j]]
            a,b=sorted([int(ids[i]),int(ids[j])]);poly=np.array([(x[a]+x[b])/2,(p[i]+p[j]+p[k])/3,center,(p[i]+p[j]+p[l])/3])
            av,area=poly_geometry(poly)
            if av@(x[b]-x[a])<0:poly=poly[::-1];av=-av
            closure[a]+=av;closure[b]-=av;areas[[a,b]]+=area
            for node,sgn in [(a,1),(b,-1)]:
                q=poly-x[node];rebuilt[node]+=sgn*(np.linalg.det(q[[0,1,2]])+np.linalg.det(q[[0,2,3]]))/6
            if (a,b) not in shared:shared[(a,b)]=[np.zeros(3),0.,0,0.]
            shared[(a,b)][0]+=av;shared[(a,b)][1]+=area;shared[(a,b)][2]+=1
            shared[(a,b)][3]+=(np.linalg.det(poly[[0,1,2]])+np.linalg.det(poly[[0,2,3]]))/6
        for omitted in range(4):
            f=tuple(sorted(int(ids[j]) for j in range(4) if j!=omitted));faces[f].append(int(ids[omitted]))
    boundary=[]
    for f,opposite in faces.items():
        if len(opposite)==2:continue
        if len(opposite)!=1:raise ValueError('nonmanifold tetrahedral face')
        a,b,c=f;p=x[[a,b,c]]
        if np.cross(p[1]-p[0],p[2]-p[0])@(x[opposite[0]]-p[0])>0:b,c=c,b
        boundary.append([a,b,c]);fc=x[[a,b,c]].mean(0)
        for i,j,k in [(a,b,c),(b,c,a),(c,a,b)]:
            poly=np.array([x[i],(x[i]+x[j])/2,fc,(x[i]+x[k])/2]);av,area=poly_geometry(poly)
            closure[i]+=av;areas[i]+=area
            moment=(np.linalg.det(poly[[0,1,2]])+np.linalg.det(poly[[0,2,3]]))/6
            outer.append([i,*av,area,moment])
    cuts=np.array([[a,b,*v,area,count,moment] for (a,b),(v,area,count,moment) in sorted(shared.items())])
    return mass,cuts,np.array(outer),np.array(boundary),dict(
       minimum_cell_volume_m3=float(mass.min()*R**3),
       dual_volume_rebuild_error=float(max(abs(rebuilt/mass-1))),
       dual_area_closure=float(max(np.linalg.norm(closure,axis=1)/areas)),
       stock_count=nv,shared_cut_count=len(cuts),exterior_patch_count=len(outer))

def operator(x,t):
    p=x[t];q=p[:,1:]-p[:,0,None];vol=np.linalg.det(q)/6
    grad=np.zeros((len(t),4,3));grad[:,1:]=np.linalg.inv(q).transpose(0,2,1);grad[:,0]=-grad[:,1:].sum(1)
    ke=vol[:,None,None]*np.einsum('tij,tkj->tik',grad,grad)
    rows=np.repeat(t,4,axis=1).ravel();cols=np.tile(t,(1,4)).ravel()
    raw=coo_matrix((ke.ravel(),(rows,cols)),shape=(len(x),len(x))).tocsc();raw.sum_duplicates()
    row_sum=np.asarray(raw.sum(axis=1)).ravel();K=raw-diags(row_sum)
    change=float(np.linalg.norm(row_sum)/np.linalg.norm(raw.data));kk=K.tocoo();off=kk.data[kk.row!=kk.col]
    return K,dict(constant_null_diagonal_change_relative=change,positive_offdiagonal_fraction=float(np.mean(off>0)),
                  maximum_positive_offdiagonal=float(max(off.max(),0)))

def evolve(x,t,mass,seed,dt,T=100000.,uniform=False):
    K,ostats=operator(x,t);dtnd=dt*D/R**2;A=diags(mass)+dtnd*K;lu=splu(A.tocsc())
    z=np.zeros(len(x)) if uniform else .2*np.exp(-np.sum((x-seed)**2,axis=1)/.15**2)
    initial=z.copy();initial_amount=float(mass@(1+z));initial_energy=float(.5*np.dot(z,mass*z));history=[];frames=[]
    for step in range(int(round(T/dt))+1):
        if step:
            old=z.copy();Eold=float(.5*np.dot(old,mass*old));rhs=mass*old;z=lu.solve(rhs)
            residual=np.linalg.norm(A@z-rhs)/max(np.linalg.norm(rhs),1e-300)
            loss=float(.5*np.dot(z-old,mass*(z-old)));diss=float(dtnd*z@(K@z));E=float(.5*np.dot(z,mass*z))
            energy_error=abs(E-Eold+loss+diss)/max(initial_energy,1e-300)
        else:residual=loss=diss=energy_error=0.;E=initial_energy
        concentration=1+z;amount=float(mass@concentration)
        history.append(dict(step=step,time_s=step*dt,amount_mol=amount*CSTAR*R**3,
           amount_relative_error=abs(amount/initial_amount-1),minimum_c_over_cstar=float(concentration.min()),
           maximum_c_over_cstar=float(concentration.max()),quadratic_energy_nd=E,
           backward_euler_loss_nd=loss,dt_diffusion_dissipation_nd=diss,energy_ledger_relative_error=energy_error,
           linear_relative_residual=float(residual)))
        frames.append(concentration.copy())
    return np.array(frames),history,ostats
