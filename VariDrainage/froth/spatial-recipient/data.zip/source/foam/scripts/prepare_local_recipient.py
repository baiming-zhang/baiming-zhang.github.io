"""Seven-body actual CODA contact and volume-exact local receiving geometry."""
from collections import Counter,defaultdict
from pathlib import Path
import hashlib,json,subprocess,time
import numpy as np
from scipy.spatial import cKDTree
from gas_shape import ROOT,R,load
from rim_receiver import split,tri_area
OUT=ROOT/'results/spatial-recipient';LOG=ROOT/'results/logs/spatial-recipient'
RHO=1000.;H=.8e-6;GAMMA=.03;TAG=1e-6

def save(p,q):p.write_text(json.dumps(q,indent=2,default=lambda v:v.item()),encoding='utf8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def closest_point(p,tri):
    a,b,c=tri;n=np.cross(b-a,c-a);normal=n/np.linalg.norm(n);point=p-normal*np.dot(p-a,normal)
    B=np.array([b-a,c-a]).T;uv=np.linalg.lstsq(B,point-a,rcond=None)[0]
    if min(uv)>=0 and uv.sum()<=1:return point
    choices=[]
    for a,b in zip(tri,np.roll(tri,-1,axis=0)):
        u=np.clip((p-a)@(b-a)/np.dot(b-a,b-a),0,1);choices.append(a+u*(b-a))
    return min(choices,key=lambda q:np.linalg.norm(q-p))

def separated(tet1,tet2):
    # Separating-axis test: shared faces/edges are permitted, positive volume is not.
    edges=[(i,j) for i in range(4) for j in range(i+1,4)]
    axes=[]
    for t in [tet1,tet2]:
        axes += [np.cross(t[j]-t[i],t[k]-t[i]) for i,j,k in [(0,1,2),(0,1,3),(0,2,3),(1,2,3)]]
    axes += [np.cross(tet1[j]-tet1[i],tet2[l]-tet2[k]) for i,j in edges for k,l in edges]
    for axis in axes:
        norm=np.linalg.norm(axis)
        if norm<1e-30:continue
        axis/=norm;a=tet1@axis;b=tet2@axis;tol=256*np.finfo(float).eps*max(np.ptp(a),np.ptp(b),.01)
        if min(a.max(),b.max())-max(a.min(),b.min())<=tol:return True
    return False

def prepare_contact():
    x,t,front,back,kind,tension,paths=load(7);x*=R
    ranking=[]
    pairs=sorted({tuple(sorted([int(a),int(b)])) for a,b,k in zip(front,back,kind) if k==1 and a and b})
    for pair in pairs:
        mask=(kind==1)&np.array([tuple(sorted([int(a),int(b)]))==pair for a,b in zip(front,back)])
        p=x[t[mask]];A=tri_area(p);C=np.sum(p.mean(1)*A[:,None],axis=0)/A.sum();n=np.sum(np.cross(p[:,1]-p[:,0],p[:,2]-p[:,0]),axis=0);n/=np.linalg.norm(n)
        ranking.append(dict(pair=list(pair),maximum_plane_error_m=float(np.max(abs((x[np.unique(t[mask])]-C)@n)))))
    selected=min(ranking,key=lambda q:(q['maximum_plane_error_m'],q['pair']));pair=selected['pair'];save(OUT/'film-selection.json',dict(rule='minimum maximum native plane deviation, before dynamics',ranking=ranking,selected=selected))
    active=(kind==1)&(((front==pair[0])&(back==pair[1]))|((front==pair[1])&(back==pair[0])));at=t[active];areas=tri_area(x[at])
    center=np.sum(x[at].mean(1)*areas[:,None],axis=0)/areas.sum();normal=np.sum(np.cross(x[at[:,1]]-x[at[:,0]],x[at[:,2]]-x[at[:,0]]),axis=0);normal/=np.linalg.norm(normal)
    counts=Counter(tuple(sorted([int(a),int(b)])) for f in at for a,b in zip(f,np.roll(f,-1)));adj=defaultdict(list)
    for (a,b),count in counts.items():
        if count==1:adj[a].append(b);adj[b].append(a)
    if not adj or not all(len(v)==2 for v in adj.values()):raise ValueError('not one film boundary loop')
    loop=[min(adj)];prev=None;cur=loop[0]
    while True:
        nxt=next(j for j in sorted(adj[cur]) if j!=prev)
        if nxt==loop[0]:break
        loop.append(nxt);prev,cur=cur,nxt
    assert len(loop)==len(adj)
    projected=x-((x-center)@normal)[:,None]*normal;e1=projected[loop[1]]-projected[loop[0]];e1/=np.linalg.norm(e1);e2=np.cross(normal,e1);boundary=projected[loop]
    uv=(boundary-center)@np.array([e1,e2]).T
    if np.sum(uv[:,0]*np.roll(uv[:,1],-1)-uv[:,1]*np.roll(uv[:,0],-1))<0:boundary=boundary[::-1]
    origin=.75*center+.25*(boundary[0]+boundary[1])/2
    d=[]
    for a,b in zip(boundary,np.roll(boundary,-1,axis=0)):
        u=np.clip((origin-a)@(b-a)/np.dot(b-a,b-a),0,1);d.append(np.linalg.norm(origin-a-u*(b-a)))
    radius=.15*min(d);parcels=[]
    for face,area in zip(at,areas):
        children=[projected[face]]
        for _ in range(5):children=[q for child in children for q in split(child)]
        for child in children:
            c=child.mean(0)
            if np.linalg.norm(c-origin)>=radius:parcels.append([*c,RHO*H*area/len(children),2*TAG*area/len(children)])
    parcels=np.array(parcels);spacing=float(np.sqrt(np.median(parcels[:,3]/(RHO*H))));dt=.15*spacing/np.sqrt(2*GAMMA/(RHO*H))
    with (OUT/'rim7-input.dat').open('w') as f:
        f.write(f'{len(parcels)} {len(boundary)} 24 {RHO:.17g} {H:.17g} {2*GAMMA:.17g} {radius:.17g} {dt:.17g} {spacing:.17g}\n')
        for row in [origin,e1,e2,*boundary,*parcels]:f.write(' '.join(f'{v:.17g}' for v in row)+'\n')
    np.savez_compressed(OUT/'seven-scene.npz',x=x,tri=t,front=front,back=back,kind=kind,active=active,parcels=parcels,boundary=boundary,origin=origin,e1=e1,e2=e2)
    return dict(active_pair=pair,geometry_sources=[str(p.relative_to(ROOT)) for p in paths],projection_error_m=float(np.max(abs((x[np.unique(at)]-center)@normal))),area_m2=float(areas.sum()),parcels=len(parcels),dt_s=dt)

def cap_geometry():
    native=np.load(OUT/'seven-scene.npz');old=np.load(ROOT/'results/liquid-volume/liquid7-s020-preserved.npz');px=old['points']*R;t=old['tets'];faces=old['faces'][old['markers']>0]
    # Orient skin triangles outwards using the original tetrahedron incidence.
    incidence={}
    for tet in t:
        for omitted in range(4):
            face=tuple(sorted(int(q) for j,q in enumerate(tet) if j!=omitted));incidence.setdefault(face,[]).append(int(tet[omitted]))
    boundary=[]
    for face in faces:
        a,b,c=map(int,face);opposite=incidence[tuple(sorted(face))]
        if len(opposite)!=1:raise ValueError('non-boundary marked triangle')
        if np.cross(px[b]-px[a],px[c]-px[a])@(px[opposite[0]]-px[a])>0:b,c=c,b
        boundary.append([a,b,c])
    boundary=np.array(boundary);packet=np.loadtxt(OUT/'seven-contact.csv',delimiter=',',skiprows=1,ndmin=2);m=packet[:,7].sum();S=packet[:,8].sum();point=np.sum(packet[:,7,None]*packet[:,1:4],axis=0)/m
    distances=np.array([np.linalg.norm(point-closest_point(point,px[f])) for f in boundary]);which=int(distances.argmin());face=boundary[which];p=px[face];cross=np.cross(p[1]-p[0],p[2]-p[0]);area=np.linalg.norm(cross)/2;n=cross/(2*area);height=3*m/(RHO*area);apex=p.mean(0)+height*n
    cap=np.array([*face,len(px)]);allx=np.vstack([px,apex]);vol=lambda q:np.linalg.det(allx[q[1:]]-allx[q[0]])/6
    if vol(cap)<0:cap[:2]=cap[1::-1]
    cap_points=allx[cap];other=px[t];overlap=[]
    for k,tt in enumerate(other):
        if np.any(np.minimum(tt.max(0),cap_points.max(0))-np.maximum(tt.min(0),cap_points.min(0))<=0):continue
        if not separated(cap_points,tt):overlap.append(k)
    film_mask=(native['kind']==1)&~native['active'];film_native=native['tri'][film_mask];tree=cKDTree(px);dist,near=tree.query(native['x'])
    mapping={int(i):int(j) for i,j in enumerate(near) if dist[i]<1e-12};positions=list(allx)
    for i in np.unique(film_native):
        if int(i) not in mapping:mapping[int(i)]=len(positions);positions.append(native['x'][i])
    allx=np.array(positions);film=np.array([[mapping[int(v)] for v in f] for f in film_native]);tets=np.vstack([t,cap]);skin=np.delete(boundary,which,axis=0).tolist()
    for a,b in zip(face,np.roll(face,-1)):
        tri=[int(a),int(b),int(cap.max())]
        p=allx[tri];remaining=next(q for q in cap if q not in tri)
        if np.cross(p[1]-p[0],p[2]-p[0])@(allx[remaining]-p[0])>0:tri[1],tri[2]=tri[2],tri[1]
        skin.append(tri)
    skin=np.array(skin);vp=allx[tets];volumes=np.linalg.det(vp[:,1:]-vp[:,0,None])/6
    touched=set(map(int,face));support=set(map(int,cap))
    for tet in t:
        if any(int(j) in touched for j in tet):support.update(map(int,tet))
    np.savez_compressed(OUT/'local-geometry.npz',x0=allx,tets=tets,skin=skin,film=film,volume0=volumes,cap=cap,base_face=face,packet=packet,support=np.array(sorted(support)),fluid_nodes=np.unique(tets),bulk_S=np.r_[np.zeros(len(t)),S],film_native_pairs=np.stack([native['front'][film_mask],native['back'][film_mask]],axis=1))
    stats=dict(native_liquid_volume_m3=float(volumes[:-1].sum()),cap_volume_m3=float(volumes[-1]),incoming_volume_m3=float(m/RHO),cap_volume_error=float(abs(volumes[-1]/(m/RHO)-1)),
        cap_height_m=height,footprint_area_m2=area,contact_to_facet_m=float(distances[which]),footprint_length_over_packet_radius=float(np.sqrt(area)/max(packet[:,10])),
        cap_COM_to_incoming_COM_m=float(np.linalg.norm(allx[cap].mean(0)-point)),overlapping_tets=overlap,fluid_vertices=len(np.unique(tets)),tetrahedra=len(tets),total_nodes=len(allx),film_triangles=len(film),liquid_skin_triangles=len(skin),support_nodes=len(support),
        original_volume_error=float(abs(volumes[:-1].sum()/json.loads((ROOT/'results/liquid-volume/liquid7-s020-preserved-mesh.json').read_text())['expected_volume_m3']-1)))
    preparation=json.loads((OUT/'preparation-protocol.json').read_text())['preparation']
    allowance=float(max(packet[:,10])+preparation['projection_error_m']+preparation['dt_s']*max(np.linalg.norm(packet[:,4:7],axis=1)))
    stats['contact_distance_allowance_m']=allowance;stats['consistent_3d_contact']=bool(distances[which]<=allowance)
    stats['passed']=bool(stats['cap_volume_error']<1e-10 and stats['original_volume_error']<1e-8 and not overlap and min(volumes)>0 and stats['consistent_3d_contact'])
    save(OUT/'receiving-geometry-audit.json',stats);return stats

def main():
    OUT.mkdir(exist_ok=True);LOG.mkdir(exist_ok=True);meta=prepare_contact();exe=ROOT/'build/windows/x64/release/froth_rim_first_contact.exe'
    sources=[Path(__file__),ROOT/'foam/docs/spatial_recipient_protocol.md',ROOT/'foam/bench/rim_first_contact.cpp',ROOT/'results/liquid-volume/liquid7-s020-preserved.npz']+[ROOT/q for q in meta['geometry_sources']]
    save(OUT/'preparation-protocol.json',dict(scope='new seven-bubble native contact and uncalibrated local receiving cap',preparation=meta,executable_sha256=sha(exe),sources={str(p.relative_to(ROOT)):sha(p) for p in sources},training=False))
    for name,factor in [('seven',1),('seven-half',.5)]:
        p=subprocess.run([str(exe),'rim7-input.dat',name,str(factor)],cwd=OUT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=60);(LOG/(name+'-rim.txt')).write_bytes(p.stdout)
        if p.returncode:raise RuntimeError(f'{name} native rim error {p.returncode}')
    a=json.loads((OUT/'seven-event.json').read_text());b=json.loads((OUT/'seven-half-event.json').read_text())
    comparison=dict(time_relative=abs(a['impact_time_s']/b['impact_time_s']-1),mass_relative=abs(a['incoming_mass_kg']/b['incoming_mass_kg']-1),impulse_relative=float(np.linalg.norm(np.array(a['momentum_kg_m_s'])-b['momentum_kg_m_s'])/np.linalg.norm(b['momentum_kg_m_s'])))
    save(OUT/'native-contact-comparison.json',comparison);print('seven contact',a,'comparison',comparison)
    geometry=cap_geometry();print('local receiving geometry',geometry)
    if not geometry['passed']:raise RuntimeError('receiving geometry rejected; do not evolve fluid')

if __name__=='__main__':main()
