"""Actual four-bubble spatial liquid recipient; no private third-party patches."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys,time
import numpy as np
import meshpy.tet as tet
from liquid_control_volume import ROOT,R,load_surface,volumes,dual_cells
OUT=ROOT/'results/spatial-recipient';LOG=ROOT/'results/logs/spatial-recipient'

def save(path,value):path.write_text(json.dumps(value,indent=2,default=lambda x:x.item()),encoding='utf8')

def mesh_worker():
    x,f,gas,expected,paths=load_surface(4,.02,'initial')
    info=tet.MeshInfo();info.set_points(x.tolist());info.set_facets(f.tolist(),markers=(gas+1).tolist())
    switches='pfnT1e-12'
    mesh=tet.build(info,options=tet.Options(switches),verbose=True)
    y=np.array(mesh.points);t=np.array(mesh.elements,dtype=int);faces=np.array(mesh.faces,dtype=int);markers=np.array(mesh.face_markers,dtype=int)
    v=volumes(y,t);q=y[t[:,1:]]-y[t[:,0,None]];sv=np.linalg.svd(q,compute_uv=False);condition=sv[:,0]/sv[:,-1]
    m,cuts,outer,boundary,dual=dual_cells(y,t)
    np.savez_compressed(OUT/'recipient-mesh.npz',x=y*R,tets=t,faces=faces,markers=markers,input_x=x*R,input_faces=f,input_gas=gas,stocks=m*R**3,cuts=cuts,outer=outer,boundary=boundary)
    stats=dict(switches=switches,facet_markers='native adjacent gas body +1',vertices=len(y),tetrahedra=len(t),volume_m3=float(v.sum()*R**3),expected_volume_m3=expected*R**3,
               volume_error=float(abs(v.sum()/expected-1)),minimum_tet_volume_m3=float(v.min()*R**3),maximum_condition_number=float(condition.max()),dual=dual,
               source_hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
    stats['passed']=bool(np.all(v>0) and stats['volume_error']<1e-8 and condition.max()<1e8 and dual['dual_area_closure']<1e-9 and dual['dual_volume_rebuild_error']<1e-8)
    save(OUT/'mesh-audit.json',stats);print(json.dumps(stats,indent=2))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--mesh-worker',action='store_true');args=ap.parse_args();OUT.mkdir(exist_ok=True);LOG.mkdir(exist_ok=True)
    if args.mesh_worker:mesh_worker();return
    start=time.perf_counter();p=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--mesh-worker'],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30)
    (LOG/'mesh.txt').write_bytes(p.stdout)
    if p.returncode:raise RuntimeError(f'native meshing failure {p.returncode}, original domain preserved')
    print((OUT/'mesh-audit.json').read_text());print('elapsed',time.perf_counter()-start)

if __name__=='__main__':main()
