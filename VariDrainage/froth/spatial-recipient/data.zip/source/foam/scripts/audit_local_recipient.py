"""Independent saved tetrahedral volumes, momenta and supported-energy audit."""
from pathlib import Path
import hashlib,json
import numpy as np
from gas_shape import ROOT,RT
OUT=ROOT/'results/spatial-recipient';RHO=1000.;H=.8e-6;TAG=1e-6;GAMMA=.03

def area(x,t):
    p=x[t];return np.sqrt(np.sum(np.cross(p[:,1]-p[:,0],p[:,2]-p[:,0])**2,axis=1))/2

def main():
    g=dict(np.load(OUT/'local-geometry.npz'));summary=json.loads((OUT/'fluid-summary.json').read_text());x0=g['x0'];t=g['tets'];skin=g['skin'];film=g['film'];surf=np.vstack([skin,film]);n=len(skin)
    p0=x0[t];V0=np.linalg.det(p0[:,1:]-p0[:,0,None])/6;A0=area(x0,surf);filmV=H*A0[n:];Sfilm=2*TAG*A0[n:]
    mass=np.zeros(len(x0));np.add.at(mass,t.ravel(),np.repeat(RHO*V0/4,4));np.add.at(mass,film.ravel(),np.repeat(RHO*filmV/3,3))
    # Separate cotangent expression for the initial capillary preload.
    preload=np.zeros_like(x0);sigma0=np.r_[np.full(n,GAMMA),np.full(len(film),2*GAMMA)];p=x0[surf]
    for a,b,c in [(0,1,2),(1,2,0),(2,0,1)]:
        cotb=np.einsum('ij,ij->i',p[:,a]-p[:,b],p[:,c]-p[:,b])/(2*A0);cotc=np.einsum('ij,ij->i',p[:,a]-p[:,c],p[:,b]-p[:,c])/(2*A0)
        grad=.5*(cotc[:,None]*(p[:,a]-p[:,b])+cotb[:,None]*(p[:,a]-p[:,c]));np.add.at(preload,surf[:,a],sigma0[:,None]*grad)
    packet=g['packet'];P0=(packet[:,7,None]*packet[:,4:7]).sum(0);L0=np.cross(packet[:,1:4],packet[:,7,None]*packet[:,4:7]).sum(0);Pscale=np.linalg.norm(P0);Lscale=max(np.linalg.norm(L0),.01*Pscale)
    audits=[]
    for run in summary['runs']:
        name=run['name'];z=dict(np.load(OUT/(name+'-frames.npz')));hist=np.genfromtxt(OUT/(name+'-history.csv'),delimiter=',',names=True);E0=run['received_energy_J'];scale=max(E0,summary['runs'][0]['received_energy_J']*1e-12,1e-30)
        verrors=[];herr=[];bulkerr=[];energyerr=[];perr=[];lerr=[];div=[];nonrigid=[];preloadwork=[];maxspeed=0.
        for k,time in enumerate(z['time']):
            xx=z['x'][k];vv=z['v'][k];p=xx[t];V=np.linalg.det(p[:,1:]-p[:,0,None])/6;A=area(xx,surf);delta=A/A0-1
            verrors.append(float(max(abs(V/V0-1))));herr.append(float(max(abs(z['h'][k]*A[n:]/filmV-1))));bulkerr.append(float(abs(np.dot(g['bulk_S']/V0,V)/g['bulk_S'].sum()-1)))
            surface=float(GAMMA*np.sum(A0[:n]*delta[:n])+np.sum(2*(GAMMA+RT*TAG)*A0[n:]*delta[n:]-RT*Sfilm*np.log1p(delta[n:])))
            work=float(np.sum(preload*(xx-x0)));K=float(.5*np.sum(mass[:,None]*vv*vv));energyerr.append(abs(K+surface-work-hist[k]['supported_energy_J'])/scale);preloadwork.append(work/scale)
            P=np.sum(mass[:,None]*vv,axis=0);L=np.cross(xx,mass[:,None]*vv).sum(0);externalL=np.array([hist[k][q] for q in ['external_Lx','external_Ly','external_Lz']]);expectedP=np.zeros(3) if run['erased'] else P0;expectedL=np.zeros(3) if run['erased'] else L0
            perr.append(float(np.linalg.norm(P-expectedP)/Pscale));lerr.append(float(np.linalg.norm(L-expectedL-externalL)/Lscale))
            # Velocity gradient from independent full affine-coordinate inverse.
            affine=np.concatenate([np.ones((len(t),4,1)),p],axis=2);grad=np.linalg.inv(affine)[:,1:,:].transpose(0,2,1);dv=np.einsum('tai,taj->tij',vv[t],grad);trace=np.trace(dv,axis1=1,axis2=2)
            denominator=np.sum(V*np.sum(dv*dv,axis=(1,2)));div.append(float(np.sqrt(np.dot(V,trace*trace)/denominator)) if denominator>1e-25 else 0.)
            ids=g['fluid_nodes'];m=mass[ids];C=np.sum(m[:,None]*xx[ids],axis=0)/m.sum();r=xx[ids]-C;vel=vv[ids];U=np.sum(m[:,None]*vel,axis=0)/m.sum();J=np.eye(3)*np.sum(m*np.sum(r*r,axis=1))-np.einsum('i,ij,ik->jk',m,r,r);omega=np.linalg.solve(J,np.cross(r,m[:,None]*(vel-U)).sum(0));remainder=vel-U-np.cross(omega,r)
            denom=float(np.sum(m[:,None]*vel*vel));nonrigid.append(float(np.sum(m[:,None]*remainder*remainder)/denom) if denom>1e-25 else 0.);maxspeed=max(maxspeed,float(np.max(np.linalg.norm(vel,axis=1))))
        q=dict(name=name,saved_frames=len(z['time']),maximum_independent_tet_volume_error=max(verrors),material_film_volume_error=max(herr),bulk_tag_amount_error=max(bulkerr),energy_reconstruction_received=max(energyerr),true_P_error=max(perr),true_L_plus_recorded_preload_error=max(lerr),affine_velocity_divergence_relative=max(div),maximum_preload_work_over_received=max(abs(np.array(preloadwork))),initial_nonrigid_liquid_kinetic_fraction=nonrigid[0],final_nonrigid_liquid_kinetic_fraction=nonrigid[-1],maximum_saved_liquid_speed_m_s=maxspeed)
        q['passed']=bool(max(verrors)<1e-9 and max(herr)<1e-12 and max(bulkerr)<1e-9 and max(energyerr)<1e-5 and max(perr)<1e-6 and max(lerr)<1e-6 and max(div)<1e-7);audits.append(q)
    cap=g['cap'];base=g['base_face'];cap_skin=np.array([f for f in skin if int(cap.max()) in f]);surface_added=GAMMA*(area(x0,cap_skin).sum()-area(x0,base[None]).sum())
    estimated_rim_surface=float(np.sum(2*GAMMA*packet[:,7]/(RHO*packet[:,10])))
    event=dict(received_volume_m3=float(V0[-1]),incoming_volume_m3=float(packet[:,7].sum()/RHO),volume_error=float(abs(V0[-1]/(packet[:,7].sum()/RHO)-1)),cap_surface_energy_increase_J=float(surface_added),cylindrical_node_surface_energy_estimate_J=estimated_rim_surface,surface_difference_estimate_J=float(surface_added-estimated_rim_surface),scope='geometric estimate only; not a calibrated full collision or total rim energy validation')
    protocol=json.loads((OUT/'fluid-protocol.json').read_text());prep=json.loads((OUT/'preparation-protocol.json').read_text());sources_match=all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==v for p,v in {**protocol['sources'],**prep['sources']}.items())
    result=dict(runs=audits,event_geometry_energy=event,sources_match=sources_match,preload_force_relative=float(np.linalg.norm(preload.sum(0))/np.linalg.norm(preload)),initial_total_liquid_including_remaining_films_m3=float(V0.sum()+filmV.sum()),initial_total_represented_tag_mol=float(g['bulk_S'].sum()+Sfilm.sum()),scope='saved geometry/physical momenta and recorded integrated preload; not independent full-time torque quadrature, spatial convergence or experimental validation')
    result['passed']=bool(all(q['passed'] for q in audits) and sources_match and event['volume_error']<1e-10)
    (OUT/'independent-fluid-audit.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps(result,indent=2))

if __name__=='__main__':main()
