"""Spatial inviscid material-volume liquid + finite-area films after real contact.

RATTLE on P1/P0 tetrahedra, explicit preload and uncalibrated cap receiving.
No private CODA/tool patch, no pressure penalty or solid shear stiffness.
"""
from pathlib import Path
import hashlib,json,csv,time,argparse,platform
import numpy as np
from scipy.sparse import coo_matrix,diags
from scipy.sparse.linalg import splu
from gas_shape import ROOT,RT
OUT=ROOT/'results/spatial-recipient';RHO=1000.;H=.8e-6;TAG=1e-6;GAMMA=.03

def save(p,q):p.write_text(json.dumps(q,indent=2,default=lambda v:v.item()),encoding='utf8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

class Scene:
    def __init__(self):
        z=np.load(OUT/'local-geometry.npz');self.x0=z['x0'];self.t=z['tets'];self.vol0=z['volume0'];self.fluid=z['fluid_nodes'];self.support=z['support'];self.packet=z['packet'];self.bulkS=z['bulk_S']
        self.skin=z['skin'];self.film=z['film'];self.surf=np.vstack([self.skin,self.film]);self.nskin=len(self.skin);self.n=len(self.x0);self.nt=len(self.t)
        self.rows=np.repeat(np.arange(self.nt),12);self.cols=(3*self.t[:,:,None]+np.arange(3)).ravel()
        p=self.x0[self.surf];cross=np.cross(p[:,1]-p[:,0],p[:,2]-p[:,0]);self.A0=np.linalg.norm(cross,axis=1)/2
        self.filmVol=H*self.A0[self.nskin:];self.filmS=2*TAG*self.A0[self.nskin:]
        self.m=np.zeros(self.n);np.add.at(self.m,self.t.ravel(),np.repeat(RHO*self.vol0/4,4));np.add.at(self.m,self.film.ravel(),np.repeat(RHO*self.filmVol/3,3))
        if min(self.m)<=0:raise ValueError('unowned zero-mass node')
        self.im=np.repeat(1/self.m,3);self.P=np.sum(self.packet[:,7,None]*self.packet[:,4:7],axis=0);self.L=np.cross(self.packet[:,1:4],self.packet[:,7,None]*self.packet[:,4:7]).sum(0)
        self.Ein=float(np.sum(.5*self.packet[:,7]*np.sum(self.packet[:,4:7]**2,axis=1)))
        _,self.g0,_,_=self.energy_gradient(self.x0)
        self.local_unprojected=self.fit_wrench(self.support);self.local_v,self.initial_projection=self.project(self.x0,self.local_unprojected)
        self.mixed_v=self.fit_wrench(self.fluid)
        self.E0local=self.kinetic(self.local_v);self.E0mixed=self.kinetic(self.mixed_v)
        # Conservative initial capillary frequency upper diagnostic, no prescribed dynamics.
        norm=cross/(2*self.A0[:,None]);grads=np.stack([np.cross(norm,p[:,2]-p[:,1]),np.cross(norm,p[:,0]-p[:,2]),np.cross(norm,p[:,1]-p[:,0])],axis=1)/(2*self.A0[:,None,None])
        sigma=np.r_[np.full(self.nskin,GAMMA),np.full(len(self.film),2*GAMMA)];k=np.zeros(self.n)
        np.add.at(k,self.surf.ravel(),(12*sigma[:,None]*self.A0[:,None]*np.sum(grads**2,axis=2)).ravel())
        self.omega_bound=float(np.max(np.sqrt(k/self.m)));self.steps=40*int(np.ceil(.0002/min(1e-6,.1/self.omega_bound)/40));self.dt=.0002/self.steps

    def kinetic(self,v):return float(.5*np.sum(self.m[:,None]*v*v))

    def fit_wrench(self,nodes):
        masses=self.m[nodes];mass=masses.sum();center=np.sum(masses[:,None]*self.x0[nodes],axis=0)/mass;r=self.x0[nodes]-center
        J=np.eye(3)*np.sum(masses*np.sum(r*r,axis=1))-np.einsum('i,ij,ik->jk',masses,r,r)
        spin=np.linalg.solve(J,self.L-np.cross(center,self.P));v=np.zeros_like(self.x0);v[nodes]=self.P/mass+np.cross(spin,r)
        return v

    def volumes_jacobian(self,x):
        p=x[self.t];a=p[:,1]-p[:,0];b=p[:,2]-p[:,0];c=p[:,3]-p[:,0]
        vol=np.einsum('ij,ij->i',a,np.cross(b,c))/6
        g=np.stack([np.cross(b,c),np.cross(c,a),np.cross(a,b)],axis=1)/6
        g=np.concatenate([-g.sum(1)[:,None],g],axis=1)/self.vol0[:,None,None]
        J=coo_matrix((g.ravel(),(self.rows,self.cols)),shape=(self.nt,3*self.n)).tocsr()
        return vol,J

    def solve_pressure(self,Jleft,Jright,rhs):
        S=(Jleft.multiply(self.im)@Jright.T).tocsc();diag=S.diagonal()
        if np.any(diag<=0):raise ValueError('nonpositive constraint Schur diagonal')
        d=1/np.sqrt(diag);A=S.multiply(d[:,None]).multiply(d[None,:]).tocsc();lu=splu(A)
        pivots=abs(lu.U.diagonal());pivot_ratio=float(pivots.min()/pivots.max())
        if pivot_ratio<1e-12:raise ValueError(f'singular/poor-rank pressure system, pivot ratio {pivot_ratio}')
        y=d*lu.solve(d*rhs);res=float(np.linalg.norm(S@y-rhs)/max(np.linalg.norm(rhs),1e-300))
        return y,res,pivot_ratio

    def project(self,x,v):
        _,J=self.volumes_jacobian(x);rhs=J@v.ravel()
        if np.linalg.norm(rhs)<1e-25:return v.copy(),dict(relative_solve_residual=0.,pivot_ratio=None,divergence=0.)
        pressure,res,pivot=self.solve_pressure(J,J,rhs);out=(v.ravel()-self.im*(J.T@pressure)).reshape(-1,3)
        div=float(np.linalg.norm(J@out.ravel())/max(np.linalg.norm(rhs),1e-300))
        return out,dict(relative_solve_residual=res,pivot_ratio=pivot,divergence=div)

    def energy_gradient(self,x):
        p=x[self.surf];cross=np.cross(p[:,1]-p[:,0],p[:,2]-p[:,0]);area=np.linalg.norm(cross,axis=1)/2
        if min(area)<=0 or not np.all(np.isfinite(area)):raise ValueError('invalid skin/film area')
        n=cross/(2*area[:,None]);delta=area/self.A0-1;sigma=np.full(len(area),GAMMA)
        sigma[self.nskin:]=2*(GAMMA+RT*TAG)-RT*self.filmS/area[self.nskin:]
        e=float(GAMMA*np.sum(self.A0[:self.nskin]*delta[:self.nskin])+np.sum(2*(GAMMA+RT*TAG)*self.A0[self.nskin:]*delta[self.nskin:]-RT*self.filmS*np.log1p(delta[self.nskin:])))
        gradient=np.zeros_like(x)
        for a,b,c in [(0,1,2),(1,2,0),(2,0,1)]:np.add.at(gradient,self.surf[:,a],.5*sigma[:,None]*np.cross(p[:,b]-p[:,c],n))
        return e,gradient,area,sigma

    def preflight(self):
        vol,J=self.volumes_jacobian(self.x0);rng=np.random.default_rng(713);d=rng.normal(size=self.x0.shape);d/=np.linalg.norm(d);probe=self.x0+1e-8*rng.normal(size=self.x0.shape)
        e,g,_,_=self.energy_gradient(probe);eps=1e-10;fd=(self.energy_gradient(probe+eps*d)[0]-self.energy_gradient(probe-eps*d)[0])/(2*eps);exact=float(np.sum(g*d))
        # Holomorphic area sqrt(cross dot cross): no conjugation/subtractive FD.
        cp=(probe+1e-25j*d)[self.surf];cc=np.cross(cp[:,1]-cp[:,0],cp[:,2]-cp[:,0]);ca=np.sqrt(np.sum(cc*cc,axis=1))/2;delta=ca/self.A0-1
        ce=GAMMA*np.sum(self.A0[:self.nskin]*delta[:self.nskin])+np.sum(2*(GAMMA+RT*TAG)*self.A0[self.nskin:]*delta[self.nskin:]-RT*self.filmS*np.log1p(delta[self.nskin:]))
        derivative=float(ce.imag/1e-25)
        modes=[np.tile(axis,(self.n,1)) for axis in np.eye(3)]
        modes += [np.cross(np.tile(axis,(self.n,1)),self.x0) for axis in np.eye(3)]
        modes += [self.x0@np.array([[0,1,0],[0,0,0],[0,0,0]]).T,self.x0@np.diag([1,-1,0])]
        errors=[float(np.linalg.norm(J@v.ravel())/(np.linalg.norm(J.data)*np.linalg.norm(v))) for v in modes]
        localP=np.sum(self.m[:,None]*self.local_v,axis=0);localL=np.cross(self.x0,self.m[:,None]*self.local_v).sum(0)
        Pscale=np.linalg.norm(self.P);Lscale=max(np.linalg.norm(self.L),.01*Pscale)
        out=dict(nodes=self.n,fluid_nodes=len(self.fluid),material_tets=self.nt,film_triangles=len(self.film),constraint_rows=self.nt,total_position_dofs=3*self.n,
                 pressure_projection=self.initial_projection,material_volume_error=float(max(abs(vol/self.vol0-1))),rigid_and_tracefree_mode_error=max(errors),
                 directional_force_gradient_error=float(abs(derivative-exact)/max(abs(exact),1e-30)),
                 subtractive_fd_roundoff_diagnostic=float(abs(fd-exact)/max(abs(exact),1e-30)),derivative_check='complex-step independent analytic energy evaluation',
                 received_energy_local_J=self.E0local,received_energy_global_mix_J=self.E0mixed,incoming_kinetic_J=self.Ein,
                 unprojected_local_energy_J=self.kinetic(self.local_unprojected),initial_P_error=float(np.linalg.norm(localP-self.P)/Pscale),initial_L_error=float(np.linalg.norm(localL-self.L)/Lscale),
                 omega_bound_per_s=self.omega_bound,main_steps=self.steps,main_dt_s=self.dt,
                 local_pressure_projection_loss_J=self.kinetic(self.local_unprojected)-self.E0local,global_mix_extra_loss_J=self.E0local-self.E0mixed,
                 scope='constraint consistency/rank diagnostics, not inf-sup stability or spatial convergence')
        out['passed']=bool(out['directional_force_gradient_error']<1e-6 and max(errors)<1e-10 and out['initial_P_error']<1e-6 and out['initial_L_error']<1e-6 and self.initial_projection['relative_solve_residual']<1e-8 and self.Ein>=self.kinetic(self.local_unprojected)>=self.E0local>=self.E0mixed and self.steps<=20000)
        return out

    def run(self,name,half=False,mixed=False,erased=False):
        steps=self.steps*(2 if half else 1);dt=.0002/steps;stride=steps//40
        x=self.x0.copy();v=np.zeros_like(x) if erased else self.mixed_v.copy() if mixed else self.local_v.copy();E0=self.kinetic(v);scale=max(E0,self.E0local*1e-12,1e-30)
        Ptarget=np.zeros(3) if erased else self.P;Ltarget=np.zeros(3) if erased else self.L;externalL=np.zeros(3);Pscale=np.linalg.norm(self.P);Lscale=max(np.linalg.norm(self.L),.01*Pscale)
        energy,g,area,sigma=self.energy_gradient(x);F=-g+self.g0;extTorque=np.cross(x,self.g0).sum(0)
        hist=[];frames=[];maxE=maxP=maxL=maxVol=maxResidual=0.;maxNewton=0;minh=np.inf;minsigma=np.inf;failure=None;start=time.perf_counter();completed=0
        def record(step,save_frame=False):
            nonlocal maxE,maxP,maxL,maxVol,minh,minsigma
            vol,_=self.volumes_jacobian(x);ev=float(max(abs(vol/self.vol0-1)));K=self.kinetic(v);work=float(np.sum(self.g0*(x-self.x0)));E=K+energy-work;P=np.sum(self.m[:,None]*v,axis=0);L=np.cross(x,self.m[:,None]*v).sum(0)
            ee=abs(E-E0)/scale;pe=float(np.linalg.norm(P-Ptarget)/Pscale);le=float(np.linalg.norm(L-Ltarget-externalL)/Lscale);h=self.filmVol/area[self.nskin:];gamma=sigma[self.nskin:]/2
            maxE=max(maxE,ee);maxP=max(maxP,pe);maxL=max(maxL,le);maxVol=max(maxVol,ev);minh=min(minh,float(h.min()));minsigma=min(minsigma,float(gamma.min()))
            if save_frame:
                hist.append([step,step*dt,K,energy,work,E,ee,pe,le,ev,float(h.min()),float(h.max()),*externalL])
                frames.append(dict(time=step*dt,x=x.copy(),v=v.copy(),h=h.copy(),area=area.copy(),vol=vol.copy()))
        record(0,True)
        for step in range(1,steps+1):
            try:
                old=x.copy();_,Jold=self.volumes_jacobian(old);vhalf=v+.5*dt*F/self.m[:,None];xp=old+dt*vhalf;extold=extTorque.copy()
                for iteration in range(12):
                    volume,Jnow=self.volumes_jacobian(xp);c=volume/self.vol0-1
                    if min(volume)<=0:raise ValueError('predicted material tet inversion')
                    if max(abs(c))<1e-11:break
                    pressure,res,pivot=self.solve_pressure(Jnow,Jold,c);maxResidual=max(maxResidual,res)
                    xp-= (self.im*(Jold.T@pressure)).reshape(-1,3)
                else:raise ValueError('position volume Newton did not converge in12 iterations')
                maxNewton=max(maxNewton,iteration);vhalf=(xp-old)/dt;x=xp
                energy,g,area,sigma=self.energy_gradient(x)
                if min(sigma)<=0 or min(area/self.A0)<.1:raise ValueError('nonpositive tension or degenerate surface')
                F=-g+self.g0;v,pstat=self.project(x,vhalf+.5*dt*F/self.m[:,None]);maxResidual=max(maxResidual,pstat['relative_solve_residual'])
                extTorque=np.cross(x,self.g0).sum(0);externalL+=.5*dt*(extold+extTorque);completed=step;record(step,step%stride==0)
                if step%(steps//4)==0:
                    print(name,step,'/',steps,'liquid_m3',self.vol0.sum(),'liquid_error',maxVol,'tag_mol',self.bulkS.sum()+self.filmS.sum(),'tag_error',0.,'gas=N/A','P_error',maxP,'L_error',maxL,'E_received_error',maxE,flush=True)
            except (ValueError,RuntimeError,np.linalg.LinAlgError) as error:
                failure=dict(step=step,time_s=step*dt,reason=str(error));np.savez_compressed(OUT/(name+'-failed.npz'),x=x,v=v);break
        np.savez_compressed(OUT/(name+'-frames.npz'),**{k:np.array([f[k] for f in frames]) for k in frames[0]})
        with (OUT/(name+'-history.csv')).open('w',newline='') as f:
            w=csv.writer(f);w.writerow(['step','time_s','kinetic_J','surface_change_J','preload_work_J','supported_energy_J','energy_error_received','P_error','L_plus_preload_error','maximum_tet_volume_error','min_h_m','max_h_m','external_Lx','external_Ly','external_Lz']);w.writerows(hist)
        result=dict(name=name,dt_s=dt,steps_completed=completed,steps_planned=steps,local=not mixed and not erased,erased=erased,failure=failure,received_energy_J=E0,incoming_energy_J=self.Ein,
                    inelastic_total_loss_J=self.Ein-E0,mixing_extra_loss_J=self.E0local-E0 if mixed else 0.,maximum_energy_error_received=maxE,maximum_P_error=maxP,maximum_L_plus_preload_error=maxL,maximum_material_volume_error=maxVol,maximum_pressure_solve_residual=maxResidual,maximum_position_Newton_iterations=maxNewton,
                    minimum_h_m=minh,minimum_film_gamma_N_m=minsigma,elapsed_seconds=time.perf_counter()-start,
                    external_sink_P=(-self.P if erased else np.zeros(3)).tolist(),external_sink_L=(-self.L if erased else np.zeros(3)).tolist())
        result['checks']=dict(completed=failure is None,volume=maxVol<1e-9,P=maxP<1e-6,L=maxL<1e-6,energy_received_1pct=maxE<.01,positive_h=minh>0,positive_gamma=minsigma>0)
        save(OUT/(name+'-summary.json'),result);return result

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--preflight-only',action='store_true');args=parser.parse_args();scene=Scene();audit=scene.preflight();save(OUT/'fluid-preflight.json',audit);print(json.dumps(audit,indent=2),flush=True)
    if not audit['passed']:raise RuntimeError('spatial fluid preflight rejected; no evolution')
    if args.preflight_only:return
    sources=[Path(__file__),ROOT/'foam/docs/spatial_recipient_protocol.md',OUT/'local-geometry.npz',OUT/'seven-contact.csv',ROOT/'foam/scripts/gas_shape.py']
    save(OUT/'fluid-protocol.json',dict(sources={str(p.relative_to(ROOT)):sha(p) for p in sources},python=platform.python_version(),numpy=np.__version__,scope='supported inviscid constrained spatial liquid and insoluble material films; not full lifecycle',horizon_s=.0002,main_dt_s=scene.dt,main_steps=scene.steps,training=False))
    runs=[]
    for name,half,mixed,erased in [('local',False,False,False),('half',True,False,False),('global-mix',False,True,False),('erased',False,False,True)]:
        runs.append(scene.run(name,half,mixed,erased));save(OUT/'progress.json',dict(completed=name))
    comparisons={}
    if all(r['failure'] is None for r in runs[:2]):
        a=np.load(OUT/'local-frames.npz');b=np.load(OUT/'half-frames.npz');c=np.load(OUT/'global-mix-frames.npz')
        comparisons=dict(half_displacement_response_relative=float(np.linalg.norm(a['x'][-1]-b['x'][-1])/max(np.linalg.norm(b['x'][-1]-scene.x0),1e-30)),half_thickness_increment_relative=float(np.linalg.norm(a['h'][-1]-b['h'][-1])/max(np.linalg.norm(b['h'][-1]-H),1e-30)),global_mix_thickness_increment_difference=float(np.linalg.norm(a['h'][-1]-c['h'][-1])/max(np.linalg.norm(a['h'][-1]-H),1e-30)))
        comparisons['time_1pct_pass']=comparisons['half_displacement_response_relative']<.01 and comparisons['half_thickness_increment_relative']<.01
    save(OUT/'fluid-summary.json',dict(runs=runs,comparisons=comparisons,preflight=audit,scope='new spatial supported response, uncalibrated receiving cap and omitted transport/viscosity/gas remain'))
    print(json.dumps(comparisons,indent=2),flush=True)

if __name__=='__main__':main()
