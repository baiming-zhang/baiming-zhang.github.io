// FROTH owned first-contact bridge. Uses the unmodified CODA Rim integrator.
// Fixed planar, constant-tension/pressureless sheet limit; stop at first contact.
#include <algorithm>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <string>
#include <vector>
#include "vf/coda/Rim.h"
using namespace vf; using namespace vf::coda;
struct Parcel { Vec3 x; real m,s; bool live=true; };
static Vec3 Read3(std::istream& f) { Vec3 x; f>>x[0]>>x[1]>>x[2];return x; }
int main(int argc,char** argv) {
 if(argc<3) { std::cerr<<"rim_first_contact input.dat tag [dt_factor]\n";return 2; }
 std::ifstream input(argv[1]); if(!input)return 3;
 int np,nb,nr;real rho,h,sigma,rhole,dt,spacing;input>>np>>nb>>nr>>rho>>h>>sigma>>rhole>>dt>>spacing;
 const Vec3 origin=Read3(input),e1=Read3(input),e2=Read3(input),normal=e1.cross(e2);
 std::vector<Vec3> boundary(nb);for(auto& p:boundary)p=Read3(input);
 std::vector<Parcel> bed(np);for(auto& p:bed){p.x=Read3(input);input>>p.m>>p.s;}
 if(!input)return 4;
 const std::string tag=argv[2];dt*=argc>3?std::stod(argv[3]):1.;
 auto angle=[&](const Vec3& p){Vec3 a=p-origin;real v=std::atan2(a.dot(e2),a.dot(e1));return v<0?v+2*kPi:v;};
 auto inside=[&](const Vec3& p,const std::vector<Vec3>& poly){const real u=(p-origin).dot(e1),v=(p-origin).dot(e2);bool yes=false;
  for(int i=0,j=(int)poly.size()-1;i<(int)poly.size();j=i++) {real a=(poly[i]-origin).dot(e1),b=(poly[i]-origin).dot(e2),c=(poly[j]-origin).dot(e1),d=(poly[j]-origin).dot(e2);
   if((b>v)!=(d>v))if(u<(c-a)*(v-b)/(d-b)+a)yes=!yes;}return yes;};
 auto distance=[](const Vec3& p,const Vec3& a,const Vec3& b,real* w=nullptr){const Vec3 d=b-a;real q=std::clamp((p-a).dot(d)/d.squaredNorm(),0.,1.);if(w)*w=q;return (p-a-q*d).norm();};
 std::vector<int> seed(nr,-1);std::vector<real> best(nr,std::numeric_limits<real>::infinity());
 real totalm=0,totals=0;
 for(int i=0;i<np;i++){totalm+=bed[i].m;totals+=bed[i].s;int k=std::min(nr-1,int(angle(bed[i].x)/(2*kPi)*nr));real r=(bed[i].x-origin).norm();if(r<best[k]){best[k]=r;seed[k]=i;}}
 Rim rim;
 for(int k=0;k<nr;k++){if(seed[k]<0){std::cerr<<"empty initial angular bin\n";return 5;}auto& p=bed[seed[k]];rim.Add_Node(p.x,Vec3::Zero(),p.m,p.s);p.live=false;}
 auto area=[&](){real a=0;for(int i=0;i<rim.Size();i++)a+=(rim.X[i]-origin).cross(rim.X[(i+1)%rim.Size()]-origin).dot(normal)/2;return a;};
 std::ofstream hist(tag+"-history.csv"),frames(tag+"-rim.csv"),absorbed(tag+"-absorbed.csv"),contact(tag+"-contact.csv");
 for(auto* f:{&hist,&frames,&absorbed,&contact})*f<<std::setprecision(17);
 hist<<"step,time_s,film_mass_kg,rim_mass_kg,film_tag_mol,rim_tag_mol,px,py,pz,kinetic_J,line_work_J,BE_loss_J,merge_loss_J,area_release_J,mass_error,tag_error,momentum_error,work_ledger_error\n";
 frames<<"step,time_s,node,x_m,y_m,z_m,vx,vy,vz,mass_kg,tag_mol\n";absorbed<<"parcel,step,time_s\n";
 contact<<"node,x_m,y_m,z_m,vx,vy,vz,mass_kg,tag_mol,boundary_segment,radius_m\n";
 real work=0,benum=0,merge=0;const real A0=area(),KE0=rim.Kinetic(),vscale=std::sqrt(sigma/(rho*h));
 real maxm=0,maxs=0,maxp=0,maxwork=0;int step=0;std::vector<int> hit;std::vector<int> hitseg;std::vector<real> radii;
 for(step=0;step<20000;step++) {
  if(step){std::vector<Vec3> F(rim.Size());const auto oldX=rim.X,oldV=rim.V;
   for(int i=0;i<rim.Size();i++)F[i]=sigma*.5*(rim.X[(i+1)%rim.Size()]-rim.X[(i+rim.Size()-1)%rim.Size()]).cross(normal);
   rim.Step_Frozen(F,dt,false); // actual inertia update, no prescribed retraction speed
   for(int i=0;i<rim.Size();i++){work+=F[i].dot(rim.X[i]-oldX[i]);benum+=.5*rim.M[i]*(rim.V[i]-oldV[i]).squaredNorm();}
   for(int k=0;k<np;k++)if(bed[k].live&&inside(bed[k].x,rim.X)){
    real bestd=std::numeric_limits<real>::infinity(),w=0;int edge=0;
    for(int i=0;i<rim.Size();i++){real q=0,d=distance(bed[k].x,rim.X[i],rim.X[(i+1)%rim.Size()],&q);if(d<bestd){bestd=d;w=q;edge=i;}}
    auto& p=bed[k];if(w<1)merge+=rim.Merge(edge,1-w,p.m,p.s,p.x,Vec3::Zero(),p.x,Vec3::Zero());
    if(w>0)merge+=rim.Merge((edge+1)%rim.Size(),w,p.m,p.s,p.x,Vec3::Zero(),p.x,Vec3::Zero());
    p.live=false;absorbed<<k<<','<<step<<','<<step*dt<<'\n';
   }
  }
  real fm=0,fs=0,rs=0;for(auto& p:bed)if(p.live){fm+=p.m;fs+=p.s;}for(auto s:rim.S)rs+=s;
  const Vec3 P=rim.Momentum();real me=std::abs((fm+rim.Mass())/totalm-1),se=std::abs((fs+rs)/totals-1),pe=P.norm()/(totalm*vscale);
  real we=std::abs(work-(rim.Kinetic()-KE0)-benum-merge)/std::max(work,1e-300);
  maxm=std::max(maxm,me);maxs=std::max(maxs,se);maxp=std::max(maxp,pe);maxwork=std::max(maxwork,we);
  hist<<step<<','<<step*dt<<','<<fm<<','<<rim.Mass()<<','<<fs<<','<<rs<<','<<P[0]<<','<<P[1]<<','<<P[2]<<','<<rim.Kinetic()<<','<<work<<','<<benum<<','<<merge<<','<<sigma*(area()-A0)<<','<<me<<','<<se<<','<<pe<<','<<we<<'\n';
  hit.clear();hitseg.clear();radii.clear();
  for(int i=0;i<rim.Size();i++){real ell=.5*((rim.X[i]-rim.X[(i+rim.Size()-1)%rim.Size()]).norm()+(rim.X[(i+1)%rim.Size()]-rim.X[i]).norm());real a=std::sqrt(rim.M[i]/(rho*kPi*ell));
   real dmin=std::numeric_limits<real>::infinity();int seg=0;for(int b=0;b<nb;b++){real d=distance(rim.X[i],boundary[b],boundary[(b+1)%nb]);if(d<dmin){dmin=d;seg=b;}}
   if(dmin<=a||!inside(rim.X[i],boundary)){hit.push_back(i);hitseg.push_back(seg);radii.push_back(a);}
  }
  if(step%4==0||!hit.empty())for(int i=0;i<rim.Size();i++)frames<<step<<','<<step*dt<<','<<i<<','<<rim.X[i][0]<<','<<rim.X[i][1]<<','<<rim.X[i][2]<<','<<rim.V[i][0]<<','<<rim.V[i][1]<<','<<rim.V[i][2]<<','<<rim.M[i]<<','<<rim.S[i]<<'\n';
  if(!hit.empty())break;
  if(!(area()>0)||!std::isfinite(rim.Kinetic())){std::cerr<<"invalid rim geometry\n";return 6;}
 }
 if(hit.empty()){std::cerr<<"no first contact\n";return 7;}
 real dm=0,ds=0,ke=0;Vec3 p=Vec3::Zero(),first=Vec3::Zero();
 for(int j=0;j<(int)hit.size();j++){int i=hit[j];dm+=rim.M[i];ds+=rim.S[i];p+=rim.M[i]*rim.V[i];first+=rim.M[i]*rim.X[i];ke+=.5*rim.M[i]*rim.V[i].squaredNorm();
  contact<<i<<','<<rim.X[i][0]<<','<<rim.X[i][1]<<','<<rim.X[i][2]<<','<<rim.V[i][0]<<','<<rim.V[i][1]<<','<<rim.V[i][2]<<','<<rim.M[i]<<','<<rim.S[i]<<','<<hitseg[j]<<','<<radii[j]<<'\n';}
 std::ofstream out(tag+"-event.json");out<<std::setprecision(17)<<"{\n\"dt_s\":"<<dt<<",\"impact_time_s\":"<<step*dt<<",\"steps\":"<<step<<",\"contact_nodes\":"<<hit.size()<<",\"incoming_mass_kg\":"<<dm<<",\"incoming_tag_mol\":"<<ds<<",\"incoming_kinetic_J\":"<<ke<<",\"initial_mass_kg\":"<<totalm<<",\"initial_tag_mol\":"<<totals<<",\"max_mass_error\":"<<maxm<<",\"max_tag_error\":"<<maxs<<",\"max_momentum_error\":"<<maxp<<",\"max_force_work_ledger_error\":"<<maxwork<<",\"final_area_release_J\":"<<sigma*(area()-A0)<<",\"final_line_work_J\":"<<work<<",\"momentum_kg_m_s\":["<<p[0]<<','<<p[1]<<','<<p[2]<<"],\"position_m\":["<<first[0]/dm<<','<<first[1]/dm<<','<<first[2]/dm<<"],\"model\":\"constant-tension planar first contact, stop before continuing topology\"}\n";
 std::cout<<"first contact t="<<step*dt<<" s nodes="<<hit.size()<<" dm="<<dm<<" kg mass_error="<<maxm<<" tag_error="<<maxs<<" P_error="<<maxp<<"\n";
 return 0;
}
