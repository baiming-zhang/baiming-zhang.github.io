//////////////////////////////////////////////////////////////////////////
// CODA: a 1D Lagrangian rim along the free edge of a particle film.
//
// The rim is a chain of nodes (position X, velocity V, mass M, absorbed surfactant S) along a hole edge. It carries
// the film's tension as a line force: the tension energy of the film is sigma times the area the rim encloses, so
// in the plane of a flat film it is sigma times the polygon area of the rim chain (a null Lagrangian inside the film,
// acting only through the boundary). The film particles keep their Gibbs energy, viscosity and inertia; their
// tension acts only on their normal motion (A2 split), so a film edge without a rim is a 2D gas of pressure K C.
//
// The rim and the film interact through accretion: after every step each film particle on the hole side of the
// rim chain is merged into the two nodes of the segment it crossed (linear weights), perfectly inelastically:
// mass, momentum, centre of mass and the BDF2 history (mass-weighted) are kept exactly; the kinetic energy lost is
// the dissipation of the rim. Its surfactant leaves the film with its liquid (soluble surfactant, as SDS above the
// CMC). Taylor-Culick (rim speed sqrt((sigma - K) / mu), half of the work of the net tension dissipated) is not
// built in anywhere: it is the check.
//
// Time stepping mirrors Normal_Stepper: BDF2 in optimization form, x = argmin M/(2 hh^2) |x - xt|^2 + E(x).
//////////////////////////////////////////////////////////////////////////
#pragma once
#include <algorithm>
#include <cmath>
#include <vector>
#include <Eigen/Dense>
#include "vf/core/Types.h"

namespace vf::coda {

struct Rim {
	std::vector<Vec3> X, V, X_prev, V_prev;
	std::vector<real> M, S;
	bool has_prev = false;
	// topology: a closed chain joins its last node to its first (shifted by `period` for a periodic straight chain);
	// an open chain (a free ligament) has two ends
	bool closed = true;
	Vec3 period = Vec3::Zero();
	bool tied0 = false; // open chain whose node 0 is tied to a node of another chain (a ligament hanging from the rim)
	real dt_hist = 0.; // step size the BDF2 history (X_prev, V_prev) belongs to (0: unknown, taken as the next step)
	int Size() const { return (int)X.size(); }
	int Segments() const { return closed ? Size() : std::max(0, Size() - 1); }
	// segment j from node j to node j + 1 (mod n), for positions x of this chain
	Vec3 Seg(const std::vector<Vec3>& x, int j) const
	{
		const int n = (int)x.size(), b = (j + 1) % n;
		return x[b] - x[j] + (closed && b == 0 ? period : Vec3::Zero());
	}

	void Add_Node(const Vec3& x, const Vec3& v, real m, real s)
	{
		X.push_back(x); V.push_back(v); X_prev.push_back(x); V_prev.push_back(v); M.push_back(m); S.push_back(s);
	}

	// BDF2 (or backward Euler) inertia target and step scale hh
	void Predictor(real dt, bool bdf2, std::vector<Vec3>& xt, real& hh) const
	{
		const int n = Size();
		hh = bdf2 ? 2. * dt / 3. : dt;
		xt.resize(n);
		for (int k = 0; k < n; k++)
			xt[k] = bdf2 ? Vec3(4. / 3. * X[k] - 1. / 3. * X_prev[k] + 8. * dt / 9. * V[k] - 2. * dt / 9. * V_prev[k]) : Vec3(X[k] + dt * V[k]);
	}

	void Finish(const std::vector<Vec3>& xn, real dt, bool bdf2)
	{
		for (int k = 0; k < Size(); k++) {
			const Vec3 v = bdf2 ? Vec3(1.5 / dt * (xn[k] - 4. / 3. * X[k] + 1. / 3. * X_prev[k])) : Vec3((xn[k] - X[k]) / dt);
			X_prev[k] = X[k]; V_prev[k] = V[k];
			X[k] = xn[k]; V[k] = v;
		}
		has_prev = true;
	}

	// Perfectly inelastic merge of a film particle (mass m, surfactant s, position p, velocity v, BDF2 history pp, vp)
	// into node k with weight w in (0, 1]. Returns the kinetic energy lost.
	real Merge(int k, real w, real m, real s, const Vec3& p, const Vec3& v, const Vec3& pp, const Vec3& vp)
	{
		const real dm = w * m, Mn = M[k] + dm;
		const real loss = 0.5 * M[k] * dm / Mn * (V[k] - v).squaredNorm();
		X[k] = (M[k] * X[k] + dm * p) / Mn;           V[k] = (M[k] * V[k] + dm * v) / Mn;
		X_prev[k] = (M[k] * X_prev[k] + dm * pp) / Mn; V_prev[k] = (M[k] * V_prev[k] + dm * vp) / Mn;
		M[k] = Mn; S[k] += w * s;
		return loss;
	}

	// Step with a force frozen over the step (e.g. a line force whose direction comes from the film at x^n):
	// x = xt + hh^2 F / M, exact through the inertia target.
	void Step_Frozen(const std::vector<Vec3>& F, real dt, bool bdf2)
	{
		std::vector<Vec3> xt;
		real hh;
		Predictor(dt, bdf2, xt, hh);
		for (int k = 0; k < Size(); k++) xt[k] += hh * hh / M[k] * F[k];
		Finish(xt, dt, bdf2);
	}

	// Closed chain in vector order: split every segment longer than max_len by a new node. A node stands for half of
	// each of its two segments; the new node takes over a quarter of the split segment from each end, and with it the
	// same fraction of that end's mass (and surfactant), so the mass per unit length along the rim stays as it was.
	// The new node sits at the centre of mass of what it takes, with its momentum and history: mass, momentum and
	// centre of mass are kept. Returns the number of nodes added.
	int Refine_Closed(real max_len)
	{
		int added = 0;
		for (int k = 0; k < Size() && Size() > 2; k++) {
			const int n = Size(), b = (k + 1) % n, a0 = (k + n - 1) % n, b1 = (b + 1) % n;
			const real Lab = (X[b] - X[k]).norm();
			if (Lab <= max_len) continue;
			const real la = 0.5 * ((X[k] - X[a0]).norm() + Lab), lb = 0.5 * (Lab + (X[b1] - X[b]).norm());
			const real fa = std::min(0.5, 0.25 * Lab / la), fb = std::min(0.5, 0.25 * Lab / lb);
			const real Ma = fa * M[k], Mb = fb * M[b], Mc = Ma + Mb, w = 1. / Mc;
			const Vec3 xc = w * (Ma * X[k] + Mb * X[b]), vc = w * (Ma * V[k] + Mb * V[b]);
			const Vec3 xpc = w * (Ma * X_prev[k] + Mb * X_prev[b]), vpc = w * (Ma * V_prev[k] + Mb * V_prev[b]);
			const real sc = fa * S[k] + fb * S[b];
			M[k] -= Ma; M[b] -= Mb; S[k] *= 1. - fa; S[b] *= 1. - fb;
			X.insert(X.begin() + k + 1, xc); V.insert(V.begin() + k + 1, vc);
			X_prev.insert(X_prev.begin() + k + 1, xpc); V_prev.insert(V_prev.begin() + k + 1, vpc);
			M.insert(M.begin() + k + 1, Mc); S.insert(S.begin() + k + 1, sc);
			added++;
			k++; // the new node's far segment is checked with the next k
		}
		return added;
	}

	// Open or closed chain: split segment j (from node j to j + 1) by a new node at its midpoint. The node takes over a
	// quarter of the segment from each end and the same fraction of that end's mass (length-proportional shares, an end
	// node standing for half of its one segment), so the line density, and with it the radius of a capillary thread, stays
	// as it was at both ends. Mass and momentum are kept; the centre of mass of the shares is generally not the midpoint,
	// so both ends move along the segment by the same small amount that keeps the first moment exact (their velocities
	// and the BDF2 history move with them). Returns the index of the new node.
	// A pinned end (a junction another chain is tied to): both ends give the same mass (the smaller of their shares), the
	// new node sits at the midpoint, neither end moves.
	int Split_Segment(int j, bool pin_j = false, bool pin_b = false)
	{
		const int n = Size(), b = (j + 1) % n;
		const real Lab = Seg(X, j).norm();
		auto node_len = [&](int k) {
			real l = 0.;
			if (closed || k > 0) l += 0.5 * Seg(X, (k + n - 1) % n).norm();
			if (closed || k < n - 1) l += 0.5 * Seg(X, k).norm();
			return l;
		};
		real fa = std::min(0.5, 0.25 * Lab / node_len(j)), fb = std::min(0.5, 0.25 * Lab / node_len(b));
		if (pin_j || pin_b) {
			// a pinned end: equal shares from both ends, so that the new node sits at the midpoint without moving anything
			// (shares of unequal mass would put it next to the heavier end, leave the far half long, and repeated splits
			// would drain the lighter end)
			const real ms = std::min(fa * M[j], fb * M[b]);
			fa = ms / M[j]; fb = ms / M[b];
		}
		const Vec3 sh = (closed && b == 0) ? period : Vec3::Zero(); // node b seen from node j
		const real Ma = fa * M[j], Mb = fb * M[b], Mc = Ma + Mb, w = 1. / Mc;
		const Vec3 xm = 0.5 * (X[j] + X[b] + sh), xpm = 0.5 * (X_prev[j] + X_prev[b] + sh);
		const Vec3 vc = w * (Ma * V[j] + Mb * V[b]), vpc = w * (Ma * V_prev[j] + Mb * V_prev[b]);
		const Vec3 xcom = w * (Ma * X[j] + Mb * (X[b] + sh)), xpcom = w * (Ma * X_prev[j] + Mb * (X_prev[b] + sh));
		const real sc = fa * S[j] + fb * S[b];
		M[j] -= Ma; M[b] -= Mb; S[j] *= 1. - fa; S[b] *= 1. - fb;
		const bool both = pin_j || pin_b; // (equal shares: the centre of mass is the midpoint)
		const real Mfree = M[j] + M[b];
		const real wr = both ? 0. : Mc / Mfree;
		const Vec3 dx = wr * (xcom - xm), dxp = wr * (xpcom - xpm);
		if (!pin_j) { X[j] += dx; X_prev[j] += dxp; }
		if (!pin_b) { X[b] += dx; X_prev[b] += dxp; }
		X.insert(X.begin() + j + 1, both ? xcom : xm); V.insert(V.begin() + j + 1, vc);
		X_prev.insert(X_prev.begin() + j + 1, both ? xpcom : xpm); V_prev.insert(V_prev.begin() + j + 1, vpc);
		M.insert(M.begin() + j + 1, Mc); S.insert(S.begin() + j + 1, sc);
		return j + 1;
	}

	// Merge node b = j + 1 (mod n) into node j, perfectly inelastically (mass, momentum, centre of mass, history kept).
	// Returns the kinetic energy lost.
	real Merge_Nodes(int j)
	{
		const int n = Size(), b = (j + 1) % n;
		const Vec3 sh = (closed && b == 0) ? period : Vec3::Zero();
		const real loss = Merge(j, 1., M[b], S[b], X[b] + sh, V[b], X_prev[b] + sh, V_prev[b]);
		Erase(b);
		return loss;
	}

	void Erase(int k)
	{
		X.erase(X.begin() + k); V.erase(V.begin() + k); X_prev.erase(X_prev.begin() + k); V_prev.erase(V_prev.begin() + k);
		M.erase(M.begin() + k); S.erase(S.begin() + k);
	}

	real Mass() const { real m = 0.; for (real x : M) m += x; return m; }
	Vec3 Momentum() const { Vec3 p = Vec3::Zero(); for (int k = 0; k < Size(); k++) p += M[k] * V[k]; return p; }
	real Kinetic() const { real e = 0.; for (int k = 0; k < Size(); k++) e += 0.5 * M[k] * V[k].squaredNorm(); return e; }
};

// A rim chain in the plane spanned by e1 (outward from the film, towards the hole) and e2 (along the edge), periodic
// along e2 with period Lp: nodes sorted by their e2 coordinate, the last segment closing to the first node shifted by
// Lp. Its line energy is sigma times the signed polygon area  sum_seg 1/2 (u_a + u_b)(w_b - w_a)  (u = x.e1,
// w = x.e2), whose gradient is the line force sigma ds along -e1 on a straight edge.
struct Planar_Rim_Side {
	Vec3 e1 = Vec3::UnitX(), e2 = Vec3::UnitY();
	real Lp = 1.;
	std::vector<int> order; // node indices sorted by w

	void Sort(const Rim& R)
	{
		order.resize(R.Size());
		for (int k = 0; k < R.Size(); k++) order[k] = k;
		std::sort(order.begin(), order.end(), [&](int a, int b) { return R.X[a].dot(e2) < R.X[b].dot(e2); });
	}

	// sigma times the polygon area of chain positions x (in the order of `order`)
	real Energy(const std::vector<Vec3>& x, real sigma) const
	{
		const int n = (int)order.size();
		real a = 0.;
		for (int k = 0; k < n; k++) {
			const int i = order[k], j = order[(k + 1) % n];
			const real wi = x[i].dot(e2), wj = x[j].dot(e2) + (k + 1 == n ? Lp : 0.);
			a += 0.5 * (x[i].dot(e1) + x[j].dot(e1)) * (wj - wi);
		}
		return sigma * a;
	}

	// Implicit step of the chain: minimize sum M/(2 hh^2) |x - xt|^2 + sigma A(x) over the in-plane coordinates
	// (u, w) of every node. The area is quadratic, so one Newton step on the dense system is exact.
	void Solve(const Rim& R, const std::vector<Vec3>& xt, real hh, real sigma, std::vector<Vec3>& xn) const
	{
		const int n = (int)order.size();
		xn = xt;
		if (n == 0) return;
		Eigen::MatrixXd H = Eigen::MatrixXd::Zero(2 * n, 2 * n);
		Eigen::VectorXd g = Eigen::VectorXd::Zero(2 * n);
		// unknowns: (u_k, w_k) of node order[k]; start at the predictor
		std::vector<real> u(n), w(n);
		for (int k = 0; k < n; k++) { u[k] = xt[order[k]].dot(e1); w[k] = xt[order[k]].dot(e2); }
		for (int k = 0; k < n; k++) {
			const real c = R.M[order[k]] / (hh * hh);
			H(2 * k, 2 * k) += c; H(2 * k + 1, 2 * k + 1) += c; // inertia: gradient zero at the predictor
		}
		for (int k = 0; k < n; k++) {
			const int k1 = (k + 1) % n;
			const real wk1 = w[k1] + (k + 1 == n ? Lp : 0.);
			// a_seg = 1/2 (u_k + u_k1)(w_k1 - w_k)
			g[2 * k] += 0.5 * sigma * (wk1 - w[k]);
			g[2 * k1] += 0.5 * sigma * (wk1 - w[k]);
			g[2 * k + 1] -= 0.5 * sigma * (u[k] + u[k1]);
			g[2 * k1 + 1] += 0.5 * sigma * (u[k] + u[k1]);
			// d2 a / du_k dw_k1 = 1/2, d2 a / du_k dw_k = -1/2, d2 a / du_k1 dw_k1 = 1/2, d2 a / du_k1 dw_k = -1/2
			auto add = [&](int r, int c, real v) { H(r, c) += v; H(c, r) += v; };
			add(2 * k, 2 * k1 + 1, 0.5 * sigma);
			add(2 * k, 2 * k + 1, -0.5 * sigma);
			add(2 * k1, 2 * k1 + 1, 0.5 * sigma);
			add(2 * k1, 2 * k + 1, -0.5 * sigma);
		}
		const Eigen::VectorXd d = H.ldlt().solve(-g);
		for (int k = 0; k < n; k++) {
			const int i = order[k];
			xn[i] = xt[i] + d[2 * k] * e1 + d[2 * k + 1] * e2;
		}
	}

	// The segment (in `order`) that spans the edge coordinate wq, as node indices (a, b), the weight t of b, the
	// chain's e1 coordinate there, and the shift of b along e2 (0 or Lp) that makes the segment contiguous.
	// wq is taken modulo Lp.
	void Locate(const Rim& R, real wq, int& a, int& b, real& t, real& u, real& shift_b, real& shift_a) const
	{
		const int n = (int)order.size();
		wq -= Lp * std::floor(wq / Lp);
		// the caller keeps the nodes at w in [0, Lp); find the first node with w > wq
		int k = 0;
		while (k < n && R.X[order[k]].dot(e2) <= wq) k++;
		shift_a = 0.; shift_b = 0.;
		if (k == 0) { a = order[n - 1]; b = order[0]; shift_a = -Lp; }
		else if (k == n) { a = order[n - 1]; b = order[0]; shift_b = Lp; }
		else { a = order[k - 1]; b = order[k]; }
		const real wa = R.X[a].dot(e2) + shift_a, wb = R.X[b].dot(e2) + shift_b;
		t = wb > wa ? std::clamp((wq - wa) / (wb - wa), 0., 1.) : 0.5;
		u = (1. - t) * R.X[a].dot(e1) + t * R.X[b].dot(e1);
	}
};

} // namespace vf::coda
