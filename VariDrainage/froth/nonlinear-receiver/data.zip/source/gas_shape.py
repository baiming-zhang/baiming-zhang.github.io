"""Explicit gas inventories and native wet-shape relaxation, film-path baseline."""
from pathlib import Path
import csv,json,re,subprocess
import numpy as np

ROOT=Path(__file__).resolve().parents[2];R=.01;GAMMA=.03;RGAS=8.31446261815324;TEMP=298.15
RT=RGAS*TEMP;P0=100000.;PSCALE=2*GAMMA/R;ESCALE=2*GAMMA*R**2
H=6.4e-6;DGAS=2e-9;THICK=.8e-6;EXE=ROOT.parents[1]/'.tools/evolver270/evolver64.exe'

def load(n):
    folder=ROOT/'results/free-wet-conditioned';label='initial' if n==4 else 'final';name=f'wet{n}-s020'
    vp=folder/f'{name}-{label}-vertices.csv';fp=folder/f'{name}-{label}-triangles.csv'
    with vp.open() as f:vv=list(csv.DictReader(f))
    ids=[int(q['id']) for q in vv];lookup={k:i for i,k in enumerate(ids)}
    x=np.array([[float(q[k]) for k in ['x_over_R','y_over_R','z_over_R']] for q in vv])
    with fp.open() as f:rows=list(csv.DictReader(f))
    t=np.array([[lookup[int(q[k])] for k in ['v1','v2','v3']] for q in rows])
    front=np.array([int(q['front_body']) for q in rows]);back=np.array([int(q['back_body']) for q in rows]);kind=np.array([int(q['ftype']) for q in rows]);tension=np.array([float(q['tension_over_2gamma']) for q in rows])
    return x,t,front,back,kind,tension,[vp,fp]

def geometry(x,t,front,back,tension,n):
    p=x[t];cross=np.cross(p[:,1]-p[:,0],p[:,2]-p[:,0]);area=np.linalg.norm(cross,axis=1)/2
    normal=cross/(2*area[:,None]);vol=np.linalg.det(p)/6;V=np.zeros(n+2)
    np.add.at(V,front,vol);np.add.at(V,back,-vol)
    gs=np.zeros_like(x);gv=np.zeros((n+2,len(x),3))
    for a,b,c in [(0,1,2),(1,2,0),(2,0,1)]:
        np.add.at(gs,t[:,a],tension[:,None]*np.cross(p[:,b]-p[:,c],normal)/2)
        d=np.cross(p[:,b],p[:,c])/6
        np.add.at(gv,(front,t[:,a]),d);np.add.at(gv,(back,t[:,a]),-d)
    return V,area,gs,gv

def grand(N,V):
    u=(N-(P0/PSCALE)*V)/((P0/PSCALE)*V)
    return float(np.sum((P0/PSCALE)*V*((1+u)*np.log1p(u)-u)))

def force_ratio(N,V,gs,gv,n):
    g=gs.copy()
    for i in range(n):g+=(P0/PSCALE-N[i]/V[i+1])*gv[i+1]
    a=gv[n+1];g-=np.sum(g*a)/np.sum(a*a)*a
    return float(np.linalg.norm(g)/np.linalg.norm(gs))

def write_native(path,x,t,front,back,kind,tension,n,N,vref,liquid):
    lines=['// FROTH explicit amount/Helmholtz shape reference; not physical dynamics.',f'parameter ambient = {P0/PSCALE:.17g}','define facet attribute ftype integer']
    for i in range(1,n+1):
        lines += [f'parameter vref{i} = {vref[i-1]:.17g}',f'parameter amount{i} = {N[i-1]:.17g}',f'method_instance gv{i} method facet_vector_integral','vector_integrand:','q1: x/3','q2: y/3','q3: z/3',f'quantity ge{i} energy function ambient*(gv{i}.value-vref{i})-amount{i}*log(gv{i}.value/vref{i})']
    lines+=['vertices'];lines += [str(i+1)+' '+' '.join(f'{v:.17g}' for v in p) for i,p in enumerate(x)];lines+=['edges'];edges={}
    for tri in t:
        for a,b in zip(tri,np.roll(tri,-1)):
            key=tuple(sorted([int(a),int(b)]))
            if key not in edges:edges[key]=len(edges)+1;lines.append(f'{len(edges)} {key[0]+1} {key[1]+1}')
    lines+=['faces'];bodies={i:[] for i in range(1,n+2)}
    for k,tri in enumerate(t):
        es=[edges[tuple(sorted([int(a),int(b)]))]*(1 if a<b else -1) for a,b in zip(tri,np.roll(tri,-1))];inst=[]
        if front[k]:
            bodies[front[k]].append(k+1)
            if front[k]<=n:inst.append(f'gv{front[k]}')
        if back[k]:
            bodies[back[k]].append(-(k+1))
            if back[k]<=n:inst.append(f'gv{back[k]}-')
        lines.append(f'{k+1} '+' '.join(map(str,es))+f' tension {tension[k]:.17g} ftype {kind[k]} '+' '.join(inst))
    lines+=['bodies'];lines += [str(i)+' '+' '.join(map(str,ids))+(f' volume {liquid:.17g}' if i==n+1 else '') for i,ids in bodies.items()]
    lines+=['read','function_quantity_sparse on'];path.write_text('\n'.join(lines)+'\n',encoding='utf8')

def relax(prefix,x,t,front,back,kind,tension,n,N,vref,liquid,initial=False):
    path=prefix.with_suffix('.fe');write_native(path,x,t,front,back,kind,tension,n,N,vref,liquid)
    commands=['target_tolerance := 1e-12','U','g 80' if initial else 'g 10']+['hessian_seek']*(3 if initial else 1)
    commands += ['printf "ENERGY %.17g\\n",total_energy','foreach body bb do printf "BODY %d %.17g\\n",bb.id,bb.volume','foreach vertex vv do printf "VERTEX %d %.17g %.17g %.17g\\n",vv.id,vv.x,vv.y,vv.z','q','q']
    cmd='\n'.join(commands)+'\n';prefix.with_suffix('.cmd').write_text(cmd,encoding='utf8')
    p=subprocess.run([str(EXE),path.name],cwd=path.parent,input=cmd.encode('ascii'),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90)
    text=p.stdout.decode('cp1252',errors='replace');prefix.with_suffix('.txt').write_text(text,encoding='utf8')
    if p.returncode or 'ERROR ' in text:raise RuntimeError(f'native error: {prefix.name}')
    vv={int(i)-1:np.array([float(a),float(b),float(c)]) for i,a,b,c in re.findall(r'VERTEX (\d+) (\S+) (\S+) (\S+)',text)}
    if len(vv)!=len(x):raise RuntimeError('incomplete native vertices')
    nativeV={int(i):float(v) for i,v in re.findall(r'BODY (\d+) (\S+)',text)}
    return np.array([vv[i] for i in range(len(x))]),dict(energy=float(re.findall(r'ENERGY (\S+)',text)[0]),volumes=nativeV,
         warnings=[s for s in text.splitlines() if 'WARNING' in s],hessian_indices=[int(i) for i in re.findall(r'Index: (\d+)',text)])

def exchange(N,V,areas,front,back,kind,n,dt,closed=False,zero=False):
    L=np.zeros((n,n));external=np.zeros(n);edges=[]
    for a,b,area,k in zip(front,back,areas,kind):
        if k!=1 or zero or (closed and (a==0 or b==0)):continue
        rate=DGAS*H*(area*R**2)/THICK*RT/R**3
        if a and b:
            i,j=a-1,b-1;L[i,i]+=rate;L[j,j]+=rate;L[i,j]-=rate;L[j,i]-=rate
        else:
            i=(a or b)-1;L[i,i]+=rate;external[i]+=rate
        edges.append((a,b,rate))
    rhs=N+dt*external*(P0/PSCALE);A=np.diag(V)+dt*L;P=np.linalg.solve(A,rhs);new=V*P
    received=float(dt*np.dot(external,P-P0/PSCALE));diss=0.
    for a,b,rate in edges:
        pa=P[a-1] if a else P0/PSCALE;pb=P[b-1] if b else P0/PSCALE
        diss+=dt*rate*(pa-pb)*np.log(pa/pb)
    u=(new-N)/N;be=float(np.sum(N*(u-np.log1p(u))))
    return new,received,dict(graph_residual=float(np.linalg.norm(A@P-rhs)/np.linalg.norm(rhs)),
       grand_energy_residual=float(grand(new,V)-grand(N,V)+diss+be),dissipation=diss,backward_euler=be)
