"""Finite-area material liquid sheets and finite-rotation rigid recipient.

Supported post-contact experiment, not resolved border flow or a foam lifecycle.
All new code belongs to FROTH; consumes the frozen original CODA packet.
"""
from pathlib import Path
import csv, hashlib, json, time
import numpy as np
from rim_receiver import ROOT, OUT as PREVIOUS, assemble, RHO, H, TAG
from gas_shape import RT

OUT=ROOT/'results/nonlinear-receiver'
GAMMA=.03

def save(path,value):
    path.write_text(json.dumps(value,indent=2,default=lambda x:x.item()),encoding='utf8')

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def rotation(w):
    theta=np.linalg.norm(w)
    W=np.array([[0,-w[2],w[1]],[w[2],0,-w[0]],[-w[1],w[0],0]])
    a=np.sin(theta)/theta if theta>1e-7 else 1-theta**2/6
    b=(1-np.cos(theta))/theta**2 if theta>1e-7 else .5-theta**2/24
    return np.eye(3)+a*W+b*(W@W)

class Scene:
    def __init__(self,elastic=True):
        _,_,nodes,groups,meta,_=assemble()
        self.x0=np.array([n['position'] for n in nodes])
        self.m=np.array([n['mass'] for n in nodes])
        self.bound=np.array([not len(n['dof']) for n in nodes])
        self.free=~self.bound
        self.tri=np.array(meta['film_triangles'])
        self.groups=groups;self.meta=meta
        p=self.x0[self.tri];cross=np.cross(p[:,1]-p[:,0],p[:,2]-p[:,0])
        self.A0=np.linalg.norm(cross,axis=1)/2
        self.n0=cross/(2*self.A0[:,None])
        self.vol=H*self.A0;self.S=2*TAG*self.A0
        self.elastic=elastic
        self.packet=np.loadtxt(PREVIOUS/'main-contact.csv',delimiter=',',skiprows=1,ndmin=2)
        liquidmass=RHO*meta['liquid_volume_m3'];liquidC=np.array(meta['liquid_centroid_m'])
        xp=np.vstack([liquidC,self.x0[self.bound],self.packet[:,1:4]])
        mp=np.r_[liquidmass,self.m[self.bound],self.packet[:,7]]
        self.M=mp.sum();self.C0=np.sum(mp[:,None]*xp,axis=0)/self.M
        self.J=np.array(meta['liquid_inertia_kg_m2'])
        for m,x in zip(mp,xp):
            r=x-self.C0;self.J+=m*((r@r)*np.eye(3)-np.outer(r,r))
        self.invJ=np.linalg.inv(self.J)
        self.r=self.x0[self.bound]-self.C0
        self.P=np.sum(self.packet[:,7,None]*self.packet[:,4:7],axis=0)
        self.L=np.sum(np.cross(self.packet[:,1:4]-self.C0,self.packet[:,7,None]*self.packet[:,4:7]),axis=0)
        self.Eincoming=float(np.sum(.5*self.packet[:,7]*np.sum(self.packet[:,4:7]**2,axis=1)))
        _,self.g0,_,_=self.energy_gradient(self.x0)

    def energy_gradient(self,x):
        p=x[self.tri];cross=np.cross(p[:,1]-p[:,0],p[:,2]-p[:,0])
        area=np.linalg.norm(cross,axis=1)/2
        if np.any(area<=0) or not np.all(np.isfinite(area)):raise ValueError('degenerate/nonfinite area')
        n=cross/(2*area[:,None]);d=area/self.A0-1
        if self.elastic:
            tension=2*(GAMMA+RT*TAG)-RT*self.S/area
            e=float(np.sum(2*(GAMMA+RT*TAG)*self.A0*d-RT*self.S*np.log1p(d)))
        else:
            tension=np.full(len(area),2*GAMMA);e=float(2*GAMMA*np.sum(self.A0*d))
        gradient=np.zeros_like(x)
        for a,b,c in [(0,1,2),(1,2,0),(2,0,1)]:
            np.add.at(gradient,self.tri[:,a],.5*tension[:,None]*np.cross(p[:,b]-p[:,c],n))
        return e,gradient,area,tension

    def force(self,x,Q):
        e,g,area,tension=self.energy_gradient(x)
        # Lab-fixed external balancing forces with explicit potential/work.
        F=-g+self.g0
        rb=x[self.bound]-self.center
        force=F[self.bound].sum(0);torque=np.cross(rb,F[self.bound]).sum(0)
        external_torque=np.cross(x,self.g0).sum(0)
        orientation=np.sum((np.cross(x[self.tri][:,1]-x[self.tri][:,0],x[self.tri][:,2]-x[self.tri][:,0])/(2*area[:,None]))*(self.n0@Q.T),axis=1)
        if min(area/self.A0)<.1 or min(tension)<=0 or min(orientation)<=0:
            raise ValueError(f'physical/discrete gate: minA/A0={min(area/self.A0)}, min sigma={min(tension)}, min orientation={min(orientation)}')
        return F,force,torque,e,area,tension,external_torque

    def audit(self):
        rng=np.random.default_rng(61);x=self.x0+rng.normal(size=self.x0.shape)*1e-7
        direction=rng.normal(size=x.shape);direction/=np.linalg.norm(direction)
        e,g,_,_=self.energy_gradient(x);eps=1e-10
        fd=(self.energy_gradient(x+eps*direction)[0]-self.energy_gradient(x-eps*direction)[0])/(2*eps)
        exact=float(np.sum(g*direction));err=abs(fd-exact)/max(abs(exact),1e-30)
        Q=rotation(np.array([.2,-.3,.15]));y=x@Q.T+np.array([.001,.002,-.001])
        er,gr,_,_=self.energy_gradient(y)
        scale=2*GAMMA*self.A0.sum()
        result=dict(directional_gradient_error=err,energy_rigid_invariance=abs(e-er)/scale,
                    net_capillary_force=float(np.linalg.norm(g.sum(0))/np.linalg.norm(g)),
                    net_capillary_torque=float(np.linalg.norm(np.cross(x,g).sum(0))/(.01*np.linalg.norm(g))),
                    rotated_gradient_error=float(np.linalg.norm(gr-g@Q.T)/np.linalg.norm(g)))
        result['passed']=err<1e-6 and all(result[k]<1e-10 for k in result if k!='directional_gradient_error')
        return result

    def run(self,name,dt,erased=False,end=.002):
        x=self.x0.copy();v=np.zeros_like(x);Q=np.eye(3);self.center=self.C0.copy()
        V=np.zeros(3) if erased else self.P/self.M
        L=np.zeros(3) if erased else self.L.copy()
        E0=float(.5*self.M*(V@V)+.5*L@(self.invJ@L));energy_scale=max(E0,.5*np.dot(self.P,self.P)/self.M,1e-30)
        expectedP=self.M*V;expectedL=np.cross(self.center,self.M*V)+L
        Pscale=np.linalg.norm(self.P);Lscale=max(np.linalg.norm(np.cross(self.packet[:,1:4],self.packet[:,7,None]*self.packet[:,4:7]).sum(0)),.01*Pscale)
        externalL=np.zeros(3);history=[];frames=[];maxE=maxP=maxL=maxmove=0.;minH=np.inf;minSigma=np.inf;status='completed';failure=None
        force=self.force(x,Q);steps=round(end/dt);save_stride=round(1e-5/dt);hist_stride=round(5e-6/dt)
        start=time.perf_counter()
        def readout(step,record=False):
            nonlocal maxE,maxP,maxL,minH,minSigma,maxmove
            F,Fb,Tb,e,area,tension,extT=force
            KE=float(.5*self.M*(V@V)+.5*L@(Q@self.invJ@Q.T@L)+.5*np.sum(self.m[self.free,None]*v[self.free]**2))
            work=float(np.sum(self.g0*(x-self.x0)));E=KE+e-work
            P=self.M*V+np.sum(self.m[self.free,None]*v[self.free],axis=0)
            angular=np.cross(self.center,self.M*V)+L+np.cross(x[self.free],self.m[self.free,None]*v[self.free]).sum(0)
            ee=abs(E-E0)/energy_scale;pe=np.linalg.norm(P-expectedP)/Pscale;le=np.linalg.norm(angular-expectedL-externalL)/Lscale
            h=self.vol/area;Gamma=self.S/(2*area);move=float(np.max(np.linalg.norm(x-self.x0,axis=1)))
            maxE=max(maxE,ee);maxP=max(maxP,pe);maxL=max(maxL,le);minH=min(minH,float(h.min()));minSigma=min(minSigma,float(tension.min()/2));maxmove=max(maxmove,move)
            if step%hist_stride==0 or record:history.append([step,step*dt,KE,e,work,E,ee,pe,le,float(h.min()),float(h.max()),float(tension.min()/2),move,*externalL])
            if step%save_stride==0 or record:frames.append(dict(time=step*dt,x=x.copy(),v=v.copy(),Q=Q.copy(),C=self.center.copy(),V=V.copy(),L=L.copy(),area=area.copy(),h=h.copy(),Gamma=Gamma.copy(),gamma=tension.copy()/2))
        readout(0)
        for step in range(1,steps+1):
            F,Fb,Tb,*_=force
            V+=dt/2*Fb/self.M;L+=dt/2*Tb;v[self.free]+=dt/2*F[self.free]/self.m[self.free,None]
            externalL+=dt/2*force[-1]
            self.center+=dt*V;x[self.free]+=dt*v[self.free]
            omega=Q@self.invJ@Q.T@L
            for _ in range(4):
                mid=rotation(dt/2*omega)@Q;omega=mid@self.invJ@mid.T@L
            Q=rotation(dt*omega)@Q;x[self.bound]=self.center+self.r@Q.T
            try:force=self.force(x,Q)
            except ValueError as error:
                status='failed';failure=dict(step=step,time_s=step*dt,reason=str(error));break
            F,Fb,Tb,*_=force
            V+=dt/2*Fb/self.M;L+=dt/2*Tb;v[self.free]+=dt/2*F[self.free]/self.m[self.free,None]
            externalL+=dt/2*force[-1];readout(step,step==steps)
            if step%2000==0:print(name,step,'/',steps,'min h',minH,'E error',maxE,flush=True)
        if status=='failed':
            np.savez_compressed(OUT/(name+'-failed.npz'),x=x,v=v,Q=Q,C=self.center,V=V,L=L)
        np.savez_compressed(OUT/(name+'-frames.npz'),**{key:np.array([q[key] for q in frames]) for key in frames[0]})
        with (OUT/(name+'-history.csv')).open('w',newline='') as f:
            w=csv.writer(f);w.writerow(['step','time_s','kinetic_J','capillary_change_J','preload_work_J','supported_energy_J','energy_error_received','linear_impulse_error','angular_impulse_error','min_h_m','max_h_m','min_gamma_N_m','max_displacement_m','external_Lx','external_Ly','external_Lz']);w.writerows(history)
        checks=dict(completed=status=='completed',energy_1pct=maxE<.01,momentum=maxP<1e-5,angular_with_preload=maxL<1e-5,positive_thickness=minH>0,positive_tension=minSigma>0,inelastic_loss=self.Eincoming-E0>=-1e-15)
        result=dict(name=name,dt_s=dt,steps_completed=step if status=='completed' else step-1,status=status,failure=failure,elastic=self.elastic,erased=erased,
            received_energy_J=E0,incoming_energy_J=self.Eincoming,inelastic_loss_J=self.Eincoming-E0,
            maximum_energy_error_received=maxE,maximum_linear_impulse_error=maxP,maximum_angular_impulse_error=maxL,
            minimum_thickness_m=minH,minimum_surface_tension_N_m=minSigma,maximum_displacement_m=maxmove,
            final_rotation_rad=float(np.arccos(np.clip((np.trace(Q)-1)/2,-1,1))),
            external_sink_linear=(-self.P if erased else np.zeros(3)).tolist(),external_sink_angular=(-np.sum(np.cross(self.packet[:,1:4],self.packet[:,7,None]*self.packet[:,4:7]),axis=0) if erased else np.zeros(3)).tolist(),
            checks=checks,elapsed_seconds=time.perf_counter()-start)
        save(OUT/(name+'-summary.json'),result);return result

def main():
    OUT.mkdir(exist_ok=True);scene=Scene();audit=scene.audit();save(OUT/'derivative-audit.json',audit)
    if not audit['passed']:raise RuntimeError(f'failed force preflight {audit}')
    source=[Path(__file__),ROOT/'foam/docs/nonlinear_receiver_protocol.md',ROOT/'foam/scripts/rim_receiver.py',PREVIOUS/'main-contact.csv',PREVIOUS/'geometry.npz']
    save(OUT/'protocol.json',dict(sources={str(p.relative_to(ROOT)):sha(p) for p in source},scope='supported finite-area material-sheet response, rigid connected border carrier; not local PB or autonomous rupture',dt_s=2.5e-7,end_s=.002,Gamma0_mol_m2=TAG,h0_m=H,gamma0_N_m=GAMMA,RT_J_mol=RT,rho_kg_m3=RHO,training=False))
    np.savez_compressed(OUT/'geometry.npz',x0=scene.x0,tri=scene.tri,area0=scene.A0,volume=scene.vol,surface_amount=scene.S,mass=scene.m,boundary=scene.bound,preload=scene.g0,body_mass=scene.M,body_COM0=scene.C0,body_inertia=scene.J,packet=scene.packet)
    runs=[]
    for name,dt,elastic,erased in [('active',2.5e-7,True,False),('half',1.25e-7,True,False),('constant',2.5e-7,False,False),('erased',2.5e-7,True,True)]:
        runs.append(Scene(elastic).run(name,dt,erased));save(OUT/'progress.json',dict(completed=name))
    a=np.load(OUT/'active-frames.npz');b=np.load(OUT/'half-frames.npz');c=np.load(OUT/'constant-frames.npz')
    compare=dict(final_thickness_half_relative=float(np.linalg.norm(a['h'][-1]-b['h'][-1])/np.linalg.norm(b['h'][-1])),
                 final_response_half_relative=float(np.linalg.norm(a['x'][-1]-b['x'][-1])/max(np.linalg.norm(b['x'][-1]-scene.x0),1e-30)),
                 final_thickness_constitutive_difference=float(np.linalg.norm(a['h'][-1]-c['h'][-1])/np.linalg.norm(a['h'][-1])))
    compare['time_1pct_pass']=compare['final_thickness_half_relative']<.01 and compare['final_response_half_relative']<.01
    save(OUT/'summary.json',dict(runs=runs,comparisons=compare,force_audit=audit,scope='supported isolated nonlinear neighbour response; complete lifecycle remains open'))
    print(json.dumps(compare,indent=2),flush=True)

if __name__=='__main__':main()
