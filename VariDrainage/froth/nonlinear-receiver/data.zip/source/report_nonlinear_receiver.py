"""White scientific PNG/vector PDF and standalone actual saved-state viewer."""
from pathlib import Path
import json,hashlib,zipfile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap,TwoSlopeNorm
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'results/nonlinear-receiver'
BLUE='#3b6da8';RED='#c44e52'

def main():
    s=json.loads((OUT/'summary.json').read_text());audit=json.loads((OUT/'independent-audit.json').read_text());g=dict(np.load(OUT/'geometry.npz'));data={name:dict(np.load(OUT/(name+'-frames.npz'))) for name in ['active','constant','half','erased']}
    histories={name:np.genfromtxt(OUT/(name+'-history.csv'),delimiter=',',names=True) for name in data}
    tri=g['tri'];cmap=LinearSegmentedColormap.from_list('nature_diverging',[BLUE,'#f4f4f4',RED])
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
    fig=plt.figure(figsize=(12.6,8.7),facecolor='white');gs=fig.add_gridspec(2,3,wspace=.42,hspace=.42)
    for k,(name,limit,title) in enumerate([('active',.5,'Surface amount affects tension'),('constant',45,'Constant-tension control')]):
        ax=fig.add_subplot(gs[0,k],projection='3d');z=data[name];pts=z['x'][-1][tri].mean(1)*1000;field=100*(z['h'][-1]/8e-7-1)
        sc=ax.scatter(*pts.T,c=field,cmap=cmap,vmin=-limit,vmax=limit,s=10,depthshade=False)
        center=(g['x0'].max(0)+g['x0'].min(0))/2*1000;r=np.ptp(g['x0'],axis=0).max()*550
        ax.set(xlim=(center[0]-r,center[0]+r),ylim=(center[1]-r,center[1]+r),zlim=(center[2]-r,center[2]+r));ax.set_box_aspect((1,1,1));ax.set_axis_off();ax.view_init(20,35);ax.set_title(title,pad=14)
        bar=fig.colorbar(sc,ax=ax,shrink=.66,pad=.01,label='Thickness change / %')
        bar.solids.set_rasterized(False)
        bar.solids.set_edgecolor('face')
    ax=fig.add_subplot(gs[0,2]);ax.axis('off');ax.text(0,1,'Identical real contact packet',weight='bold',fontsize=12,va='top')
    ax.text(0,.83,'Incoming liquid: 1.121 micrograms\nIncoming speed: 8.652 m/s\nReceived energy: 4.884e-11 J\n\nNine finite-area liquid films\n292 material triangles / 209 nodes\nFull finite rotation of recipient\nNo reduced impulse',va='top',color=BLUE,linespacing=1.65)
    ax=fig.add_subplot(gs[1,0])
    for name,col,label in [('active',BLUE,'active surface'),('constant',RED,'constant tension')]:
        h=histories[name];ax.plot(h['time_s']*1000,h['min_h_m']*1e6,c=col,label=label)
    ax.axhline(.8,c='#8c969f',ls=':',lw=1);ax.set(xlabel='Time after contact / ms',ylabel='Minimum thickness / micrometers',title='Thickness follows material area');ax.legend(frameon=False,fontsize=9)
    ax=fig.add_subplot(gs[1,1]);a=data['active'];b=data['half']
    numerator=np.linalg.norm(a['h']-b['h'],axis=1);denominator=np.linalg.norm(b['h']-8e-7,axis=1);relative=np.divide(numerator,denominator,out=np.zeros_like(numerator),where=denominator>1e-20)
    ax.semilogy(a['time'][1:]*1000,np.maximum(relative[1:],1e-12),color=BLUE);ax.axhline(.01,c=RED,ls='--',lw=1,label='1% target')
    ax.set(xlabel='Time after contact / ms',ylabel='Paired thickness-increment difference',title='Time check on the same mesh');ax.legend(frameon=False,fontsize=9)
    ax=fig.add_subplot(gs[1,2]);ax.axis('off');ax.text(0,1,'Supported post-contact response',weight='bold',fontsize=12,va='top')
    ax.text(0,.82,'Initial gas/meniscus forces replaced\nby explicit lab-fixed preloads.\nPreload work: up to 13.33% of\nreceived energy in the active case.\n\nRigid whole-liquid recipient remains.\nNo local border flow or extraction.\nNo drainage/coarsening/event loop.\nNo subsequent rupture claimed.',va='top',color=RED,linespacing=1.55)
    fig.suptitle('Real rim impulse -> finite-area films -> thickness / surface-tension feedback',x=.04,ha='left',fontsize=17,y=.98)
    fig.text(.04,.025,'Actual saved states at 2 ms; geometry is not magnified. Different, explicitly labelled colour ranges. Inviscid insoluble diagnostic.',color='#596878',fontsize=9)
    fig.subplots_adjust(left=.07,right=.97,bottom=.10,top=.89);fig.savefig(OUT/'nonlinear-receiver.png',dpi=180);fig.savefig(OUT/'nonlinear-receiver.pdf');plt.close(fig)
    indices=np.arange(0,len(data['active']['time']),10);payload=dict(tri=tri.tolist(),center=((g['x0'].max(0)+g['x0'].min(0))/2).tolist(),span=float(np.ptp(g['x0'],axis=0).max()),times=data['active']['time'][indices].tolist(),cases={})
    for name in ['active','constant']:
        payload['cases'][name]=dict(x=data[name]['x'][indices].tolist(),h=(data[name]['h'][indices]/8e-7).tolist())
    html='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>FROTH · 实际冲量与膜厚—张力响应</title><style>:root{color-scheme:light}*{box-sizing:border-box}body{margin:0;background:#fff;color:#243140;font:16px/1.8 system-ui,sans-serif}main{max-width:1140px;margin:auto;padding:32px 22px}h1{font-size:clamp(28px,4vw,44px);line-height:1.3}h2{margin-top:34px}a{color:#3b6da8}img{display:block;width:100%;height:auto}.tag{color:#c44e52;font-weight:700}.note{padding:18px;background:#faf5f5;border-left:4px solid #c44e52}.pair{display:grid;grid-template-columns:1fr 1fr;gap:20px}.pair>div{min-width:0}canvas{display:block;width:100%;aspect-ratio:1;background:white;border:1px solid #e1e5eb;touch-action:none}input{width:100%;accent-color:#3b6da8}button{background:#fff;border:1px solid #cbd5df;border-radius:4px;padding:8px 14px;color:#243140}.muted{font-size:14px;color:#596878}table{border-collapse:collapse;width:100%}td,th{padding:10px;text-align:left;border-bottom:1px solid #e1e5eb}.table{overflow:auto}select{max-width:100%;padding:6px}@media(max-width:700px){.pair{grid-template-columns:1fr}}</style><main><a href="../index.html">← FROTH</a><p class="tag">FINITE-AREA MATERIAL FILMS · SUPPORTED POST-CONTACT EXPERIMENT</p><h1>同一真实冲量，现在会改变膜厚与张力</h1><p>沿用实际四泡共享膜第一次回缩接触的原始质量与冲量，不缩小输入。把其余九张膜从法向线性响应改为有限面积液膜：面片液体体积及两界面表活量随材料搬运，面积决定厚度，局部浓度参与张力，作用力包含面内与法向分量。</p><div class="note">四组40,000步、2ms接收后响应已执行。最薄处：活跃表活—张力反馈约0.7963μm，恒张力对照约0.6491μm；终态厚度场差4.75%。这是同一受控模型内的本构消融，不是寿命、稳定性或下一次破裂的预测。</div><img src="nonlinear-receiver.png" alt="实际材料面片厚度、同冲量对照与时间步检查"><p><a href="nonlinear-receiver.png">PNG</a> · <a href="nonlinear-receiver.pdf">矢量PDF</a></p>
    <h2>播放真实保存的接收后状态</h2><p class="muted">两个视图共用相机，拖动任意视图旋转；圆盘是实际材料三角面片的中心，按其实际厚度着色。位置没有放大，没有时间插值。回放取201份保存状态中的21份，每100μs一帧；不是前一阶段液环继续回缩的动画。细微位移在整个泡簇尺度上本来就很小。</p><label>颜色范围 <select id="scale"><option value="separate">分别显示：反馈±0.5%，恒张力±45%</option><option value="common">统一范围：两侧±45%</option></select></label><div class="pair"><div><h3>表活—张力反馈</h3><canvas id="active" aria-label="实际反馈液膜"></canvas><p class="legend" id="active-legend"></p></div><div><h3>恒张力对照</h3><canvas id="constant" aria-label="实际恒张力对照"></canvas><p class="legend" id="constant-legend"></p></div></div><input id="frame" aria-label="保存状态" type="range" min="0" value="0"><button id="play">播放保存帧</button><p id="label"></p>
    <h2>这次新增的物理状态</h2><p>292片材料三角形保持各自液体体积 V 与总界面表活量 S，厚度 h=V/A、单界面浓度 Γ=S/(2A)。使用精确三角形面积能及其梯度，提供全部三维作用力；没有面内剪切弹簧。稀溶液不溶表活参考自由能产生 γ=γ₀+RTΓ₀−RTΓ；本次γ₀=0.03N/m、Γ₀=10⁻⁶mol/m²、h₀=0.8μm均为诊断输入，未标定真实配方。恒张力对照保持同一质量、表活量、初始张力与入射包。</p><p>接收体包含原连通液体、边界膜面片的集总质量及原始入射点质量；真实质心和惯量决定平移、转动。采用有限旋转与独立的膜内部世界坐标，初始接收能与旧线性接口一致，但后续运动不使用无穷小旋转。</p>
    <h2>不能隐藏的支撑与限制</h2><p>原四泡几何尚未平衡，当前没有自主气体压力和局部Plateau流动。为单独测量冲击响应，显式施加等于初始毛细力梯度的实验室固定节点预载，使无冲量对照保持静止；其保守势、做功和角冲量全部进入账目。主例预载做功最大达到接收能量的13.33%，不能忽略或把结果说成自由泡沫。</p><p>整个连通边界液体仍是一个刚性整体，收到的表活量仅进入该接收体库存，没有自动分配到邻膜。膜内为无黏、不溶表活、无扩散的材料面片极限；缺少近弯月面剪切、吸脱附、液体抽取、膜厚梯度与分离压、自接触、继续回缩及拓扑变化。没有人为设置后续开孔时间或顺序，也未与慢排液、粗化闭环。</p>
    <h2>从保存位置独立核算</h2><p>真实位置重建面积、厚度、浓度和张力，材料体积／表活量误差约2.22×10⁻¹⁶；实际液体体积与惯量另用四点二次体积分复核。主例线冲量误差约1.1×10⁻¹³，实际角冲量加预载输入误差约1.6×10⁻¹⁵。以接收后的微小能量为分母，主例最大能量误差约4.06×10⁻⁷，没有用大背景能量稀释误差。</p><p>半步2ms终态响应位移差0.00331%；厚度增量场差0.0569%，原厚度场差0.0000793%。这些是同一空间离散上的时间检查，尚无空间或实验验证。旧法向线性模型完整梯度0.334超过0.01的失败保持归档；新模型主例完整相对梯度约0.0849，恒张力约0.359，采用有限变形计算，不能把旧线性门槛标为通过。</p>
    <div class="table"><table><tr><th>对照</th><th>输入／作用</th><th>已执行</th></tr><tr><td>主例</td><td>原始冲量＋活跃表活张力</td><td>8,000步</td></tr><tr><td>半时间步</td><td>同一个入射包与本构</td><td>16,000步</td></tr><tr><td>恒张力</td><td>相同初始张力，关闭浓度对张力反馈</td><td>8,000步</td></tr><tr><td>冲量擦除</td><td>保留相同接收质量／表活量，冲量记入明确外部汇</td><td>8,000步，静止</td></tr></table></div>
    <h2>原始证据与接下来的完整场景</h2><p><a href="summary.json">结果与原门槛</a> · <a href="protocol.json">运行源哈希／输入</a> · <a href="independent-audit.json">保存几何与真实冲量审计</a> · <a href="derivative-audit.json">有限变形能量梯度核对</a> · <a href="data.zip">全部201帧／原始场／源码／日志ZIP</a> · <a href="../rim-receiver/index.html">入射包来自哪里</a></p><p>下一步必须把刚性整体替换为局部边界液体及界面转移，再继续整张膜回缩／拓扑、气体压力与排液粗化。该阶段提供的是同场景中新增的厚度—张力反馈，完整原始目标保持不变。</p><p class="muted">已有先例：<a href="https://arxiv.org/abs/2011.13658">Bussonnière–Cantat：近弯月面剪切、表活与界面转移</a>；<a href="https://pub.ista.ac.at/group_wojtan/projects/2020_Ishida_ThinFilms/soapfilm_with_thickness.pdf">Ishida等：演化膜厚及删膜质量转移</a>。厚度演化、界面弹性和有限转动不作为新贡献。论文已保存在本地，本阶段未复现其实验。CPU确定性计算，无机器学习训练。</p></main>
    <script>const data=PAYLOAD;let frame=0,yaw=.6,pitch=.3,drag=false,last,timer=null;const slider=document.querySelector('#frame'),scale=document.querySelector('#scale');slider.max=data.times.length-1;
    function project(v,c){let r=v.map((x,k)=>(x-data.center[k])/data.span),a=Math.cos(yaw)*r[0]-Math.sin(yaw)*r[1],b=Math.sin(yaw)*r[0]+Math.cos(yaw)*r[1];return [c.width*(.5+.78*a),c.width*(.5-.78*(Math.cos(pitch)*r[2]-Math.sin(pitch)*b))]}
    function colour(value,limit){let f=Math.min(1,Math.abs(value)/limit),end=value<0?[59,109,168]:[196,78,82];return 'rgb('+end.map(q=>Math.round(244+(q-244)*f)).join(',')+')'}
    function draw(){for(const name of ['active','constant']){let c=document.getElementById(name),ctx=c.getContext('2d'),z=data.cases[name],points=z.x[frame],limit=scale.value==='common'?45:name==='active'?.5:45;c.width=Math.round(c.clientWidth*devicePixelRatio);c.height=c.width;ctx.fillStyle='#fff';ctx.fillRect(0,0,c.width,c.height);data.tri.forEach((t,i)=>{let v=[0,1,2].map(k=>t.reduce((s,j)=>s+points[j][k],0)/3),p=project(v,c);ctx.fillStyle=colour((z.h[frame][i]-1)*100,limit);ctx.strokeStyle='#8493a1';ctx.lineWidth=.35*devicePixelRatio;ctx.beginPath();ctx.arc(...p,2.5*devicePixelRatio,0,Math.PI*2);ctx.fill();ctx.stroke()});document.getElementById(name+'-legend').textContent='蓝 −'+limit+'% → 白 0 → 红 +'+limit+'% · 实际 h/h₀ '+Math.min(...z.h[frame]).toFixed(5)+'–'+Math.max(...z.h[frame]).toFixed(5)}document.querySelector('#label').textContent='保存帧 '+frame+' / '+(data.times.length-1)+' · 接触后 '+(1000*data.times[frame]).toFixed(2)+' ms';}
    slider.oninput=()=>{frame=+slider.value;draw()};scale.onchange=draw;document.querySelector('#play').onclick=()=>{if(timer){clearInterval(timer);timer=null;return}if(frame===data.times.length-1)frame=0;timer=setInterval(()=>{frame++;slider.value=frame;draw();if(frame===data.times.length-1){clearInterval(timer);timer=null}},140)};for(const c of document.querySelectorAll('canvas')){c.onpointerdown=e=>{drag=true;last=[e.clientX,e.clientY];c.setPointerCapture(e.pointerId)};c.onpointermove=e=>{if(drag){yaw+=(e.clientX-last[0])*.01;pitch+=(e.clientY-last[1])*.01;last=[e.clientX,e.clientY];draw()}};c.onpointerup=()=>drag=false;new ResizeObserver(draw).observe(c)}draw();</script></html>'''
    (OUT/'index.html').write_text(html.replace('PAYLOAD',json.dumps(payload,separators=(',',':'))),encoding='utf8')
    sources=[ROOT/'foam/scripts/nonlinear_receiver.py',ROOT/'foam/scripts/audit_nonlinear_receiver.py',Path(__file__),ROOT/'foam/docs/nonlinear_receiver_protocol.md']
    (OUT/'readout-provenance.json').write_text(json.dumps({str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},indent=2),encoding='utf8')
    with zipfile.ZipFile(OUT/'data.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in OUT.iterdir():
            if p.suffix in ['.csv','.npz','.json'] and p.name!='progress.json':z.write(p,p.name)
        for p in sources:z.write(p,'source/'+p.name)
        for name in ['rim_receiver.py','gas_shape.py']:z.write(ROOT/'foam/scripts'/name,'source/'+name)
        z.write(ROOT/'results/logs/nonlinear-receiver.txt','logs/run.txt');z.write(ROOT/'results/logs/nonlinear-receiver-audit.txt','logs/audit.txt');z.write(ROOT/'results/rim-receiver/main-contact.csv','source/main-contact.csv');z.write(ROOT/'results/rim-receiver/geometry.npz','source/rim-geometry.npz')
    print('Nonlinear liquid-film report, PNG/vector PDF and raw evidence package written')

if __name__=='__main__':main()
