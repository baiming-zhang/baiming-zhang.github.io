# Finite-deformation, liquid-thickness/surface-amount neighbour response

Frozen before execution, 2026-11-13. Continue the actual wet4 first-contact scene;
do not rerun or attenuate its incoming CODA packet. This stage replaces the
normal-only, infinitesimal neighbour law, not the full lifecycle objective.

## Physical scope and prior work

Bussonniere & Cantat, JFM922 A25 (2021), author preprint
https://arxiv.org/pdf/2011.13658, sections II--III, identifies material-element
volume conservation, extension/thickness, interfacial elasticity and meniscus
transfer. Its SDS/dodecanol/glycerol chemistry and measured elasticity are NOT
inputs or validation for our dilute diagnostic. Ishida et al., TOG39(4),31(2020),
https://pub.ista.ac.at/group_wojtan/projects/2020_Ishida_ThinFilms/soapfilm_with_thickness.pdf,
already evolves thickness and transfers deleted-film mass; finite-speed actual
rim/recipient coupling is the distinction to investigate, not thickness alone.
Publisher/source screening retained separately. Neither paper is reproduced here.

Keep all nine actual remaining films, their connectivity and physical masses.
Each material triangle keeps volume V_t=h0*A0 and two-interface amount
S_t=2*Gamma0*A0. Its current thickness h=V_t/A and surface excess Gamma=S_t/(2A).
No artificial shear spring. Full nonlinear triangle area and analytic area
gradient supply the force in ALL three spatial directions. No normal-only
projection. The dilute insoluble surface reference has

    f(A,S)=2*(gamma0+RT*Gamma0)*A + RT*S*(log(S/(2*Gamma0*A))-1),
    df/dA=2*(gamma0+RT*Gamma0)-RT*S/A = 2*gamma(Gamma).

gamma0=.03N/m, Gamma0=1e-6mol/m2, rho1000kg/m3, h0=.8um,
T298.15K are diagnostic choices, not calibrated SDS. Gamma0 implies initial
Gibbs elasticity RT*Gamma0=.002479N/m/interface. With elasticity disabled, keep
the SAME mass/amount and initial tension but use f=2*gamma0*A. This is an
inviscid, insoluble, material-triangle limit; no diffusion, adsorption, local
meniscus extraction, viscous shear, disjoining pressure, film self-contact or
actual rupture criterion. Surface amount is now mechanically active within
these films, while the RECEIVED packet amount stays in the recipient ledger.

The whole actual connected border-liquid body remains one rigid carrier.
Include lumped boundary-film mass and the incoming point mass in its exact
COM/inertia; free film interior nodes have independent world velocities.
Finite rotations replace the old infinitesimal floating-frame kinematics.
Initial contact is perfectly inelastic and uncalibrated, as before; infer body
translation/spin from the actual incoming linear and orbital angular impulse.
No impulse goes directly to interior film nodes. Track mass/amount destinations.

Native reference geometry is not equilibrated and gas/PB mechanics are absent.
Hold it at rest by explicit LAB-FIXED nodal preload equal to the initial
capillary energy gradient. Include its exact conservative potential
-sum(g0*(x-x0)), work, force and torque. This is a supported post-contact
experiment, NOT autonomous free foam or a hidden equilibrium assertion.
Compare zero-impulse with identical added mass/amount; it must remain at rest.

Integrate translation/interior nodes by velocity Verlet and rigid orientation
by midpoint exponential drift with world angular momentum. Fixed end2ms;
dt2.5e-7s and half1.25e-7s (8,000/16,000 steps). Run FOUR cases only:
active surface response, same-packet half-time control, constant-tension
surface-law control, and same-mass/amount zero-impulse external-sink control.
No further parameter/mesh sweep this stage. Stop on nonpositive tension,
area below.1 initial, inversion relative to carrier-rotated reference normal,
or nonfinite state; save failure, do not clip areas/tensions or create holes.

## Gates and retained evidence

Directional analytic area/free-energy derivative relative error<1e-6;
translation/rotation invariance of physical capillary energy and force/torque
balance<1e-10 on a finite synthetic deformation of this actual geometry.
Fixed material volumes and surface amounts reconstructed from saved A,h,Gamma
agree<1e-12. No deletion or remapping in this stage.
Full physical+preload energy error normalized to RECEIVED post-inelastic energy
<1%; also report normalization by initial capillary energy, never replace the
former with the easier denominator. Track true momentum/angular impulse plus
explicit preload impulses (<1e-5 relative target), and inelastic loss>=0.
Half-time paired final thickness field difference<1%, displacement difference
<1% of nonzero response; no spatial convergence claim. Save raw trajectories,
triangle thickness/Gamma/tension, preloads and packet/source hashes.
Keep full deformation gradient diagnostics; the old linear.01 gate is archived,
not turned green. This nonlinear law has its OWN physical omissions above.

Required next lifecycle steps remain spatial border flow/transfer, continuing
retraction/topology and coupling to drainage/coarsening-generated states. No
claim of event memory or predicted propagation until those comparisons exist.
