"""Independent saved-geometry/energy/momentum reconstruction, no dynamics rerun."""
import json,hashlib
import numpy as np
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'results/nonlinear-receiver'

def main():
    protocol=json.loads((OUT/'protocol.json').read_text());g=np.load(OUT/'geometry.npz');summary=json.loads((OUT/'summary.json').read_text())
    RT=protocol['RT_J_mol'];gamma0=protocol['gamma0_N_m'];tag=protocol['Gamma0_mol_m2'];rho=protocol['rho_kg_m3']
    x0=g['x0'];tri=g['tri'];bound=g['boundary'];free=~bound;m=g['mass'];packet=g['packet'];preload=g['preload']
    # Separate degree-two tetrahedral quadrature of actual oriented liquid shell.
    old=np.load(ROOT/'results/rim-receiver/geometry.npz');x=old['points'];tt=old['tets'];f=old['front'];b=old['back'];s=(f==5).astype(int)-(b==5).astype(int)
    pp=x[tt];signed=s*np.linalg.det(pp)/6;v=signed.sum();a=.5854101966249685;beta=.1381966011250105
    bary=np.full((4,4),beta);np.fill_diagonal(bary,a)
    tet=np.concatenate([np.zeros((len(pp),1,3)),pp],axis=1);q=np.einsum('ij,tjk->tik',bary,tet)
    first=np.sum(signed[:,None]*q.mean(1),axis=0);C=first/v
    cov=np.einsum('t,tij,tik->jk',signed/4,q,q)-v*np.outer(C,C)
    J=rho*(np.trace(cov)*np.eye(3)-cov)
    masses=np.r_[rho*v,m[bound],packet[:,7]];locations=np.vstack([C,x0[bound],packet[:,1:4]])
    M=masses.sum();bodyC=np.sum(masses[:,None]*locations,axis=0)/M
    for mass,pos in zip(masses,locations):
        r=pos-bodyC;J+=mass*((r@r)*np.eye(3)-np.outer(r,r))
    geom=dict(body_mass_error=abs(M/float(g['body_mass'])-1),body_COM_error_m=float(np.linalg.norm(bodyC-g['body_COM0'])),
              body_inertia_error=float(np.linalg.norm(J-g['body_inertia'])/np.linalg.norm(J)),positive_inertia=bool(np.min(np.linalg.eigvalsh(J))>0))
    P0=np.sum(packet[:,7,None]*packet[:,4:7],axis=0);L0=np.cross(packet[:,1:4],packet[:,7,None]*packet[:,4:7]).sum(0)
    reports=[]
    for run in summary['runs']:
        name=run['name'];z=np.load(OUT/(name+'-frames.npz'));hist=np.genfromtxt(OUT/(name+'-history.csv'),delimiter=',',names=True)
        by_time={round(float(row['time_s']),12):row for row in hist}
        maxA=maxh=maxS=maxV=maxG=maxgamma=maxE=maxP=maxL=maxBC=0.;deform=[];minquality=1.
        E0=run['received_energy_J'];scale=max(E0,.5*np.dot(P0,P0)/M,1e-30);expectedP=np.zeros(3) if run['erased'] else P0;expectedL=np.zeros(3) if run['erased'] else L0
        for k,time in enumerate(z['time']):
            xx=z['x'][k];p=xx[tri];cr=np.cross(p[:,1]-p[:,0],p[:,2]-p[:,0]);A=np.sqrt(np.sum(cr**2,axis=1))/2
            h=g['volume']/A;Gamma=g['surface_amount']/(2*A)
            ratio=A/g['area0'];sig=2*(gamma0+RT*tag)-RT*g['surface_amount']/A if run['elastic'] else np.full(len(A),2*gamma0)
            cap=float(np.sum(2*(gamma0+RT*tag)*g['area0']*(ratio-1)-RT*g['surface_amount']*np.log(ratio))) if run['elastic'] else float(2*gamma0*np.sum(A-g['area0']))
            Q=z['Q'][k];vel=z['v'][k];V=z['V'][k];L=z['L'][k];center=z['C'][k]
            kinetic=.5*M*(V@V)+.5*L@(Q@np.linalg.solve(J,Q.T@L))+.5*np.sum(m[free,None]*vel[free]**2)
            work=float(np.sum(preload*(xx-x0)));E=kinetic+cap-work;row=by_time[round(float(time),12)]
            currentP=M*V+np.sum(m[free,None]*vel[free],axis=0)
            currentL=np.cross(center,M*V)+L+np.cross(xx[free],m[free,None]*vel[free]).sum(0)
            extL=np.array([row['external_Lx'],row['external_Ly'],row['external_Lz']])
            maxA=max(maxA,float(np.max(abs(A/z['area'][k]-1))));maxh=max(maxh,float(np.max(abs(h/z['h'][k]-1))))
            maxG=max(maxG,float(np.max(abs(Gamma/z['Gamma'][k]-1))));maxgamma=max(maxgamma,float(np.max(abs(sig/(2*z['gamma'][k])-1))))
            maxV=max(maxV,float(np.max(abs(z['h'][k]*A/g['volume']-1))));maxS=max(maxS,float(np.max(abs(2*z['Gamma'][k]*A/g['surface_amount']-1))))
            maxE=max(maxE,abs(E-row['supported_energy_J'])/scale)
            maxP=max(maxP,float(np.linalg.norm(currentP-expectedP)/np.linalg.norm(P0)))
            maxL=max(maxL,float(np.linalg.norm(currentL-expectedL-extL)/max(np.linalg.norm(L0),.01*np.linalg.norm(P0))))
            maxBC=max(maxBC,float(np.max(np.linalg.norm(xx[bound]-(center+(x0[bound]-bodyC)@Q.T),axis=1))))
            minquality=min(minquality,float(np.min(ratio)))
            # Finite deformation gradient relative to the material reference,
            # removing only the ACTUAL carrier rigid motion, not its strain.
            ref=x0[tri];n=np.cross(ref[:,1]-ref[:,0],ref[:,2]-ref[:,0]);area0=np.linalg.norm(n,axis=1)/2;n/=2*area0[:,None]
            grads=np.stack([np.cross(n,ref[:,2]-ref[:,1]),np.cross(n,ref[:,0]-ref[:,2]),np.cross(n,ref[:,1]-ref[:,0])],axis=1)/(2*area0[:,None,None])
            u=(xx-center)@Q+bodyC-x0;D=np.einsum('tij,tik->tjk',u[tri],grads);deform.append(float(np.max(np.linalg.norm(D,axis=(1,2)))))
        report=dict(name=name,saved_frames=len(z['time']),saved_area_error=maxA,saved_thickness_error=maxh,saved_Gamma_error=maxG,saved_tension_error=maxgamma,
                    material_volume_error=maxV,material_surface_amount_error=maxS,energy_reconstruction_received=maxE,
                    physical_linear_impulse_error=maxP,physical_angular_plus_preload_error=maxL,boundary_rigid_position_error_m=maxBC,
                    maximum_full_relative_gradient=max(deform),minimum_area_ratio=minquality,
                    maximum_preload_work_over_received=float(np.max(abs(hist['preload_work_J']))/scale),
                    energy_error_initial_capillary_scale=run['maximum_energy_error_received']*scale/(2*gamma0*g['area0'].sum()))
        report['passed']=all(report[k]<1e-12 for k in ['saved_area_error','saved_thickness_error','saved_Gamma_error','saved_tension_error','material_volume_error','material_surface_amount_error']) and maxE<1e-5 and maxP<1e-5 and maxL<1e-5 and maxBC<1e-12
        reports.append(report)
    za=np.load(OUT/'active-frames.npz');zb=np.load(OUT/'half-frames.npz');zc=np.load(OUT/'constant-frames.npz')
    comparisons=dict(thickness_increment_half_difference=float(np.linalg.norm(za['h'][-1]-zb['h'][-1])/max(np.linalg.norm(zb['h'][-1]-protocol['h0_m']),1e-30)),
       response_thickness_increment_rms_m=float(np.sqrt(np.mean((za['h'][-1]-protocol['h0_m'])**2))),
       constant_minimum_thickness_m=float(zc['h'].min()),active_minimum_thickness_m=float(za['h'].min()),
       source_hashes_match=all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==v for p,v in protocol['sources'].items()))
    result=dict(native_liquid_and_rigid_mass=geom,runs=reports,comparisons=comparisons,
       scope='independent saved geometry, thermodynamic energy and true momenta; not experimental or local-border-flow validation')
    result['passed']=geom['body_mass_error']<1e-12 and geom['body_COM_error_m']<1e-12 and geom['body_inertia_error']<1e-12 and geom['positive_inertia'] and all(r['passed'] for r in reports) and comparisons['source_hashes_match']
    (OUT/'independent-audit.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps(result,indent=2))

if __name__=='__main__':main()
