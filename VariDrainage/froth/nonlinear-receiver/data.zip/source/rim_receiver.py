"""Actual geometry, first-contact preparation and linear finite-recipient response."""
from pathlib import Path
from collections import Counter,defaultdict
import json
import numpy as np
from scipy.sparse import coo_matrix,csc_matrix
from scipy.sparse.linalg import splu
from gas_shape import ROOT,load,R
RHO=1000.;H=.8e-6;SIGMA=.06;TAG=1e-6
OUT=ROOT/'results/rim-receiver'
def crossmat(v):
    a,b,c=v;return np.array([[0,-c,b],[c,0,-a],[-b,a,0]])
def tri_area(p):return np.linalg.norm(np.cross(p[:,1]-p[:,0],p[:,2]-p[:,0]),axis=1)/2
def split(p):
    a,b,c=p;ab=(a+b)/2;bc=(b+c)/2;ca=(c+a)/2
    return [np.array(v) for v in [(a,ab,ca),(ab,b,bc),(ca,bc,c),(ab,bc,ca)]]
def prepare():
    x,t,front,back,kind,tension,paths=load(4);x=x*R
    active=(kind==1)&(((front==1)&(back==2))|((front==2)&(back==1)));at=t[active];p=x[at];areas=tri_area(p)
    center=np.sum(p.mean(1)*areas[:,None],axis=0)/areas.sum();normal=np.sum(np.cross(p[:,1]-p[:,0],p[:,2]-p[:,0]),axis=0);normal/=np.linalg.norm(normal)
    counts=Counter(tuple(sorted([int(a),int(b)])) for tri in at for a,b in zip(tri,np.roll(tri,-1)));adj=defaultdict(list)
    for (a,b),count in counts.items():
        if count==1:adj[a].append(b);adj[b].append(a)
    assert all(len(v)==2 for v in adj.values());start=min(adj);loop=[start];prev=None;cur=start
    while True:
        nxt=next(q for q in sorted(adj[cur]) if q!=prev)
        if nxt==start:break
        loop.append(nxt);prev,cur=cur,nxt
    assert len(loop)==len(adj)
    e1=x[loop[1]]-x[loop[0]];e1-=normal*(e1@normal);e1/=np.linalg.norm(e1);e2=np.cross(normal,e1)
    projected=x-((x-center)@normal)[:,None]*normal;boundary=projected[loop]
    uv=(boundary-center)@np.array([e1,e2]).T
    if np.sum(uv[:,0]*np.roll(uv[:,1],-1)-uv[:,1]*np.roll(uv[:,0],-1))<0:loop=loop[::-1];boundary=projected[loop]
    origin=.75*center+.25*(boundary[0]+boundary[1])/2
    ds=[]
    for a,b in zip(boundary,np.roll(boundary,-1,axis=0)):
        u=np.clip((origin-a)@(b-a)/np.dot(b-a,b-a),0,1);ds.append(np.linalg.norm(origin-a-u*(b-a)))
    radius=.15*min(ds);parcels=[]
    for face,area in zip(at,areas):
        children=[projected[face]]
        for _ in range(5):children=[q for child in children for q in split(child)]
        for child in children:
            c=child.mean(0)
            if np.linalg.norm(c-origin)>=radius:parcels.append([*c,RHO*H*area/len(children),2*TAG*area/len(children)])
    parcels=np.array(parcels);spacing=float(np.sqrt(np.median(parcels[:,3]/(RHO*H))));dt=.15*spacing/np.sqrt(SIGMA/(RHO*H))
    with (OUT/'rim-input.dat').open('w',encoding='ascii') as f:
        f.write(f'{len(parcels)} {len(boundary)} 24 {RHO:.17g} {H:.17g} {SIGMA:.17g} {radius:.17g} {dt:.17g} {spacing:.17g}\n')
        for a in [origin,e1,e2,*boundary]:f.write(' '.join(f'{v:.17g}' for v in a)+'\n')
        for row in parcels:f.write(' '.join(f'{v:.17g}' for v in row)+'\n')
    np.savez_compressed(OUT/'geometry.npz',points=x,tets=t,front=front,back=back,kind=kind,active=active,parcels=parcels,boundary=boundary,origin=origin,e1=e1,e2=e2)
    return dict(active_gases=[1,2],parcels=len(parcels),rim_nodes=24,dt_s=dt,hole_radius_m=radius,
       projection_error_m=float(max(abs((x[np.unique(at)]-center)@normal))),native_active_area_m2=float(areas.sum()),
       initial_remaining_volume_m3=float(parcels[:,3].sum()/RHO),geometry_sources=[str(p.relative_to(ROOT)) for p in paths])

def liquid_moments(x,t,front,back):
    volume=0.;first=np.zeros(3);second=np.zeros((3,3))
    for tri,f,b in zip(t,front,back):
        s=1 if f==5 else -1 if b==5 else 0
        if not s:continue
        p=x[tri];v=s*np.linalg.det(p)/6;z=p.sum(0);volume+=v;first+=v*z/4;second+=v*(p.T@p+np.outer(z,z))/20
    center=first/volume;cov=second-volume*np.outer(center,center);J=RHO*(np.trace(cov)*np.eye(3)-cov)
    return volume,center,J

def assemble():
    data=np.load(OUT/'geometry.npz');x=data['points'];t=data['tets'];front=data['front'];back=data['back'];kind=data['kind'];active=data['active']
    volume,center,J=liquid_moments(x,t,front,back);mr=[];mc=[];mv=[];kr=[];kc=[];kv=[];nodes=[];interiors=[];offset=6;groups=[]
    Mbody=np.zeros((6,6));Mbody[:3,:3]=RHO*volume*np.eye(3);Mbody[3:,3:]=J/R**2;display_tri=[]
    def B(p):return np.concatenate([np.eye(3),-crossmat(p-center)/R],axis=1)
    for pair in sorted({tuple(sorted([int(a),int(b)])) for a,b,k,ac in zip(front,back,kind,active) if k==1 and not ac}):
        mask=(kind==1)&(~active)&np.array([tuple(sorted([int(a),int(b)]))==pair for a,b in zip(front,back)]);tt=t[mask];ids=sorted(np.unique(tt));local={v:i for i,v in enumerate(ids)}
        counts=Counter(tuple(sorted([int(a),int(b)])) for tri in tt for a,b in zip(tri,np.roll(tri,-1)));boundary={v for edge,c in counts.items() if c==1 for v in edge};dof={};masses={v:0. for v in ids}
        for tri in tt:
            area=tri_area(x[tri][None])[0]
            for v in tri:masses[v]+=RHO*H*area/3
        group=[];node_lookup={}
        for v in ids:
            if v not in boundary:dof[v]=np.arange(offset,offset+3);offset+=3
            else:dof[v]=np.array([],dtype=int)
            bmat=B(x[v]);cols=np.r_[np.arange(6),dof[v]];G=np.concatenate([bmat,np.eye(3)],axis=1) if len(dof[v]) else bmat
            mm=masses[v]*(G.T@G)
            for a,i in enumerate(cols):
                for b,j in enumerate(cols):mr.append(int(i));mc.append(int(j));mv.append(float(mm[a,b]))
            node_lookup[v]=len(nodes);nodes.append(dict(position=x[v].tolist(),mass=masses[v],B=bmat,dof=dof[v],pair=list(pair)));group.append(len(nodes)-1)
        groups.append(group)
        for tri in tt:
            display_tri.append([node_lookup[v] for v in tri])
            p=x[tri];cross=np.cross(p[1]-p[0],p[2]-p[0]);area=np.linalg.norm(cross)/2;n=cross/(2*area);grads=np.array([np.cross(n,p[2]-p[1]),np.cross(n,p[0]-p[2]),np.cross(n,p[1]-p[0])])/(2*area)
            ke=SIGMA*area*(grads@grads.T)
            for a,i in enumerate(tri):
                if not len(dof[i]):continue
                for b,j in enumerate(tri):
                    if not len(dof[j]):continue
                    block=ke[a,b]*np.outer(n,n)
                    for u,I in enumerate(dof[i]):
                        for v,Jj in enumerate(dof[j]):kr.append(int(I));kc.append(int(Jj));kv.append(float(block[u,v]))
    for i in range(6):
        for j in range(6):mr.append(i);mc.append(j);mv.append(float(Mbody[i,j]))
    M=coo_matrix((mv,(mr,mc)),shape=(offset,offset)).tocsc();K=coo_matrix((kv,(kr,kc)),shape=(offset,offset)).tocsc()
    return M,K,nodes,groups,dict(liquid_volume_m3=volume,liquid_centroid_m=center.tolist(),liquid_inertia_kg_m2=J.tolist(),inertia_eigenvalues=np.linalg.eigvalsh(J).tolist(),film_count=len(groups),dof_count=offset,film_node_count=len(nodes),film_triangles=display_tri),B

def response(tag,erased=False):
    M,K,nodes,groups,meta,B=assemble();c=np.loadtxt(OUT/f'{tag}-contact.csv',delimiter=',',skiprows=1,ndmin=2);mass_added=c[:,7].sum();tracer=c[:,8].sum();J=np.zeros(M.shape[0]);add=np.zeros((6,6));Ein=0.
    for r in c:
        b=B(r[1:4]);m=r[7];v=r[4:7];add+=m*b.T@b;J[:6]+=b.T@(m*v);Ein+=.5*m*(v@v)
    M=M+coo_matrix((add.ravel(),(np.repeat(np.arange(6),6),np.tile(np.arange(6),6))),shape=M.shape).tocsc()
    originalJ=J.copy()
    if erased:J[:]=0
    velocity=splu(M).solve(J);q=np.zeros(len(J));Eafter=float(.5*velocity@(M@velocity));loss=Ein-Eafter
    dt=1e-5;A=M+dt**2/4*K;factor=splu(A.tocsc());C=M-dt**2/4*K;E0=Eafter;hist=[];frames=[];max_energy=max_P=max_L=0.;maxdisp=maxgrad=0.
    tt=np.array(meta['film_triangles']);p=np.array([node['position'] for node in nodes])[tt];cross=np.cross(p[:,1]-p[:,0],p[:,2]-p[:,0]);areas=np.linalg.norm(cross,axis=1)/2;normal=cross/(2*areas[:,None]);grads=np.array([np.cross(normal,p[:,2]-p[:,1]),np.cross(normal,p[:,0]-p[:,2]),np.cross(normal,p[:,1]-p[:,0])]).transpose(1,0,2)/(2*areas[:,None,None])
    for step in range(201):
        if step:
            vn=factor.solve(C@velocity-dt*K@q);q+=dt/2*(velocity+vn);velocity=vn
        momentum=M@velocity;energy=float(.5*velocity@(M@velocity)+.5*q@(K@q));errE=abs(energy-E0)/max(E0,1e-300);errP=np.linalg.norm(momentum[:3]-J[:3])/max(np.linalg.norm(originalJ[:3]),1e-300);errL=np.linalg.norm(momentum[3:6]-J[3:6])/max(np.linalg.norm(originalJ[3:6]),1e-300)
        max_energy=max(max_energy,errE);max_P=max(max_P,float(errP));max_L=max(max_L,float(errL));rel=[]
        wall=[]
        for i,node in enumerate(nodes):
            w=q[node['dof']] if len(node['dof']) else np.zeros(3);u=node['B']@q[:6]+w;rel.append(float(w@w));maxdisp=max(maxdisp,float(np.linalg.norm(w)))
            wall.append(w)
            if step%4==0:frames.append([step,step*dt,i,*(np.array(node['position'])+u),*w])
        gradval=float(max(np.linalg.norm(np.einsum('tij,tik->tjk',np.array(wall)[tt],grads),axis=(1,2))));maxgrad=max(maxgrad,gradval)
        hist.append([step,step*dt,energy,errE,errP,errL,float(np.sqrt(np.mean(rel))),float(np.linalg.norm(q[3:6])/R),gradval,loss])
    return np.array(hist),np.array(frames),dict(**meta,incoming_mass_kg=float(mass_added),incoming_tag_mol=float(tracer),receiving_energy_J=Eafter,incoming_energy_J=Ein,inelastic_loss_J=loss,relative_added_liquid_volume=float(mass_added/(RHO*meta['liquid_volume_m3'])),maximum_energy_error=max_energy,maximum_linear_impulse_error=max_P,maximum_reference_angular_impulse_error=max_L,maximum_relative_displacement_m=maxdisp,maximum_relative_gradient=maxgrad,maximum_rotation_rad=float(max(r[7] for r in hist)),external_sink_impulse=((-originalJ[:3]) if erased else np.zeros(3)).tolist())
