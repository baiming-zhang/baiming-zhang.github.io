"""Bounded explicit gas / native wet-shape feedback matrix; all warnings retained."""
from pathlib import Path
import csv,hashlib,json,platform,time,zipfile
import numpy as np
from gas_shape import ROOT,R,PSCALE,ESCALE,RT,P0,EXE,load,geometry,grand,force_ratio,relax,exchange
OUT=ROOT/'results/gas-shape';LOG=ROOT/'results/logs/gas-shape';WORK=LOG/'work'
def save(p,x):p.write_text(json.dumps(x,indent=2),encoding='utf8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def csvout(path,header,rows):
    with path.open('w',newline='',encoding='utf8') as f:w=csv.writer(f);w.writerow(header);w.writerows(rows)
def state_meta(x,t,f,b,tension,n,N,vref,liquid,native):
    V,A,gs,gv=geometry(x,t,f,b,tension,n);surface=float(A@tension);E=surface+grand(N,V[1:n+1])
    native_rebuild=surface+sum((P0/PSCALE)*(V[i+1]-vref[i])-N[i]*np.log(V[i+1]/vref[i]) for i in range(n))
    return V,A,dict(grand_energy_nd=E,surface_energy_nd=surface,gas_grand_nd=grand(N,V[1:n+1]),
         force_ratio=force_ratio(N,V,gs,gv,n),liquid_error=float(abs(V[n+1]/liquid-1)),
         native_volume_error=max(abs(V[i]/native['volumes'][i]-1) for i in range(1,n+2)) if native else 0.,
         native_energy_error=abs(native_rebuild-native['energy'])/max(abs(native_rebuild),1.) if native else 0.)
def main():
    OUT.mkdir(exist_ok=True);WORK.mkdir(parents=True,exist_ok=True);(LOG/'.gitignore').write_text('/work/\n',encoding='utf8')
    sources=[Path(__file__),ROOT/'foam/scripts/gas_shape.py',ROOT/'foam/docs/gas_shape_protocol.md'];sources+=load(4)[-1]+load(7)[-1]
    save(OUT/'protocol.json',dict(date_utc='2026-11-13',python=platform.python_version(),numpy=np.__version__,training=False,
        source_sha256={str(p.relative_to(ROOT)):sha(p) for p in sources},evolver_sha256=sha(EXE),
        R_m=R,gamma_N_m=.03,p0_Pa=P0,T_K=298.15,Dgas_m2_s=2e-9,H_mol_m3_Pa=6.4e-6,h_m=.8e-6,
        scope='film-only gas exchange + finite liquid-volume surface/ideal-gas relaxation; not full drainage/event loop'))
    prepared={};preps=[];start=time.perf_counter()
    for n in [4,7]:
        x,t,f,b,k,ten,_=load(n);V,A,_,_=geometry(x,t,f,b,ten,n);vref=V[1:n+1].copy();liquid=V[n+1];N=(P0/PSCALE)*vref
        x,native=relax(WORK/f'prepare{n}',x,t,f,b,k,ten,n,N,vref,liquid,initial=True)
        V,A,meta=state_meta(x,t,f,b,ten,n,N,vref,liquid,native);prepared[n]=(x,t,f,b,k,ten,N,vref,liquid)
        preps.append(dict(cells=n,**meta,**native))
        csvout(OUT/f'cluster{n}-triangles.csv',['id','v1','v2','v3','front_body','back_body','ftype','tension'],[[i,*tri,ff,bb,kk,tt] for i,(tri,ff,bb,kk,tt) in enumerate(zip(t,f,b,k,ten))])
    cases=[('seven-open',7,100,False,False,False),('seven-half',7,50,False,False,False),
       ('seven-closed',7,100,True,False,False),('seven-frozen-shape',7,100,False,True,False),
       ('seven-no-exchange',7,200,False,False,True),('four-open',4,100,False,False,False)]
    result=[];finals={}
    for name,n,dt,closed,frozen,zero in cases:
        x,t,f,b,k,ten,N,vref,liquid=prepared[n];x=x.copy();N=N.copy();Ninitial=N.copy();received=0.;native=None
        history=[];poses=[];bodies=[];warnings=[]
        V,A,meta=state_meta(x,t,f,b,ten,n,N,vref,liquid,None);Eref=meta['grand_energy_nd'];Gref=meta['gas_grand_nd']
        for step in range(int(1000/dt)+1):
            if step:
                V,A,_,_=geometry(x,t,f,b,ten,n);N,arrived,ex=exchange(N,V[1:n+1],A,f,b,k,n,dt,closed,zero);received+=arrived
                Ebefore=float(A@ten)+grand(N,V[1:n+1])
                if not frozen:
                    x,native=relax(WORK/f'{name}-{step:03d}',x,t,f,b,k,ten,n,N,vref,liquid)
                    warnings.extend(dict(step=step,text=q) for q in native['warnings'])
                else:native=None
                V,A,meta=state_meta(x,t,f,b,ten,n,N,vref,liquid,native);mechanical_drop=Ebefore-meta['grand_energy_nd']
            else:ex=dict(graph_residual=0.,grand_energy_residual=0.,dissipation=0.,backward_euler=0.);mechanical_drop=0.
            balance=abs((N.sum()+received)/Ninitial.sum()-1)
            row=dict(step=step,time_s=step*dt,gas_amount_mol=float(N.sum()*ESCALE/RT),ambient_received_mol=float(received*ESCALE/RT),
               amount_error=float(balance),**meta,**ex,mechanical_drop_nd=mechanical_drop,
               diffusion_energy_error=abs(ex['grand_energy_residual'])/max(Gref,1e-300),minimum_gas_amount_mol=float(N.min()*ESCALE/RT))
            history.append(row);poses.extend([step,i,*(p*R)] for i,p in enumerate(x))
            bodies.extend([step,step*dt,i+1,nn*ESCALE/RT,V[i+1]*R**3,PSCALE*nn/V[i+1]] for i,nn in enumerate(N))
            save(OUT/'progress.json',dict(case=name,step=step,time_s=step*dt,elapsed_seconds=time.perf_counter()-start))
        csvout(OUT/f'{name}-history.csv',list(history[0]),[list(q.values()) for q in history]);csvout(OUT/f'{name}-nodes.csv',['step','node','x_m','y_m','z_m'],poses)
        csvout(OUT/f'{name}-bodies.csv',['step','time_s','body','n_mol','volume_m3','pressure_Pa'],bodies)
        save(OUT/f'{name}-warnings.json',warnings)
        checks=dict(positive=all(q['minimum_gas_amount_mol']>0 for q in history),gas_ledger=max(q['amount_error'] for q in history)<1e-12,
           liquid_volume=max(q['liquid_error'] for q in history)<1e-6,native_volumes=max(q['native_volume_error'] for q in history)<1e-8,
           native_energy=max(q['native_energy_error'] for q in history)<1e-8,graph=max(q['graph_residual'] for q in history)<1e-10,
           diffusion_energy=max(q['diffusion_energy_error'] for q in history)<1e-8,
           shape_descent=min(q['mechanical_drop_nd'] for q in history)>=-1e-8*Eref)
        projection_warnings=[q for q in warnings if 'WARNING 1055' in q['text']]
        result.append(dict(name=name,cells=n,dt_s=dt,steps=len(history)-1,closed=closed,frozen=frozen,zero_exchange=zero,
            discrete_checks=checks,force_target_1e4=max(q['force_ratio'] for q in history)<1e-4,
            maximum_force_ratio=max(q['force_ratio'] for q in history),native_projection_clean=not projection_warnings,
            warning_count=len(warnings),final=history[-1],maximum_amount_error=max(q['amount_error'] for q in history),
            total_gas_change_relative=float(N.sum()/Ninitial.sum()-1)))
        finals[name]=(N.copy(),V.copy(),Ninitial)
        print(name,checks,'force',result[-1]['maximum_force_ratio'],flush=True)
    a,Va,N0=finals['seven-open'];h,Vh,_=finals['seven-half'];frozen,Vf,_=finals['seven-frozen-shape']
    comparisons=dict(half_time_transfer_difference=float(np.linalg.norm(a-h)/np.linalg.norm(h-N0)),
        half_time_volume_difference=float(np.linalg.norm(Va[1:8]-Vh[1:8])/np.linalg.norm(Vh[1:8])),
        frozen_transfer_difference=float(np.linalg.norm(a-frozen)/np.linalg.norm(a-N0)))
    comparisons['transfer_time_1pct_pass']=comparisons['half_time_transfer_difference']<.01
    save(OUT/'summary.json',dict(preparations=preps,runs=result,comparisons=comparisons,elapsed_seconds=time.perf_counter()-start))
    for tag in ['prepare4','prepare7']+[q[0] for q in cases]:
        with zipfile.ZipFile(LOG/f'{tag}.zip','w',zipfile.ZIP_DEFLATED) as z:
            for p in WORK.glob(tag+'*'):z.write(p,p.name)
    print(json.dumps(comparisons,indent=2),flush=True)
if __name__=='__main__':main()
