target_tolerance := 1e-12
U
g 80
hessian_seek
hessian_seek
hessian_seek
printf "ENERGY %.17g\n",total_energy
foreach body bb do printf "BODY %d %.17g\n",bb.id,bb.volume
foreach vertex vv do printf "VERTEX %d %.17g %.17g %.17g\n",vv.id,vv.x,vv.y,vv.z
q
q
