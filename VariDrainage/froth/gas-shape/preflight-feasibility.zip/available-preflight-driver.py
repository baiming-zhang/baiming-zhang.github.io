from pathlib import Path
import csv,json,subprocess,re
import numpy as np
BASE=Path('.').resolve();src=BASE/'project/results/free-wet-conditioned';out=BASE/'规划核对/gas-energy-preflight';out.mkdir(exist_ok=True);exe=BASE.parent/'.tools/evolver270/evolver64.exe'
for n,label in [(4,'initial'),(7,'final')]:
 name=f'wet{n}-s020';vs=list(csv.DictReader((src/f'{name}-{label}-vertices.csv').open()));fs=list(csv.DictReader((src/f'{name}-{label}-triangles.csv').open()));summary=json.loads((src/'summary.json').read_text());snap=next(s for r in summary['runs'] if r['name']==name for s in r['snapshots'] if s['label']==label);V={int(k):v/1e-6 for k,v in snap['body_volumes_m3'].items()};lines=['// Native ideal-gas Helmholtz geometry feasibility, not dynamics.','parameter ambient = 16666.666666666668','define facet attribute ftype integer']
 for i in range(1,n+1):
  lines += [f'parameter vref{i} = {V[i]:.17g}',f'parameter amount{i} = {16666.666666666668*V[i]:.17g}',f'method_instance gv{i} method facet_vector_integral','vector_integrand:','q1: x/3','q2: y/3','q3: z/3',f'quantity ge{i} energy function ambient*(gv{i}.value-vref{i}) - amount{i}*log(gv{i}.value/vref{i})']
 lines+=['vertices'];lines += [r['id']+' '+' '.join(r[k] for k in ['x_over_R','y_over_R','z_over_R']) for r in vs];lines+=['edges'];edges={}
 for r in fs:
  ids=[int(r[k]) for k in ['v1','v2','v3']]
  for a,b in zip(ids,ids[1:]+ids[:1]):
   key=tuple(sorted([a,b]));
   if key not in edges:edges[key]=len(edges)+1;lines.append(f'{len(edges)} {key[0]} {key[1]}')
 lines+=['faces'];bodies={i:[] for i in range(1,n+2)}
 for r in fs:
  fid=int(r['id']);ids=[int(r[k]) for k in ['v1','v2','v3']];es=[edges[tuple(sorted([a,b]))]*(1 if a<b else -1) for a,b in zip(ids,ids[1:]+ids[:1])];front=int(r['front_body']);back=int(r['back_body']);inst=[]
  if front:
   bodies[front].append(fid)
   if front<=n:inst.append(f'gv{front}')
  if back:
   bodies[back].append(-fid)
   if back<=n:inst.append(f'gv{back}-')
  lines.append(f'{fid} '+' '.join(map(str,es))+f' tension {r["tension_over_2gamma"]} ftype {r["ftype"]} '+' '.join(inst))
 lines+=['bodies'];lines += [str(i)+' '+' '.join(map(str,ids))+(f' volume {V[i]:.17g}' if i==n+1 else '') for i,ids in bodies.items()];lines+=['read','function_quantity_sparse on'];(out/f'gas{n}.fe').write_text('\n'.join(lines)+'\n',encoding='utf8')
 cmd='target_tolerance := 1e-12\nprintf "START %.17g\\n",total_energy\nU\ng 80\nhessian_seek\nhessian_seek\nhessian_seek\nprintf "END %.17g\\n",total_energy\nforeach body bb do printf "BODY %d %.17g\\n",bb.id,bb.volume\nforeach vertex vv do printf "VERTEX %d %.17g %.17g %.17g\\n",vv.id,vv.x,vv.y,vv.z\nq\nq\n'
 p=subprocess.run([str(exe),f'gas{n}.fe'],cwd=out,input=cmd.encode('ascii'),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90);txt=p.stdout.decode('cp1252',errors='replace');(out/f'gas{n}.txt').write_text(txt,encoding='utf8');print(n,p.returncode,'\n'.join(l for l in txt.splitlines() if re.search('WARNING|ERROR|START |END |BODY ',l))[-2000:])
