"""Saved state/native amount audit; independently reconstruct physical gas fluxes."""
from pathlib import Path
import hashlib,json,re,zipfile
import numpy as np
from gas_shape import ROOT,R,RT,ESCALE,P0,DGAS,H,THICK
OUT=ROOT/'results/gas-shape';LOG=ROOT/'results/logs/gas-shape'
def read(name):return np.loadtxt(OUT/name,delimiter=',',skiprows=1,ndmin=2)
def qgas(n,V):
    u=(n*RT-P0*V)/(P0*V);return float(np.sum(P0*V*((1+u)*np.log1p(u)-u)))
def area(x,t):p=x[t];return np.linalg.norm(np.cross(p[:,1]-p[:,0],p[:,2]-p[:,0]),axis=1)/2
def main():
    summary=json.loads((OUT/'summary.json').read_text());audits=[]
    for run in summary['runs']:
        name=run['name'];n=run['cells'];top=read(f'cluster{n}-triangles.csv');t=top[:,1:4].astype(int);front=top[:,4].astype(int);back=top[:,5].astype(int);kind=top[:,6].astype(int);tension=top[:,7]
        raw=read(name+'-nodes.csv');nn=int(raw[:,1].max())+1;x=raw[:,2:5].reshape(run['steps']+1,nn,3)
        body=read(name+'-bodies.csv').reshape(run['steps']+1,n,6);N=body[:,:,3];V=body[:,:,4];P=body[:,:,5];dt=run['dt_s']
        flux_errors=[];absolute_flux_errors=[];post_errors=[];energy_errors=[];native_amount_errors=[];surface_energy_errors=[];volume_errors=[]
        total0=N[0].sum();initial_gas_energy=qgas(N[0],V[0])
        with zipfile.ZipFile(LOG/(name+'.zip')) as z:
            for k in range(len(x)):
                pp=x[k,t];v=np.linalg.det(pp)/6;rebuilt=np.zeros(n+2);np.add.at(rebuilt,front,v);np.add.at(rebuilt,back,-v)
                volume_errors.append(float(max(abs(rebuilt[1:n+1]/V[k]-1))))
                E=float(area(x[k],t)@tension)*.06+qgas(N[k],V[k])
                hist=read(name+'-history.csv');surface_energy_errors.append(abs(E/ESCALE-hist[k,5])/max(abs(E/ESCALE),1.))
                if not k:continue
                if not run['frozen']:
                    fe=z.read(f'{name}-{k:03d}.fe').decode('utf8')
                    amounts=np.array([float(re.findall(rf'parameter amount{i} = (\S+)',fe)[0]) for i in range(1,n+1)])*ESCALE/RT
                    native_amount_errors.append(float(max(abs(amounts/N[k]-1))))
                aa=area(x[k-1],t);pf=N[k]*RT/V[k-1];pred=np.zeros(n);post=np.zeros(n);diss=0.
                for a,b,A,ftype in zip(front,back,aa,kind):
                    if ftype!=1 or run['zero_exchange'] or (run['closed'] and (a==0 or b==0)):continue
                    kap=DGAS*H*A/THICK;pa=pf[a-1] if a else P0;pb=pf[b-1] if b else P0
                    qa=dt*kap*(pb-pa);pna=P[k,a-1] if a else P0;pnb=P[k,b-1] if b else P0;qb=dt*kap*(pnb-pna)
                    if a:pred[a-1]+=qa;post[a-1]+=qb
                    if b:pred[b-1]-=qa;post[b-1]-=qb
                    diss+=dt*kap*(pa-pb)*RT*np.log(pa/pb)
                delta=N[k]-N[k-1];scale=max(np.linalg.norm(delta),total0*1e-15)
                flux_errors.append(float(np.linalg.norm(delta-pred)/scale));post_errors.append(float(np.linalg.norm(delta-post)/scale))
                absolute_flux_errors.append(float(np.linalg.norm(delta-pred)/total0))
                u=(N[k]-N[k-1])/N[k-1];be=float(np.sum(N[k-1]*RT*(u-np.log1p(u))))
                err=qgas(N[k],V[k-1])-qgas(N[k-1],V[k-1])+diss+be
                energy_errors.append(abs(err)/max(initial_gas_energy,1e-300))
        prep=next(p for p in summary['preparations'] if p['cells']==n);warnings=prep['warnings']+[q['text'] for q in json.loads((OUT/(name+'-warnings.json')).read_text())]
        result=dict(name=name,pressure_ideal_gas_error=float(max(abs((N*RT/V)/P-1).ravel())),
           saved_native_amount_error=max(native_amount_errors,default=0.),oriented_gas_volume_error=max(volume_errors),
           maximum_frozen_geometry_flux_error=max(flux_errors),maximum_postshape_flux_defect=max(post_errors),
           maximum_flux_error_to_initial_amount=max(absolute_flux_errors),maximum_full_grand_rebuild_error=max(surface_energy_errors),
           maximum_gas_energy_error=max(energy_errors),native_projection_clean_including_preparation=not any('WARNING 1055' in w for w in warnings),
           warning_count_including_preparation=len(warnings),omitting_ambient_ledger_error=float(abs(N[-1].sum()/total0-1)))
        result['flux_normalization']='initial total amount for exact zero-exchange control; transferred amount otherwise'
        flux_pass=max(absolute_flux_errors)<1e-12 if run['zero_exchange'] else max(flux_errors)<1e-8
        result['saved_algebra_audit_pass']=bool(result['pressure_ideal_gas_error']<1e-12 and result['saved_native_amount_error']<1e-12 and result['oriented_gas_volume_error']<1e-8 and flux_pass and result['maximum_gas_energy_error']<1e-8 and max(surface_energy_errors)<1e-8)
        audits.append(result)
    protocol=json.loads((OUT/'protocol.json').read_text());provenance=[]
    with zipfile.ZipFile(LOG/'runtime-source.zip') as z:
        for name,expected in protocol['source_sha256'].items():
            data=z.read(name.replace('\\','/')) if name in ['foam\\scripts\\run_gas_shape.py','foam\\scripts\\gas_shape.py','foam\\docs\\gas_shape_protocol.md'] else (ROOT/name).read_bytes()
            provenance.append(dict(source=name,matched=hashlib.sha256(data).hexdigest()==expected))
        original=z.read('foam/scripts/run_gas_shape.py');patched=original.replace(b'json.dumps(x,indent=2)',b'json.dumps(x,indent=2,default=lambda v:v.item())')
        serializer_only_change=patched==(ROOT/'foam/scripts/run_gas_shape.py').read_bytes()
    output=dict(audits=audits,provenance=provenance,serializer_only_runtime_change=serializer_only_change,
         all_saved_algebra_pass=all(q['saved_algebra_audit_pass'] for q in audits),scope='independent saved physical film flux and gas-energy ledger, not converged quasistatic/coarsening or experimental validation')
    (OUT/'independent-audit.json').write_text(json.dumps(output,indent=2),encoding='utf8');print(json.dumps(output,indent=2))
if __name__=='__main__':main()
