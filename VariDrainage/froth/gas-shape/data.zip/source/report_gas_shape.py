"""Actual geometry and gas-transfer evidence, including failed kinetics gates."""
from pathlib import Path
import hashlib,json,shutil,zipfile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from matplotlib.colors import Normalize,LinearSegmentedColormap
from gas_shape import ROOT
OUT=ROOT/'results/gas-shape';LOG=ROOT/'results/logs/gas-shape';BLUE='#3b6da8';RED='#c44e52'
def read(name):return np.loadtxt(OUT/name,delimiter=',',skiprows=1,ndmin=2)
def body(name,n):return read(name+'-bodies.csv').reshape(-1,n,6)
def main():
    s=json.loads((OUT/'summary.json').read_text());audit=json.loads((OUT/'independent-audit.json').read_text())
    top=read('cluster7-triangles.csv');tri=top[:,1:4].astype(int);front=top[:,4].astype(int);back=top[:,5].astype(int);kind=top[:,6].astype(int)
    raw=read('seven-open-nodes.csv');nn=int(raw[:,1].max())+1;x=raw[:,2:5].reshape(11,nn,3)*1000;b=body('seven-open',7)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
    fig=plt.figure(figsize=(13,8.5),facecolor='white');gs=fig.add_gridspec(2,3,hspace=.38,wspace=.33,height_ratios=[1.25,1]);norm=Normalize(0,30);cmap=LinearSegmentedColormap.from_list('gas_pressure',[BLUE,RED])
    center=(x.max(axis=(0,1))+x.min(axis=(0,1)))/2;h=np.ptp(x.reshape(-1,3),axis=0).max()*.54
    for j,k in enumerate([0,10]):
        ax=fig.add_subplot(gs[0,j],projection='3d');pressure=np.r_[0,b[k,:,5]-100000,0];color=cmap(norm(np.maximum(pressure[front],pressure[back])))
        col=color.copy();col[:,3]=.30;col[kind!=1]=[.5,.5,.5,.23];ax.add_collection3d(Poly3DCollection(x[k,tri],facecolors=col,edgecolors='none'))
        ax.set(xlim=(center[0]-h,center[0]+h),ylim=(center[1]-h,center[1]+h),zlim=(center[2]-h,center[2]+h));ax.set_box_aspect((1,1,1));ax.set_axis_off();ax.view_init(22,32);ax.set_title(f'Actual wet mesh · {k*100} s')
    cb=fig.colorbar(plt.cm.ScalarMappable(norm=norm,cmap=cmap),cax=fig.add_axes([.10,.555,.46,.012]),orientation='horizontal');cb.set_label('Max adjacent gas excess / Pa',fontsize=9);cb.solids.set_rasterized(False)
    ax=fig.add_subplot(gs[0,2]);closed=body('seven-closed',7);time=closed[:,0,1]
    ax.plot(time,(closed[:,0,3]/closed[0,0,3]-1)*100,color=RED,label='central bubble')
    ax.plot(time,(closed[:,1:,3].sum(1)/closed[0,1:,3].sum()-1)*100,color=BLUE,label='outer bubbles total')
    ax.set(xlabel='Gas exchange time / s',ylabel='Gas amount change / %',title='Closed exterior: redistribution');ax.legend(fontsize=8)
    ax=fig.add_subplot(gs[1,0])
    for name,col,ls in [('seven-open',BLUE,'-'),('seven-half',BLUE,':'),('seven-frozen-shape',RED,'-')]:
        bb=body(name,7);N=bb[:,:,3].sum(1);ax.plot(bb[:,0,1],(N/N[0]-1)*100,ls,color=col,label=name.replace('seven-',''))
    ax.set(xlabel='Gas exchange time / s',ylabel='Total bubble gas change / %');ax.legend(fontsize=8)
    ax=fig.add_subplot(gs[1,1]);vals=[s['comparisons']['half_time_transfer_difference']*100,s['comparisons']['frozen_transfer_difference']*100]
    ax.bar(['half-step\ntransfer difference','frozen-shape\nresponse difference'],vals,color=[BLUE,RED]);ax.set(ylabel='Difference / %',title='Feedback exists; kinetics unresolved')
    for j,q in enumerate(vals):ax.text(j,q+1,f'{q:.1f}%',ha='center')
    ax=fig.add_subplot(gs[1,2]);ax.axis('off');ax.text(0,1,'A split-loop diagnostic',weight='bold',va='top',fontsize=12)
    ax.text(0,.82,'6 cases / 65 gas steps\nGas + ambient error ≤ 1.34e-15\nSaved physical-flux audits pass',color=BLUE,va='top',linespacing=1.6)
    ax.text(0,.46,'Post-shape flux defect: 98% / 49%\nAll force targets (1e-4) fail\nHessian indices remain negative\nFour-body projection warning retained',color=RED,va='top',linespacing=1.6)
    fig.suptitle('Gas amounts, pressure and geometry now feed back',fontsize=18,x=.06,ha='left',y=.98)
    fig.text(.06,.02,'No deformation magnification. Film-only transfer, fixed h and total border liquid. Not converged coarsening or a complete drainage/event loop.',fontsize=9,color='#555')
    fig.savefig(OUT/'gas-shape.png',dpi=180,bbox_inches='tight',facecolor='white');fig.savefig(OUT/'gas-shape.pdf',bbox_inches='tight',facecolor='white');plt.close(fig)
    table=''
    for r in s['runs']:
        a=next(q for q in audit['audits'] if q['name']==r['name']);table+=f'<tr><td>{r["name"]}</td><td>{r["steps"]}</td><td>{r["maximum_amount_error"]:.3g}</td><td>{r["maximum_force_ratio"]:.3g}</td><td>{a["maximum_postshape_flux_defect"]:.3g}</td></tr>'
    for p in LOG.glob('*.zip'):shutil.copy2(p,OUT/p.name)
    support=['prepare4','prepare7','four-open','seven-no-exchange','runtime-source','preflight-feasibility']
    with zipfile.ZipFile(OUT/'native-support.zip','w',zipfile.ZIP_DEFLATED) as z:
        for name in support:z.write(LOG/(name+'.zip'),name+'.zip')
        z.write(LOG/'summary-failure.txt','summary-failure.txt')
    links=' · '.join(f'<a href="{name}.zip">{name}</a>' for name in ['seven-open','seven-half','seven-closed','native-support'])
    html='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>FROTH · 气体量与形变反馈</title><style>:root{color-scheme:light}*{box-sizing:border-box}body{background:#fff;color:#23303e;font:16px/1.75 system-ui,sans-serif;margin:0}main{max-width:1140px;margin:auto;padding:34px 22px}h1{font-size:clamp(28px,4vw,46px);line-height:1.25}h2{margin-top:38px}a{color:#3b6da8}img{display:block;width:100%;height:auto}.tag{color:#c44e52;font-weight:700}.note{padding:18px;background:#faf5f5;border-left:4px solid #c44e52}.table{overflow:auto}table{border-collapse:collapse;width:100%;font-size:14px}td,th{padding:10px;border-bottom:1px solid #ddd;text-align:left;white-space:nowrap}.viewer{max-width:700px;margin:auto}canvas{display:block;aspect-ratio:1;width:100%;background:#fff;border:1px solid #e1e6eb;touch-action:none}input{width:100%;accent-color:#3b6da8}.muted{font-size:14px;color:#566574}</style><main><a href="../index.html">← FROTH</a><p class="tag">GAS / PRESSURE / SHAPE · SPLIT-LOOP REFERENCE</p><h1>收支闭合，还不等于粗化预测</h1><p>四泡、七泡现在具有明确气体量：气体交换改变泡内压力，压力驱动自由湿几何松弛，更新后的体积与实际膜面积再影响下一次交换。原生求解器与气体账目已经连成反馈，但本轮暴露了显著的分步误差。</p>
    <div class="note">六组、65 步：气体加外界库存误差 ≤1.34e−15，保存数据的物理传气通量与能量审计通过。时间步减半，传气量仍差 24.97%；更新形变后代回同一步通量的缺陷约 98%／49%。所有算例均未达到1e−4机械力目标，Hessian 警告保留，四泡还存在体积投影警告。因此尚不能报告收敛的定量粗化结果。</div>
    <img src="gas-shape.png" width="2340" height="1530" alt="实际七泡湿网格、气体再分配和未收敛误差"><p><a href="gas-shape.png">PNG</a> · <a href="gas-shape.pdf">矢量 PDF</a></p>
    <h2>实际保存的几何与气体状态</h2><p class="muted">拖动旋转；滑块只切换 11 个实际保存状态，没有时间插值，也没有放大形变。膜颜色表示两侧气体中较大的超压（0–30Pa），灰色为液体边界表面；这不是干涉光学渲染。原生优化迭代没有被当成物理形变时间。</p><div class="viewer"><canvas aria-label="实际七泡气体形变状态"></canvas><input id="frame" aria-label="保存状态" type="range" min="0" max="10" step="1" value="0"><p id="label"></p></div>
    <h2>有界对照</h2><div class="table"><table><thead><tr><th>算例</th><th>步数</th><th>最大气体账目误差</th><th>最大力比值</th><th>形变后通量缺陷</th></tr></thead><tbody>TABLE</tbody></table></div>
    <p>关闭外界交换时，中心小泡气体减少约 0.0820%，外侧六泡合计增加约 0.002276%；全部气体总量守恒。开放外界时，泡内总气体减少约 0.07569%，去向已计入外界库存。冻结形状的传气响应与反馈算例相差约 80.07%。这些是当前离散模型的结果，尚非物理预测。</p>
    <h2>到底检查了什么</h2><p>明确气体量 n，使用 p=nRT/V；只固定连通液体的总体积，气泡体积可以变化。原生能量包含实际界面张力面积、环境压力做功和理想气体 Helmholtz 项。Python 独立重建完整气体巨势，避免跨气体量变化直接比较带不同常数的原生能量。</p><p>从保存状态重新计算每张膜的面积、气体量、交换前体积和压力，审计通量与逆向后向欧拉 Bregman 项。另核对原生输入里的气体量、定向三角形体积和保存的理想气体压力。审计的零交换控制按初始总量归一化，避免用零通量附近的舍入误差作分母；非零交换仍按实际传递量审计。</p>
    <h2>回到原始多泡生命周期目标</h2><p>本轮先在旧体积上求气体交换，再松弛形状；守恒与分步能量可以同时成立，但新体积对应的同一步压力通量仍不满足联合动力学。半时间步还多做了一倍机械松弛，而机械力尚未收敛，因此24.97%差异不能单独归因于时间离散。这项共同残差仍是最终粗化结论必须通过的门槛。下一步先接通实际四泡／七泡的有限速液环—边界接收—邻膜响应，再与排液／粗化产生的慢状态相互反馈；不再让另一个局部时间步扫描替代原始生命周期目标。</p>
    <h2>物理范围与来源</h2><p>这仍是仅经膜传气的基线：h=0.8μm指定，Plateau边界／顶点传气关闭，液体总体积固定，未连接此前472份局部液体库存的排流与表活，也没有有限速破裂。纯氮—水 Henry 系数6.4e−6 mol/(m³Pa)来自Sander2023汇编；D=2e−9m²/s与γ=0.03N/m为诊断输入，未校准当前表活溶液。</p><p><a href="https://henry.mpch-mainz.gwdg.de/henry/casrn/7727-37-9">氮气 Henry 数据</a> · <a href="https://kenbrakke.com/evolver/html/quants.htm">原生函数能量</a> · <a href="https://kenbrakke.com/evolver/html/datafile.htm">已有气体扩散机制</a> · <a href="https://arxiv.org/abs/1706.01392">边界传气与阻塞近似的限制</a>。气体扩散、气体自由能与几何松弛均有先例，本阶段不主张它们本身具有创新性。</p>
    <h2>可复核数据</h2><p><a href="summary.json">全部结果和未通过目标</a> · <a href="protocol.json">冻结协议／源与输入哈希</a> · <a href="independent-audit.json">独立保存数据审计</a> · <a href="data.zip">状态、协议与源码包</a></p><p><a href="seven-open-bodies.csv">气体量／压力／体积 CSV</a> · <a href="seven-open-nodes.csv">实际几何 CSV</a> · <a href="seven-closed-bodies.csv">封闭控制 CSV</a> · <a href="four-open-warnings.json">四泡原生警告</a></p><p class="muted">逐算例完整原生输入、命令与输出：LINKS</p>
    <p class="muted">计算至最后状态约114.38秒，无训练。汇总在所有轨迹完成后遇到NumPy布尔值JSON错误；已保存原始运行源码，直接从CSV和原生日志恢复汇总，没有重跑轨迹。当前运行脚本仅修正序列化；逐字节变更证明见审计。</p></main>
    <script>const data=DATA;let frame=0,yaw=.55,pitch=.35,drag=false,last;const canvas=document.querySelector('canvas'),ctx=canvas.getContext('2d'),slider=document.querySelector('#frame'),label=document.querySelector('#label'),center=data.center,span=data.span;
    function draw(){canvas.width=Math.round(canvas.clientWidth*devicePixelRatio);canvas.height=canvas.width;let w=canvas.width;ctx.fillStyle='#fff';ctx.fillRect(0,0,w,w);const pts=data.points[frame].map(v=>{let [x,y,z]=v.map((q,k)=>(q-center[k])/span),a=Math.cos(yaw)*x-Math.sin(yaw)*y,b=Math.sin(yaw)*x+Math.cos(yaw)*y;return [w*(.5+.78*a),w*(.5-.78*(Math.cos(pitch)*z-Math.sin(pitch)*b)),Math.sin(pitch)*z+Math.cos(pitch)*b]});const order=data.tri.map((t,i)=>[t.reduce((s,v)=>s+pts[v][2],0),i]).sort((a,b)=>a[0]-b[0]);for(const [,i]of order){let t=data.tri[i];ctx.beginPath();t.forEach((v,k)=>k?ctx.lineTo(...pts[v].slice(0,2)):ctx.moveTo(...pts[v].slice(0,2)));ctx.closePath();if(data.kind[i]===1){let a=data.front[i],b=data.back[i],p=Math.max(a?data.pressure[frame][a-1]-100000:0,b?data.pressure[frame][b-1]-100000:0),f=Math.min(1,Math.max(0,p/30)),rgb=[59,109,168].map((q,k)=>Math.round(q+f*([196,78,82][k]-q)));ctx.fillStyle='rgba('+rgb.join(',')+',.18)'}else ctx.fillStyle='rgba(100,110,120,.25)';ctx.fill()}label.textContent='保存帧 '+frame+' / 10 · 交换时间 '+(frame*100)+' s · 泡内气体变化 '+data.change[frame].toFixed(5)+'%'}slider.oninput=()=>{frame=+slider.value;draw()};canvas.onpointerdown=e=>{drag=true;last=[e.clientX,e.clientY];canvas.setPointerCapture(e.pointerId)};canvas.onpointermove=e=>{if(drag){yaw+=(e.clientX-last[0])*.01;pitch+=(e.clientY-last[1])*.01;last=[e.clientX,e.clientY];draw()}};canvas.onpointerup=()=>drag=false;new ResizeObserver(draw).observe(canvas);draw();</script></html>'''
    payload=dict(points=x.tolist(),tri=tri.tolist(),front=front.tolist(),back=back.tolist(),kind=kind.tolist(),pressure=b[:,:,5].tolist(),change=((b[:,:,3].sum(1)/b[0,:,3].sum()-1)*100).tolist(),center=center.tolist(),span=float(h*2))
    html=html.replace('href="seven-open-nodes.csv">实际几何 CSV','href="data.zip">实际几何 CSV（完整数据包）')
    html=html.replace('TABLE',table).replace('LINKS',links).replace('DATA',json.dumps(payload,separators=(',',':')));(OUT/'index.html').write_text(html,encoding='utf8')
    readout={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),ROOT/'foam/scripts/audit_gas_shape.py',ROOT/'foam/scripts/recover_gas_shape.py',ROOT/'foam/scripts/run_gas_shape.py']};(OUT/'readout-provenance.json').write_text(json.dumps(readout,indent=2),encoding='utf8')
    with zipfile.ZipFile(OUT/'data.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in OUT.iterdir():
            if p.suffix in ['.json','.csv'] and p.name!='progress.json':z.write(p,p.name)
        for p in [ROOT/'foam/scripts/gas_shape.py',ROOT/'foam/scripts/run_gas_shape.py',ROOT/'foam/scripts/recover_gas_shape.py',ROOT/'foam/scripts/audit_gas_shape.py',ROOT/'foam/scripts/report_gas_shape.py',ROOT/'foam/docs/gas_shape_protocol.md']:z.write(p,'source/'+p.name)
        z.write(LOG/'runtime-source.zip','source/frozen-runtime.zip');z.write(LOG/'summary-failure.txt','summary-failure.txt')
    print('Actual geometry report, PNG/vector PDF and archives written')
if __name__=='__main__':main()
