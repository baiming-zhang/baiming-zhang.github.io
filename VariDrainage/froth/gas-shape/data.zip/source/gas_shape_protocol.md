# Gas amount / pressure / wet-shape feedback: bounded reference

Scope: a film-only gas-exchange baseline with explicit ideal gas amounts and
native surface/Helmholtz relaxation of free wet4/wet7 geometry. Liquid border
volume is fixed, film thickness is a prescribed diagnostic, and topology is
fixed. No liquid drainage, surfactant feedback, border gas crossing or rupture.
This does not replace the full original objective or validate wet-foam physics.

Use unmodified Surface Evolver2.70 function quantities. All gas body volumes
are FREE; only the actual liquid body volume is constrained. At fixed amounts,
minimize surface area tension plus ambient pressure work and ideal-gas Helmholtz
energy: E/(2gamma R²)=sum(tension*A)+sum[P0*(V-Vref)-N*log(V/Vref)].
Here N=nRT/(2gamma R²), P0=p0R/(2gamma). Geometry reference constants do not
change gradients; compute the full grand free energy independently in Python,
Fgas=P0V*((1+u)log(1+u)-u), u=N/(P0V)-1. Do not compare native energy values
across changes in N without restoring the amount-dependent constants.

R=.01m, gamma=.03N/m diagnostic; p0=100000Pa, T=298.15K, gas constant
8.31446261815324J/(mol K). Pure nitrogen in water: H_s^cp=6.4e-6mol/(m³Pa)
from Sander2023 compilation, not a calibration for the project's surfactant
solution. Dgas=2e-9m²/s and uniform h=.8e-6m are diagnostic inputs. Through
each actual original film (ftype1), kappa=Dgas*H*A/h. Border/vertex surfaces
ftype2/3 carry no gas transfer in this baseline; known border-crossing literature
precludes treating this blocking assumption as universal. Exterior body0 is a
fixed-pressure pure-nitrogen reservoir; track its cumulative received amount.
Closed comparison blocks ONLY exterior gas transfer, not ambient mechanical work.

Each step: freeze current geometry/film conductance, solve the positive
backward-Euler pressure graph (diag(V)+dt*L)Pnew=Nold+dt*gext*P0; Nnew=V*Pnew.
Then relax geometry at fixed Nnew (80 conjugate-gradient iterations +3 native
hessian_seek initially;10+1 each later step). These are optimization iterations,
not physical dynamics. Retain all Hessian and volume-projection warnings.
No warning suppression, extra relaxation scans or adaptive retries.
This split scheme can incur compressibility-splitting error; matched half-time
comparison must report it and not imply a converged coarsening prediction.

Freeze six cases, horizon1000s: seven-open dt100/10steps, seven-half dt50/20,
seven-closed dt100/10, seven-frozen-shape dt100/10, seven-no-exchange dt200/5,
four-open dt100/10. Frozen shape uses the SAME prepared seven initial state.
No-exchange is a mechanics-relaxation control, not a time-stationary solution
unless force convergence is independently satisfied. All n start at p0 V/RT
on the saved wet initial state, then undergo an amount-preserving preparation.
Seven uses prior final wet7-s020; four uses prior initial wet4-s020, retaining
its native projection problems. No rescaling of liquid or gas inventories.

Numerical checks: positive gas amounts/volumes; gas+ambient amount error<1e-12;
native vs oriented-triangle body-volume error<1e-8; fixed liquid relative
error<1e-6; graph original residual<1e-10. Fixed-geometry grand-energy change
+dt*sum(k*(Pi-Pj)*log(Pi/Pj))+reverse BE Bregman=0, relative to preparation
gas grand energy <1e-8. Native surface/Helmholtz rebuild <1e-8 relative. Shape
relaxation should not increase independently rebuilt grand energy by more
than1e-8 relative total surface energy. Record projected full vertex force
norm/surface-force norm, target1e-4, separately from algebraic balances.
No rigorous stability claim while Hessian negative indices remain. Volume
projection warnings fail the native-clean gate. Neither balance passing nor a
small transfer proves a quasistatic limit. Report half-time gas-transfer/volume
and feedback/frozen differences;1% comparison target, no post-hoc tolerance repair.

Primary sources accessed2026-11-13:
https://kenbrakke.com/evolver/html/quants.htm (function quantities, signed methods)
https://kenbrakke.com/evolver/html/datafile.htm (existing gas diffusion precedent)
https://kenbrakke.com/evolver/html/eigentut.htm (rigid/tangential Hessian modes)
https://henry.mpch-mainz.gwdg.de/henry/casrn/7727-37-9 (Sander2023)
https://arxiv.org/abs/1706.01392 (border-crossing limitation, previously screened)
Gas diffusion and ideal-gas shape coupling already exist; not novelty claims.
