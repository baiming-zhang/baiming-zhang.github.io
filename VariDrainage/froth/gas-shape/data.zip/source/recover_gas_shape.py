"""Recover the completed matrix summary from saved states; no native/PDE calls."""
import csv,json,re,zipfile
import numpy as np
from gas_shape import load,PSCALE,P0,ESCALE,RT,geometry,ROOT
from run_gas_shape import OUT,LOG,WORK,save,state_meta
def read(name):
    with (OUT/name).open() as f:return [{k:float(v) for k,v in r.items()} for r in csv.DictReader(f)]
def prep(n):
    text=(WORK/f'prepare{n}.txt').read_text(encoding='utf8');fe=(WORK/f'prepare{n}.fe').read_text(encoding='utf8')
    native=dict(energy=float(re.findall(r'ENERGY (\S+)',text)[0]),volumes={int(i):float(v) for i,v in re.findall(r'BODY (\d+) (\S+)',text)},warnings=[q for q in text.splitlines() if 'WARNING' in q],hessian_indices=list(map(int,re.findall(r'Index: (\d+)',text))))
    vv={int(i)-1:np.array([float(a),float(b),float(c)]) for i,a,b,c in re.findall(r'VERTEX (\d+) (\S+) (\S+) (\S+)',text)}
    x,t,f,b,k,ten,_=load(n);x=np.array([vv[i] for i in range(len(x))]);vref=np.array([float(re.findall(rf'parameter vref{i} = (\S+)',fe)[0]) for i in range(1,n+1)])
    N=np.array([float(re.findall(rf'parameter amount{i} = (\S+)',fe)[0]) for i in range(1,n+1)]);liquid=float(re.findall(rf'^{n+1} .* volume (\S+)',fe,re.M)[0])
    V,A,meta=state_meta(x,t,f,b,ten,n,N,vref,liquid,native)
    return dict(cells=n,**meta,**native)
if __name__=='__main__':
    cases=[('seven-open',7,100,False,False,False),('seven-half',7,50,False,False,False),('seven-closed',7,100,True,False,False),('seven-frozen-shape',7,100,False,True,False),('seven-no-exchange',7,200,False,False,True),('four-open',4,100,False,False,False)]
    runs=[];finals={}
    for name,n,dt,closed,frozen,zero in cases:
        h=read(name+'-history.csv');body=read(name+'-bodies.csv');warnings=json.loads((OUT/(name+'-warnings.json')).read_text());N0=np.array([r['n_mol'] for r in body if r['step']==0]);N=np.array([r['n_mol'] for r in body if r['step']==h[-1]['step']]);V=np.array([r['volume_m3'] for r in body if r['step']==h[-1]['step']])
        Eref=h[0]['grand_energy_nd'];checks=dict(positive=all(q['minimum_gas_amount_mol']>0 for q in h),gas_ledger=max(q['amount_error'] for q in h)<1e-12,
           liquid_volume=max(q['liquid_error'] for q in h)<1e-6,native_volumes=max(q['native_volume_error'] for q in h)<1e-8,
           native_energy=max(q['native_energy_error'] for q in h)<1e-8,graph=max(q['graph_residual'] for q in h)<1e-10,
           diffusion_energy=max(q['diffusion_energy_error'] for q in h)<1e-8,shape_descent=min(q['mechanical_drop_nd'] for q in h)>=-1e-8*Eref)
        runs.append(dict(name=name,cells=n,dt_s=dt,steps=len(h)-1,closed=closed,frozen=frozen,zero_exchange=zero,discrete_checks=checks,
           force_target_1e4=max(q['force_ratio'] for q in h)<1e-4,maximum_force_ratio=max(q['force_ratio'] for q in h),
           native_projection_clean=not any('WARNING 1055' in q['text'] for q in warnings),warning_count=len(warnings),final=h[-1],maximum_amount_error=max(q['amount_error'] for q in h),total_gas_change_relative=float(N.sum()/N0.sum()-1)))
        finals[name]=(N,V,N0)
    a,Va,N0=finals['seven-open'];half,Vh,_=finals['seven-half'];frozen,Vf,_=finals['seven-frozen-shape']
    compare=dict(half_time_transfer_difference=float(np.linalg.norm(a-half)/np.linalg.norm(half-N0)),half_time_volume_difference=float(np.linalg.norm(Va-Vh)/np.linalg.norm(Vh)),frozen_transfer_difference=float(np.linalg.norm(a-frozen)/np.linalg.norm(a-N0)))
    compare['transfer_time_1pct_pass']=compare['half_time_transfer_difference']<.01
    progress=json.loads((OUT/'progress.json').read_text());save(OUT/'summary.json',dict(preparations=[prep(n) for n in [4,7]],runs=runs,comparisons=compare,elapsed_seconds=progress['elapsed_seconds'],elapsed_scope='until final saved state, before summary serialization failure',summary_recovered_without_trajectory_rerun=True))
    for tag in ['prepare4','prepare7']+[q[0] for q in cases]:
        with zipfile.ZipFile(LOG/f'{tag}.zip','w',zipfile.ZIP_DEFLATED) as z:
            for p in WORK.glob(tag+'*'):z.write(p,p.name)
    print(json.dumps(compare,indent=2));print('Summary recovered from completed states; no native trajectory rerun')
