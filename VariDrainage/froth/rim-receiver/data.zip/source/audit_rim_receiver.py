"""Raw CODA packet / signed liquid moments / independent modal-time readout."""
from pathlib import Path
import hashlib,json,subprocess
import numpy as np
from scipy.linalg import eigh
from rim_receiver import ROOT,OUT,R,RHO,assemble
def read(name):return np.loadtxt(OUT/name,delimiter=',',skiprows=1,ndmin=2)
def main():
    summary=json.loads((OUT/'summary.json').read_text());data=np.load(OUT/'geometry.npz');parcels=data['parcels'];audits=[]
    M0,K,nodes,groups,meta,B=assemble();Jquad=np.zeros((3,3));volume=0.;center=np.array(meta['liquid_centroid_m']);a=(5+3*np.sqrt(5))/20;b=(5-np.sqrt(5))/20;quad=np.full((4,4),b);np.fill_diagonal(quad,a)
    for tri,f,back in zip(data['tets'],data['front'],data['back']):
        sign=1 if f==5 else -1 if back==5 else 0
        if not sign:continue
        p=data['points'][tri];v=sign*np.linalg.det(p)/6;volume+=v;tet=np.vstack([np.zeros(3),p]);q=quad@tet-center
        for r in q:Jquad+=RHO*v/4*((r@r)*np.eye(3)-np.outer(r,r))
    native=json.loads((ROOT/'results/free-wet-conditioned/summary.json').read_text());Vnative=next(z['liquid_volume_m3'] for r in native['runs'] if r['name']=='wet4-s020' for z in r['snapshots'] if z['label']=='initial')
    geometric=dict(native_volume_error=abs(volume/Vnative-1),quadrature_inertia_error=float(np.linalg.norm(Jquad-np.array(meta['liquid_inertia_kg_m2']))/np.linalg.norm(Jquad)))
    rigid=np.vstack([node['B'] for node in nodes]);spectral=[]
    st=np.array(meta['film_triangles']);sp=np.array([node['position'] for node in nodes])[st];sc=np.cross(sp[:,1]-sp[:,0],sp[:,2]-sp[:,0]);sa=np.linalg.norm(sc,axis=1)/2;sn=sc/(2*sa[:,None]);sg=np.array([np.cross(sn,sp[:,2]-sp[:,1]),np.cross(sn,sp[:,0]-sp[:,2]),np.cross(sn,sp[:,1]-sp[:,0])]).transpose(1,0,2)/(2*sa[:,None,None])
    for run in summary['runs']:
        tag=run['name'];event=run['event'];hist=read(tag+'-history.csv');contact=read(tag+'-contact.csv');rim=read(tag+'-rim.csv');absorb=read(tag+'-absorbed.csv');ids=absorb[:,0].astype(int)
        dm=float(contact[:,7].sum());ds=float(contact[:,8].sum());P=np.sum(contact[:,7,None]*contact[:,4:7],axis=0);KE=float(.5*np.sum(contact[:,7]*np.sum(contact[:,4:7]**2,axis=1)))
        consumed=parcels[ids,3].sum();tag_consumed=parcels[ids,4].sum();mass_gain=hist[-1,3]-hist[0,3];tag_gain=hist[-1,5]-hist[0,5]
        impact=rim[rim[:,0]==event['steps']];packet_error=0.
        for row in contact:
            rr=impact[impact[:,2]==int(row[0])][0];packet_error=max(packet_error,float(np.linalg.norm(rr[3:9]-row[1:7])))
        initial_global_mass=M0[0,0]+event['initial_mass_kg'];after_mass=(M0[0,0]+dm)+hist[-1,2]+hist[-1,3]-dm
        audit=dict(name=tag,parcel_unique=len(set(ids))==len(ids),absorbed_mass_error=float(abs(consumed/mass_gain-1)),absorbed_tag_error=float(abs(tag_consumed/tag_gain-1)),packet_mass_error=abs(dm/event['incoming_mass_kg']-1),packet_tag_error=abs(ds/event['incoming_tag_mol']-1),packet_momentum_error=float(np.linalg.norm(P-event['momentum_kg_m_s'])/np.linalg.norm(P)),packet_KE_error=abs(KE/event['incoming_kinetic_J']-1),post_handoff_global_mass_error=float(abs(after_mass/initial_global_mass-1)),post_handoff_global_tag_error=float(abs((hist[-1,4]+hist[-1,5]-ds+ds)/event['initial_tag_mol']-1)),saved_contact_state_difference=packet_error)
        audit['passed']=bool(audit['parcel_unique'] and max(v for k,v in audit.items() if k.endswith('error'))<1e-9 and packet_error<1e-12);audits.append(audit)
        # Independent time solution: diagonalize the SHARED assembled M,K and use
        # the exact discrete midpoint modal phase, rather than repeating stepping.
        M=M0.toarray();J=np.zeros(len(M))
        for row in contact:
            bb=B(row[1:4]);M[:6,:6]+=row[7]*(bb.T@bb);J[:6]+=bb.T@(row[7]*row[4:7])
        lam,phi=eigh(K.toarray(),M);omega=np.sqrt(lam.astype(complex));dt=1e-5;phase=2*np.arctan(.5*dt*omega);vel0=phi.T@J
        saved=read(tag+'-response-nodes.csv');worst=0.;scale=run['response']['maximum_relative_displacement_m'];normal_grad=normal_disp=normal_rms=0.
        for step in np.unique(saved[:,0]).astype(int):
            rows=saved[saved[:,0]==step];w=rows[:,6:9];u=rows[:,3:6]-np.array([node['position'] for node in nodes]);q6=np.linalg.lstsq(rigid,(u-w).ravel(),rcond=None)[0];actual=np.zeros(len(M));actual[:6]=q6
            wn=np.einsum('tij,tj->ti',w[st],sn);normal_disp=max(normal_disp,float(abs(wn).max()));normal_grad=max(normal_grad,float(np.linalg.norm(np.einsum('ti,tij->tj',wn,sg),axis=1).max()));normal_rms=max(normal_rms,float(np.sqrt(np.sum(sa*np.mean(wn*wn,axis=1))/sa.sum())))
            for node,ww in zip(nodes,w):
                if len(node['dof']):actual[node['dof']]=ww
            factor=np.empty_like(omega);nonzero=np.abs(omega)>1e-15;factor[nonzero]=np.sin(step*phase[nonzero])/omega[nonzero];factor[~nonzero]=step*dt
            predicted=np.real(phi@(factor*vel0));worst=max(worst,float(np.linalg.norm(predicted-actual)/max(np.linalg.norm(actual),scale,1e-300)))
        spectral.append(dict(name=tag,modal_saved_displacement_error=worst,maximum_dt_omega=float(dt*np.sqrt(max(lam.max(),0))),minimum_generalized_eigenvalue=float(lam.min()),saved_max_normal_gradient=normal_grad,saved_max_normal_displacement_m=normal_disp,saved_peak_area_normal_rms_m=normal_rms,original_full_gradient_gate_retained=run['checks']['linear_gradient'],passed=worst<1e-6,scope='independent modal time integration with shared operator assembly; not an independent constitutive validation'))
    protocol=json.loads((OUT/'protocol.json').read_text());sources=[dict(source=k,matched=hashlib.sha256((ROOT/k).read_bytes()).hexdigest()==v) for k,v in protocol['sources'].items()]
    owner=subprocess.check_output(['git','show','83d9a9365e044ac1ccb98379ea8886d45dfcf30b:coda/include/vf/coda/Rim.h'],cwd=ROOT)
    owner_same=owner.replace(b'\r\n',b'\n')==(ROOT/'coda/include/vf/coda/Rim.h').read_bytes().replace(b'\r\n',b'\n')
    main_packet=read('main-contact.csv');Ppacket=np.sum(main_packet[:,7,None]*main_packet[:,4:7],axis=0);Lpacket=np.sum(np.cross(main_packet[:,1:4]-center,main_packet[:,7,None]*main_packet[:,4:7]),axis=0)
    out=dict(packet_audits=audits,liquid_geometry=geometric,modal_audits=spectral,source_hashes=sources,coda_owner_unchanged=owner_same,
       erased_control_external_linear_sink=(-Ppacket).tolist(),erased_control_external_orbital_angular_sink=(-Lpacket).tolist(),
       geometry_and_packets_pass=all(a['passed'] for a in audits) and max(geometric.values())<1e-8,
       scope='first-contact and controlled rigid-carrier impulse reference, not physical neighbour rupture')
    text=json.dumps(out,indent=2,default=lambda v:v.item());(OUT/'independent-audit.json').write_text(text,encoding='utf8');print(text)
if __name__=='__main__':main()
