# Actual shared-film first-contact / finite recipient response reference

Return to the original FROTH track, but do not claim a complete lifecycle.
Use the merged, unmodified CODA Rim (owner83d9a936). Simulate retraction on the
actual wet4-s020/initial [gas1,gas2] shared-film footprint, projected to its area
normal plane. Report the maximum projection error. Uniform h=.8um, rho1000,
gamma=.03N/m and tagged surface amount1e-6mol/m²/interface are diagnostic inputs.
The two-sided sheet tension is2gamma. Constant-tension, zero in-plane Gibbs
modulus and viscosity; tagged S is passively carried, NOT adsorption feedback.
Initially open hole: its missing liquid is NOT claimed to have been conserved
through nucleation. All remaining parcels/rim at t0 are fully accounted.

Initialize a24-node CODA rim from innermost area parcels in24 angular bins.
Parcels are centroids of five red refinements of the actual film triangles,
with exact native-triangle area shares. Hole radius .15 minimum distance to
the boundary; center75% area centroid +25% midpoint of the first oriented
boundary edge. This is a declared controlled initial perturbation, not a scripted
arrival time. CODA Step_Frozen integrates actual line force2gamma/2 times the
polygon-area gradient, BE inertia; stationary sheet parcels reached by the rim
merge through CODA Merge. No Taylor-Culick velocity imposed. Capillary wave speed
sqrt(2gamma/(rho h)) is only a timestep scale/diagnostic; CFL.15 and half.075.

First arrival: node tube radius sqrt(M/(rho*pi*dual_length)) touches the actual
projected film/meniscus edge, or its center crosses the boundary. Radius-based
perfect absorption is an uncalibrated contact closure. Stop the retraction at
first arrival. Transfer ONLY contacted node states, not the entire film; keep
the remaining film/rim as a recorded unadvanced state. This is a first-contact
handoff, not continued rupture, reconnection or a predicted cascade.

Recipient limit: the WHOLE connected liquid border body acts as a finite rigid
carrier. Its volume, centroid and inertia come from the actual native liquid
surface integrals, not length*invented cross section. The other9 shared/exterior
films use mass-lumped, normal-only incremental membrane response on their actual
triangles, with boundary nodes tied to the carrier. A6-DOF floating reference
plus3 relative displacement DOFs per interior node gives consistent mass coupling.
Rotations are infinitesimal/scaled by R=.01m. Quadratic restoring energy is
2gamma/2 sum A grad(w dot n_triangle)^2, prebalanced at the reference geometry;
it is NOT the full nonlinear curvature/gas-pressure/surfactant film energy.
No resolved internal Plateau-border flow, acoustic propagation or local mixing.
No equilibrium claim for the original native reference shape.

Incoming point masses add m B^T B to the carrier block; actual incoming m v
and orbital angular impulse add B^T m v. Solve the coupled mass matrix for the
inelastic receiving velocity, without preset neighbour displacements. Track
kinetic loss. CODA accretion resolves linear momentum, not intrinsic rim spin;
do NOT claim full angular-momentum conservation of the retraction. Recipient
checks cover the received orbital impulse in the linearized reference model.

Neighbour response: inviscid implicit midpoint,200steps of1e-5s (2ms), save every
four steps. Record relative membrane motion, quadratic energy, reference linear/
angular momenta, max infinitesimal rotation, and relative displacement gradients.
A third impulse-erased comparison receives the SAME mass/tag but puts its impulse
in an explicitly external sink; it is a controlled erasure, not a physical event.
No further resolution/parameter scan in this stage.

Numerical gates: retraction total mass/tag/linear momentum relative<1e-10;
BE force-work/kinetic/merge loss ledger<1e-9. Surface-area release vs force work
is separately reported (finite-time/polygon-remap defect), NOT hidden in heat.
Native liquid volume rebuild<1e-8; positive carrier inertia eigenvalues;
inelastic receiving energy cannot increase beyond1e-10 relative; midpoint energy
and represented impulse balances<1e-8. Infinitesimal rotations/relative gradients
<.01 are diagnostic linear-regime bounds, not physical validation. First-contact
time1% comparison target; incoming packet sensitivity reported without forcing
agreement. Tagged amount, coupled gas, drainage, ongoing event topology and
subsequent autonomous neighbour rupture remain incomplete.

Primary context (screened2026-11-13):
https://www.lmm.jussieu.fr/~antkowiak/papers/Gaichies2025.pdf (jet/foam impact)
https://pubs.rsc.org/en/content/articlepdf/2021/sm/d0sm02153a (foam-film collapse)
https://pmc.ncbi.nlm.nih.gov/articles/PMC6435193/ (floating-reference FE precedent).
This is a controlled integration reference, not a reproduction of those experiments
or novelty for impulse transfer, floating frames or constant-tension retraction.
