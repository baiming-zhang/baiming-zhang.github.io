"""Two native first-contact runs and isolated finite-recipient response; no cascade claim."""
from pathlib import Path
import csv,hashlib,json,platform,subprocess,time,zipfile
import numpy as np
from rim_receiver import ROOT,OUT,prepare,response
LOG=ROOT/'results/logs/rim-receiver';EXE=ROOT/'build/windows/x64/release/froth_rim_first_contact.exe'
def save(p,x):p.write_text(json.dumps(x,indent=2,default=lambda v:v.item()),encoding='utf8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def csvout(p,header,data):
    with p.open('w',newline='',encoding='utf8') as f:w=csv.writer(f);w.writerow(header);w.writerows(data)
def main():
    OUT.mkdir(exist_ok=True);LOG.mkdir(parents=True,exist_ok=True);meta=prepare()
    paths=[Path(__file__),ROOT/'foam/scripts/rim_receiver.py',ROOT/'foam/bench/rim_first_contact.cpp',ROOT/'foam/docs/rim_receiver_protocol.md',ROOT/'coda/include/vf/coda/Rim.h',ROOT/'core/include/vf/core/Types.h']+[ROOT/p for p in meta['geometry_sources']]
    save(OUT/'protocol.json',dict(scope='first-contact handoff and isolated linear rigid-carrier/neighbour response; no ongoing rupture/cascade',owner_coda='83d9a9365e044ac1ccb98379ea8886d45dfcf30b',python=platform.python_version(),numpy=np.__version__,executable_sha256=sha(EXE),sources={str(p.relative_to(ROOT)):sha(p) for p in paths},preparation=meta,training=False))
    start=time.perf_counter();runs=[]
    for tag,factor in [('main',1),('half',.5)]:
        t=time.perf_counter();p=subprocess.run([str(EXE),'rim-input.dat',tag,str(factor)],cwd=OUT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
        (LOG/(tag+'.txt')).write_bytes(p.stdout)
        if p.returncode:raise RuntimeError(f'{tag} native failure; retain input/log')
        event=json.loads((OUT/(tag+'-event.json')).read_text());hist,frames,res=response(tag)
        csvout(OUT/(tag+'-response.csv'),['step','time_s','quadratic_energy_J','energy_error','linear_impulse_error','reference_angular_error','relative_rms_m','rotation_rad','relative_gradient','inelastic_loss_J'],hist)
        csvout(OUT/(tag+'-response-nodes.csv'),['step','time_s','node','x_m','y_m','z_m','wx_m','wy_m','wz_m'],frames)
        checks=dict(mass=event['max_mass_error']<1e-10,tag=event['max_tag_error']<1e-10,rim_linear_momentum=event['max_momentum_error']<1e-10,
           force_work=event['max_force_work_ledger_error']<1e-9,positive_inertia=min(res['inertia_eigenvalues'])>0,
           inelastic_loss=res['inelastic_loss_J']>=-1e-10*res['incoming_energy_J'],response_energy=res['maximum_energy_error']<1e-8,
           response_linear_impulse=res['maximum_linear_impulse_error']<1e-8,response_reference_angular_impulse=res['maximum_reference_angular_impulse_error']<1e-8,
           linear_rotation=res['maximum_rotation_rad']<.01,linear_gradient=res['maximum_relative_gradient']<.01)
        runs.append(dict(name=tag,event=event,response=res,checks=checks,elapsed_seconds=time.perf_counter()-t));save(OUT/'progress.json',dict(completed=tag))
        print(tag,event,'checks',checks,flush=True)
    hist,frames,res=response('main',True);csvout(OUT/'erased-response.csv',['step','time_s','quadratic_energy_J','energy_error','linear_impulse_error','reference_angular_error','relative_rms_m','rotation_rad','relative_gradient','inelastic_loss_J'],hist)
    a,b=[r['event'] for r in runs];compare=dict(contact_time_relative=abs(a['impact_time_s']/b['impact_time_s']-1),incoming_mass_relative=abs(a['incoming_mass_kg']/b['incoming_mass_kg']-1),incoming_impulse_relative=float(np.linalg.norm(np.array(a['momentum_kg_m_s'])-b['momentum_kg_m_s'])/np.linalg.norm(b['momentum_kg_m_s'])))
    compare['contact_time_1pct_pass']=compare['contact_time_relative']<.01
    save(OUT/'summary.json',dict(runs=runs,impulse_erased_control=res,comparisons=compare,elapsed_seconds=time.perf_counter()-start))
    print(json.dumps(compare,indent=2),flush=True)
if __name__=='__main__':main()
