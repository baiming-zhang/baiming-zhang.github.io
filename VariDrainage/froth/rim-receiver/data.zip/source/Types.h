//////////////////////////////////////////////////////////////////////////
// Basic types shared by all variational-films modules
//////////////////////////////////////////////////////////////////////////
#pragma once
#include <Eigen/Dense>
#include <complex>
#include <vector>

namespace vf {

using real = double;
using Vec3 = Eigen::Matrix<real, 3, 1>;
using Mat3 = Eigen::Matrix<real, 3, 3>;
using VecX = Eigen::Matrix<real, Eigen::Dynamic, 1>;

template<class T> using Vec3T = Eigen::Matrix<T, 3, 1>;

// Real part, used for branch decisions in code templated on the scalar type
// (so the same source can be instantiated with std::complex for complex-step checks).
inline real Real_Part(real v) { return v; }
inline real Real_Part(const std::complex<real>& v) { return v.real(); }

// Non-conjugating dot product. Eigen's dot() conjugates complex arguments,
// which would break complex-step differentiation.
template<class A, class B>
inline auto Dot3(const Eigen::Matrix<A, 3, 1>& a, const Eigen::Matrix<B, 3, 1>& b) -> decltype(a(0) * b(0))
{
	return a(0) * b(0) + a(1) * b(1) + a(2) * b(2);
}

constexpr real kPi = 3.14159265358979323846;

} // namespace vf
