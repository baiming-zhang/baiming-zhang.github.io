"""First-contact handoff evidence; white geometry, real saved rim frames."""
from pathlib import Path
import hashlib,json,zipfile
import numpy as np
from scipy.spatial import cKDTree
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from rim_receiver import ROOT,OUT,assemble,RHO,SIGMA,H
BLUE='#3b6da8';RED='#c44e52'
def read(name):return np.loadtxt(OUT/name,delimiter=',',skiprows=1,ndmin=2)
def normal_series(tag,meta,nodes):
    t=np.array(meta['film_triangles']);x=np.array([n['position'] for n in nodes]);p=x[t];c=np.cross(p[:,1]-p[:,0],p[:,2]-p[:,0]);A=np.linalg.norm(c,axis=1)/2;n=c/(2*A[:,None]);raw=read(tag+'-response-nodes.csv');rows=[]
    for step in np.unique(raw[:,0]):
        q=raw[raw[:,0]==step];w=q[:,6:9];z=np.einsum('tij,tj->ti',w[t],n);rows.append([q[0,1],np.sqrt(np.sum(A*np.mean(z*z,axis=1))/A.sum())])
    return np.array(rows)
def main():
    s=json.loads((OUT/'summary.json').read_text());audit=json.loads((OUT/'independent-audit.json').read_text());protocol=json.loads((OUT/'protocol.json').read_text());g=np.load(OUT/'geometry.npz');rim=read('main-rim.csv');event=s['runs'][0]['event'];steps=np.unique(rim[:,0]).astype(int);frames=np.array([rim[rim[:,0]==k,3:6] for k in steps]);times=np.array([rim[rim[:,0]==k,1][0] for k in steps]);parcels=g['parcels'];death=np.full(len(parcels),event['steps']+1,dtype=int);absorbed=read('main-absorbed.csv');death[absorbed[:,0].astype(int)]=absorbed[:,1].astype(int)
    _,seed=cKDTree(parcels[:,:3]).query(frames[0]);death[seed]=0;sample=np.linspace(0,len(parcels)-1,600,dtype=int);M,K,nodes,groups,meta,B=assemble()
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
    fig=plt.figure(figsize=(13,8.6),facecolor='white');gs=fig.add_gridspec(2,3,height_ratios=[1.2,1],hspace=.38,wspace=.32)
    ax=fig.add_subplot(gs[0,0],projection='3d');points=g['points']*1000;t=g['tets'];other=~g['active'];ax.add_collection3d(Poly3DCollection(points[t[other]],facecolors='#9eabb6',alpha=.06,edgecolors='none'))
    alive=death[sample]>event['steps'];ax.scatter(*(parcels[sample[alive],:3]*1000).T,s=2,c=BLUE,depthshade=False);rr=frames[-1]*1000;ax.plot(*np.vstack([rr,rr[0]]).T,color=RED,lw=1.8)
    center=(points.max(0)+points.min(0))/2;half=np.ptp(points,axis=0).max()*.54;ax.set(xlim=(center[0]-half,center[0]+half),ylim=(center[1]-half,center[1]+half),zlim=(center[2]-half,center[2]+half));ax.set_box_aspect((1,1,1));ax.set_axis_off();ax.view_init(20,35);ax.set_title('Four-bubble reference + actual rim')
    ax=fig.add_subplot(gs[0,1]);e1,e2=g['e1'],g['e2'];origin=g['origin'];project=lambda p:(p-origin)@np.array([e1,e2]).T*1000
    bound=project(g['boundary']);ax.plot(*np.vstack([bound,bound[0]]).T,color=BLUE,lw=1.2);uv=project(parcels[sample[alive],:3]);ax.scatter(*uv.T,s=2,c=BLUE,alpha=.7)
    for f,col,style in [(frames[0],'#9ba4ad','--'),(frames[-1],RED,'-')]:
        uv=project(f);ax.plot(*np.vstack([uv,uv[0]]).T,style,color=col,lw=1.5)
    ax.set_aspect('equal');ax.set(xlabel='Film-plane coordinate / mm',ylabel='Film-plane coordinate / mm',title='First contact at 367.01 microseconds')
    ax=fig.add_subplot(gs[0,2]);ax.axis('off');speed=np.sqrt(2*event['incoming_kinetic_J']/event['incoming_mass_kg']);ax.text(0,1,'Actual incoming parcel',weight='bold',va='top',fontsize=12)
    ax.text(0,.82,f'Mass: {event["incoming_mass_kg"]*1e9:.3f} micrograms\nTagged S: {event["incoming_tag_mol"]*1e12:.3f} pmol\nSpeed: {speed:.3f} m/s\n\nHalf-step impulse difference: 0.82%\nMass/tag/P balances < 1.8e-13',va='top',linespacing=1.7,color=BLUE)
    ax=fig.add_subplot(gs[1,0]);radial=[]
    for k in steps:
        q=rim[rim[:,0]==k];r=q[:,3:6]-origin;u=r/np.linalg.norm(r,axis=1)[:,None];radial.append(np.sum(q[:,9]*np.sum(q[:,6:9]*u,axis=1))/q[:,9].sum())
    ax.plot(times*1e6,radial,color=RED);ax.axhline(np.sqrt(SIGMA/(RHO*H)),ls=':',color='#888',label='capillary-speed diagnostic');ax.set(xlabel='Retraction time / microseconds',ylabel='Mass-weighted radial speed / m/s',title='CODA inertia + accretion');ax.legend(fontsize=8)
    ax=fig.add_subplot(gs[1,1]);normal_data={}
    for tag,col,style in [('main',BLUE,'-'),('half',RED,':')]:
        z=normal_series(tag,meta,nodes);normal_data[tag]=z.tolist();ax.plot(z[:,0]*1000,z[:,1]*1e6,style,color=col,label=tag)
    ax.plot([0,2],[0,0],color='#888',ls='--',label='impulse erased');ax.set(xlabel='Isolated response time / ms',ylabel='Normal RMS / micrometers',title='Neighbour response: failed regime bound');ax.legend(fontsize=8)
    ax=fig.add_subplot(gs[1,2]);ax.axis('off');ax.text(0,1,'A handoff, not a cascade prediction',weight='bold',va='top',fontsize=11)
    ax.text(0,.80,'Full relative gradient: 0.334 > 0.01\nNormal gradient diagnostic: 0.00254\nHighest response dt*omega: 3.60\n\nRigid whole-liquid recipient limit\nRetraction stops at first contact\nNo drainage/gas/surfactant feedback',color=RED,va='top',linespacing=1.6)
    fig.suptitle('Finite-speed rim -> finite liquid recipient -> neighbour response',fontsize=17,x=.06,ha='left',y=.98);fig.text(.06,.02,'Actual native footprint, planar approximation (max projection 2.385 um). No deformation magnification; passive tagged S, not adsorption closure.',fontsize=9,color='#555')
    fig.savefig(OUT/'rim-receiver.png',dpi=180,bbox_inches='tight',facecolor='white');fig.savefig(OUT/'rim-receiver.pdf',bbox_inches='tight',facecolor='white');plt.close(fig)
    payload=dict(points=g['points'].tolist(),triangles=t[other].tolist(),particles=parcels[sample,:3].tolist(),death=death[sample].tolist(),rim=frames.tolist(),steps=steps.tolist(),times=times.tolist(),boundary=g['boundary'].tolist(),e1=e1.tolist(),e2=e2.tolist(),normal=np.cross(e1,e2).tolist(),center=(center/1000).tolist(),span=float(2*half/1000))
    html='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>FROTH · 液环首次接触与边界接收</title><style>:root{color-scheme:light}*{box-sizing:border-box}body{margin:0;background:#fff;color:#243140;font:16px/1.75 system-ui,sans-serif}main{max-width:1140px;margin:auto;padding:34px 22px}h1{font-size:clamp(28px,4vw,45px);line-height:1.25}h2{margin-top:38px}a{color:#3b6da8}img{display:block;width:100%;height:auto}.tag{color:#c44e52;font-weight:700}.note{padding:18px;border-left:4px solid #c44e52;background:#faf5f5}.viewer{max-width:720px;margin:auto}canvas{display:block;background:#fff;border:1px solid #e1e6eb;width:100%;aspect-ratio:1;touch-action:none}input{width:100%;accent-color:#3b6da8}button{padding:8px 16px;border:1px solid #cad3dc;background:white;border-radius:5px;color:#243140}.muted{font-size:14px;color:#596878}</style><main><a href="../index.html">← FROTH</a><p class="tag">ACTUAL FIRST-CONTACT HANDOFF · CONTROLLED REFERENCE</p><h1>液环已到边界，接收状态有了去向</h1><p>复用已合并的 CODA 原始液环代码，在四泡实际共享膜的平面近似上，由力和吸收过程计算液环运动。首次接触后，把接触节点携带的质量、被动标记表活量和冲量交给有限质量、有限惯量的接收体，再计算其与其余九张膜的受控响应。</p>
    <div class="note">首次接触约0.367 ms，传入约1.12微克液体、2.80pmol被动标记量，节点速度约8.65m/s。半时间步传入冲量差0.82%。但接收模型的完整相对位移梯度达到0.334，超过预设0.01范围；这些结果还不能判断邻膜是否真实破裂，也没有实现自动级联。</div>
    <img src="rim-receiver.png" width="2340" height="1548" alt="实际四泡参考几何、液环首次接触和受控邻膜响应"><p><a href="rim-receiver.png">PNG</a> · <a href="rim-receiver.pdf">矢量 PDF</a></p>
    <h2>播放实际保存的首次接触过程</h2><p class="muted">拖动旋转；滑块／播放只切换实际保存帧，没有时间插值。灰色为冻结四泡参考几何，蓝色展示20,394个固定膜面片中的600个子集，红色为实际CODA液环。面片按原始吸收记录消失。平面投影最大误差2.385μm，未放大几何，也不是光学渲染。时间标签为真实求解时间；播放作慢放查看。</p><div class="viewer"><canvas aria-label="实际液环首次接触"></canvas><input id="frame" type="range" aria-label="保存帧" min="0" value="0"><button id="play">播放保存帧</button><p id="label"></p></div>
    <h2>计算了什么，尚未计算什么</h2><p>初始开孔是受控初始条件，没有声称模拟其成核或回收开孔前的液体。剩余膜面片与液环的质量、被动标记量和线动量均逐步入账；CODA代码未做私有补丁，液环速度没有预设。两次回缩共1,452步，均在第一次几何接触处结束；之后是独立的2ms接收／响应实验，不是整张膜继续破裂的动画。</p>
    <p>接收体采用整个连通边界液体的刚性整体极限，体积与惯量由实际液体表面积分得到，而非边界长度乘经验截面积。接触增加其液量约0.231%。其余九张膜采用预平衡、仅法向增量能量的线性膜模型，六自由度接收体与膜内部自由度共享质量矩阵。该极限没有解析局部边界流动、混合、流动传播或非线性表面积，也未接此前的排液与气体求解器。</p>
    <h2>收支检查通过，适用范围检查未通过</h2><p>回缩质量／标记／线动量误差均小于1.8e−13，BE线力做功—动能—合并损失账目闭合；膜面积释放与线力做功仍有约2.9%差异，单独保留，没有塞进耗散。接收后的二次能量和所表示的线动量／参考轨道角冲量误差约1e−13。CODA合并没有解析液环内部自旋，故这里不声称回缩过程完整角动量守恒。</p>
    <p>从原始吸收索引、接触节点及实际液体几何重新审计；另用共享算子装配的独立模态时间解核对保存位移，差异约7e−11。这是同一线性方程的数值核对，不能当作本构或实验验证。</p>
    <p>完整相对梯度0.334超过0.01，保留失败。仅法向梯度诊断约0.00254，法向面积加权RMS峰值约2.71μm；这些另列数据没有替换原先门槛。最高响应模态dt·ω约3.60，邻膜时间精度未收敛检验。因此还需面内流动、厚度／表活输运、非线性几何和更合适的接收体模型，才能讨论传播或终止。没有通过缩小入射冲量让门槛变绿。</p>
    <h2>对照与原始证据</h2><p>原时间步／半时间步在同一空间离散上检测到相同接触时刻；传入质量差0.884%、冲量差0.821%，不代表整体空间收敛。第三个接收对照保留相同质量和标记量，但把冲量放进明确的外部汇，响应为零；它是冲量擦除诊断，不是完整的瞬时删除模型或物理事件。</p><p><a href="summary.json">两次回缩与三组响应</a> · <a href="protocol.json">冻结协议／源与二进制哈希</a> · <a href="independent-audit.json">原始接触包／几何／模态审计</a> · <a href="data.zip">全部原始状态、输入、日志与源码</a> · <a href="main-contact.csv">主接触包CSV</a> · <a href="half-contact.csv">半步接触包CSV</a></p>
    <h2>回到完整原始目标</h2><p>这是从有限速液环到共享边界接收状态的第一次接口测试，仍需继续回缩／拓扑、空间边界液体与邻膜非线性响应，再与排液及粗化产生的慢状态相互反馈。没有指定后续破裂顺序，也没有判定本次泡簇会形成级联。已有冲量转移、浮动参考框架和恒张力回缩不作为创新；创新候选仍需由完整场景中的传播／停止差异来检验。</p><p class="muted">方法参考与实验线索：<a href="https://www.lmm.jussieu.fr/~antkowiak/papers/Gaichies2025.pdf">Jet impact in a slab of foam</a> · <a href="https://pubs.rsc.org/en/content/articlepdf/2021/sm/d0sm02153a">Dynamics and mechanism of liquid film collapse in a foam</a> · <a href="https://pmc.ncbi.nlm.nih.gov/articles/PMC6435193/">浮动参考框架先例</a>。本阶段未复现这些实验。矩阵计算约2.72秒（几何准备另计），CPU／无训练。</p></main>
    <script>const data=DATA;let frame=0,yaw=0,pitch=.15,drag=false,last,timer=null;const c=document.querySelector('canvas'),ctx=c.getContext('2d'),slider=document.querySelector('#frame'),label=document.querySelector('#label');slider.max=data.rim.length-1;
    function project(v){let r=v.map((q,k)=>(q-data.center[k])/data.span),x=r.reduce((s,q,k)=>s+q*data.e1[k],0),y=r.reduce((s,q,k)=>s+q*data.e2[k],0),z=r.reduce((s,q,k)=>s+q*data.normal[k],0),a=Math.cos(yaw)*x-Math.sin(yaw)*y,b=Math.sin(yaw)*x+Math.cos(yaw)*y;return [c.width*(.5+.82*a),c.width*(.5-.82*(Math.cos(pitch)*b-Math.sin(pitch)*z)),Math.sin(pitch)*b+Math.cos(pitch)*z]}
    function draw(){c.width=Math.round(c.clientWidth*devicePixelRatio);c.height=c.width;ctx.fillStyle='#fff';ctx.fillRect(0,0,c.width,c.height);const p=data.points.map(project),order=data.triangles.map((t,i)=>[t.reduce((s,v)=>s+p[v][2],0),i]).sort((a,b)=>a[0]-b[0]);ctx.fillStyle='rgba(130,145,160,.035)';for(const [,i]of order){ctx.beginPath();data.triangles[i].forEach((v,k)=>k?ctx.lineTo(...p[v].slice(0,2)):ctx.moveTo(...p[v].slice(0,2)));ctx.closePath();ctx.fill()}ctx.fillStyle='#3b6da8';data.particles.forEach((v,i)=>{if(data.death[i]<=data.steps[frame])return;const q=project(v);ctx.beginPath();ctx.arc(q[0],q[1],1.2*devicePixelRatio,0,2*Math.PI);ctx.fill()});function line(points,color,width){ctx.strokeStyle=color;ctx.lineWidth=width*devicePixelRatio;ctx.beginPath();points.forEach((v,k)=>{let q=project(v);k?ctx.lineTo(q[0],q[1]):ctx.moveTo(q[0],q[1])});ctx.closePath();ctx.stroke()}line(data.boundary,'#8199af',.8);line(data.rim[frame],'#c44e52',2);label.textContent='保存帧 '+frame+' / '+(data.rim.length-1)+' · 回缩时间 '+(data.times[frame]*1e6).toFixed(2)+' μs · '+(frame===data.rim.length-1?'首次接触，回缩测试结束':'尚未首次接触')}
    slider.oninput=()=>{frame=+slider.value;draw()};document.querySelector('#play').onclick=()=>{if(timer){clearInterval(timer);timer=null;return}if(frame===data.rim.length-1)frame=0;timer=setInterval(()=>{frame++;slider.value=frame;draw();if(frame===data.rim.length-1){clearInterval(timer);timer=null}},60)};c.onpointerdown=e=>{drag=true;last=[e.clientX,e.clientY];c.setPointerCapture(e.pointerId)};c.onpointermove=e=>{if(drag){yaw+=(e.clientX-last[0])*.01;pitch+=(e.clientY-last[1])*.01;last=[e.clientX,e.clientY];draw()}};c.onpointerup=()=>drag=false;new ResizeObserver(draw).observe(c);draw();</script></html>'''
    html=html.replace('DATA',json.dumps(payload,separators=(',',':')));(OUT/'index.html').write_text(html,encoding='utf8')
    scripts=[Path(__file__),ROOT/'foam/scripts/audit_rim_receiver.py'];(OUT/'readout-provenance.json').write_text(json.dumps({str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in scripts},indent=2),encoding='utf8')
    with zipfile.ZipFile(OUT/'data.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in OUT.iterdir():
            if p.suffix in ['.csv','.json','.npz','.dat'] and p.name!='progress.json':z.write(p,p.name)
        for p in (ROOT/'results/logs/rim-receiver').iterdir():z.write(p,'logs/'+p.name)
        for p in [ROOT/'foam/bench/rim_first_contact.cpp',ROOT/'foam/scripts/rim_receiver.py',ROOT/'foam/scripts/run_rim_receiver.py',*scripts,ROOT/'foam/docs/rim_receiver_protocol.md',ROOT/'coda/include/vf/coda/Rim.h',ROOT/'core/include/vf/core/Types.h']:z.write(p,'source/'+p.name)
    print('First-contact report, PNG/vector PDF and complete data package written')
if __name__=='__main__':main()
